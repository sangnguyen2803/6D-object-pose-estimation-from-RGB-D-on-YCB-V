# Phạm vi triển khai và cách đọc kết quả

Đồ án triển khai perception và grasp planning offline từ RGB-D đã đăng ký cùng
camera intrinsics. Output là pose và candidate trong camera frame. Không có
controller robot, camera-to-robot transform, IK hoặc kết quả thực thi gắp.

## Luồng tính toán

```mermaid
flowchart LR
    A[RGB + depth + K] --> B[Mask R-CNN hoặc YOLO segmentation]
    B --> C[Visible mask + valid depth]
    C --> D[Point cloud theo instance]
    B --> E[RGB CAD corners + PnP]
    D --> F[Trimmed depth ICP]
    E --> F
    F --> G[Antipodal CAD surface pairs]
    D --> G
    G --> H[Observed contact support]
    H --> I[Finger + palm + approach collision]
    I --> J[Ranked top-k hoặc no feasible candidate]
```

GT masks/poses chỉ được đọc trong evaluator sau planning. Ngoại lệ là thí nghiệm
oracle mask ghi rõ `uses_ground_truth_masks=true`, không được gộp vào kết quả
detector bình thường.

## Dữ liệu và supervision

IndustryShapes có RGB, depth, K, CAD, visible/full masks, visibility và pose.
Loader giữ từng instance, kể cả nhiều instance cùng class. Depth đổi về mét bằng
`raw × depth_scale / 1000`; CAD đổi mm sang m. Classic Train/Test được tải ở
revision cố định và kiểm tra SHA256. Pixel audit đọc toàn bộ RGB-D/masks.

Không có nhãn grasp. Candidate được tạo từ CAD normals, độ rộng gripper và
depth quan sát, không có grasp network được huấn luyện. Không có mô hình 3D
segmentation học từ point-wise GT. Point clouds suy ra từ visible masks/depth,
không phải tái tạo toàn bộ bề mặt bị che.

Mask R-CNN fine-tune từ COCO; YOLO11n-seg là speed baseline. RGB pose baseline
dự đoán 8 góc hộp CAD từ crop RGB/class embedding bằng ResNet-18 rồi giải PnP.
GT pose dựng keypoint supervision chỉ trong training. 82 rotations không đạt
ngưỡng trực chuẩn bị loại khỏi pose supervision, vẫn giữ trong detector training.

Scene-level validation không trộn frame cùng scene vào training. Validation lớn,
không cân bằng; object 3 có thay đổi domain real/synthetic. Checkpoint được chọn
bằng validation, không bằng test. Mask R-CNN chọn trên 100 frame val; YOLO chọn
bằng native validation 1.908 frame, là khác biệt giao thức đã công bố.

## Pose, contact và va chạm

Full benchmark dùng RGB keypoints/PnP + depth ICP. Backend `geometric` dùng
PCA đa khởi tạo và trimmed ICP. FPFH/render-and-compare đã thử trên validation
samples, chưa chọn làm backend chính. FoundationPose có adapter nhưng chưa chạy
trong môi trường Windows này; xem [FOUNDATIONPOSE.md](FOUNDATIONPOSE.md).
Chưa hoàn thành đối chiếu bằng official FoundationPose/BOP pipeline.

ICP residual nhỏ không chứng minh pose đúng, nhất là vật đối xứng/bị che.
Pose `ok` chỉ xác nhận tiêu chí fit của backend. `poor_fit`, `pnp_failed` hoặc
thiếu depth không được dùng để xuất grasp.

Sampler ưu tiên CAD surface gần depth đích, tìm normals antipodal với friction
giả định rồi thử bốn roll. Candidate cần ít nhất một contact gần observed target
depth trong 20 mm. Đây không xác nhận cả hai ngón tiếp xúc vật. Kích thước,
friction và độ rộng gripper là tham số giả định, chưa hiệu chuẩn với hardware.

Collision kiểm tra oriented boxes của fingers/palm trên sampled CAD target,
depth ngoài target mask và 12 vị trí approach, với margin 4 mm. Sau đó xếp hạng
contact/clearance/accessibility. Vật khuất, thể tích kín, lực, đóng ngón động và
reachability chưa được kiểm tra. Output rỗng khi không có candidate là hợp lệ.

## Thí nghiệm và câu hỏi nghiên cứu

| Câu hỏi | Phép đo đã triển khai | Giới hạn diễn giải |
|---|---|---|
| Detector tách instance trong clutter thế nào? | COCO bbox/mask AP, precision/recall, per-class AP, mask IoU, visibility recall trên 923 ảnh | Không suy ra chất lượng vật bị che hoàn toàn |
| Mask giúp geometry/pose không? | Cùng 16 frame: predicted mask, bbox depth, oracle mask; contamination và ADD/ADD-S | Contamination trên points giữ lại chiếu vào GT mask, không phải full-surface completeness |
| Depth giúp pose không? | Cùng RGB model/detector và 16 frame: PnP với/không depth ICP | Grasp của cả hai vẫn dùng depth; chưa có pipeline grasp RGB-only |
| Collision filtering thay đổi candidate thế nào? | Trước/sau lọc; reference geometry dùng GT CAD placement sau inference | Cùng thuật toán sampled-surface check, không phải mô phỏng vật lý |
| Detector ảnh hưởng downstream thế nào? | Hai detector trên cùng 16 frame, RGB-D backend; pose recall, availability, latency | Subset nhỏ, chưa có nhiều lần chạy để kết luận thống kê mạnh |

Full RGB-D benchmark còn chạy đủ 923 ảnh test. End-to-end ADD/ADD-S recall dùng
tổng GT làm mẫu số, tính misses/failed poses là thất bại. Conditional errors chỉ
tính estimate ghép class/mask IoU≥0,5, phải đọc cùng recall để tránh thiên lệch.

ADD dùng khoảng cách vertex tương ứng; ADD-S dùng nearest neighbor. Tối đa
10.000 CAD vertices được chọn xác định để hạn chế chi phí mesh lớn. Threshold
diagnostic là 10% diameter. Rotation error chiếu GT về SO(3) và ghi rõ thao tác;
ADD dùng transform gốc. Chưa xác minh symmetry và official BOP AR nên không gọi
các số này là benchmark BOP chính thức.

Candidate availability, reference collision/contact support đều là geometric
diagnostics. Không có simulation/robot để báo grasp success rate.

## Tái lập và bàn giao

- [README](../README.md): setup, dữ liệu, training/resume, inference/thí nghiệm.
- [Kết quả đo](../reports/RESULTS_VI.md): sinh từ checkpoint/artifact thực tế.
- `reports/local_data_audit.json`: pixel integrity/alignment/mask/duplicate audit.
- `reports/delivery_validation.json`: đủ test frames, SE(3), units, width,
  provenance và cùng cohort giữa các cấu hình thí nghiệm.
- `reports/artifact_manifest.json`: SHA256 source/config/checkpoints.
- `artifacts/demo/`: output đầy đủ của một frame real test có selected candidate.

Đây là baseline đã triển khai và đo, chưa đủ độ bền vững để vận hành bin-picking.
Kết quả thấp ở class khó và pose failure cần giữ nguyên trong báo cáo. Deformable
DETR, PBR training, official pose baseline/BOP metrics và simulation là phần mở
rộng chưa thực hiện.
