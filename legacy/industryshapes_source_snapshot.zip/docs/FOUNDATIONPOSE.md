# Optional FoundationPose backend

The implemented default baseline is geometric multi-hypothesis CAD registration.
It does not have the robustness of a learned pose estimator and a good geometric
residual does not establish a correct pose, especially for partial or symmetric
objects. The project includes an adapter for the official FoundationPose API.

1. Use a separate Linux CUDA environment or working WSL2 installation.
2. Follow the official setup and download the refiner/scorer weights:
   https://github.com/NVlabs/FoundationPose
3. Set `FOUNDATIONPOSE_DIR` to the checkout containing `estimater.py`.
4. Run this project's inference command with `--pose-backend foundationpose`.

```bash
export FOUNDATIONPOSE_DIR=/path/to/FoundationPose
python scripts/run.py infer --checkpoint artifacts/training/maskrcnn/best.pt \
  --pose-backend foundationpose --limit 8 --output artifacts/foundationpose
```

Install this project in that environment as well. The adapter supplies CAD in
meters, the per-frame camera matrix, depth in meters and predicted visible masks.
It never assigns a ground-truth pose or reads masks from the dataset annotation
inside the pose estimator. The official IndustryShapes adapter instead reads
reference masks; those runs are a separate reference-mask diagnostic:
https://github.com/POSE-Lab/FoundationPose_IS/blob/main/diff.patch

This optional backend has not been executed by the initial native-Windows run.
Do not label geometric-baseline results as FoundationPose results. If upgrading
FoundationPose, verify the `register` API and origin correction against its demo
before evaluating this dataset. BOP evaluation and symmetry definitions still
need verification independently of the backend.
