# Lượt cải thiện baseline

Kết quả ban đầu được giữ riêng trong `reports/RESULTS_VI.md` và
`artifacts/training/{maskrcnn,yolo11n_seg,rgb_pose}`. Cấu hình mới nằm ở
`configs/improved.yaml`; các checkpoint và benchmark mới dùng thư mục riêng.

## Dữ liệu và checkpoint selection

Tải thêm Onboardings static và PBR upright từ cùng dataset revision đã pin.
Audit đọc toàn bộ 20.932 RGB-D frame và 62.153 instance: không có file hỏng,
không có exact RGB duplicates giữa train/validation/test. Loại 617 RGB frames
lặp trong training. Train pool còn 15.484 ảnh: Classic training, onboarding và
8 scene PBR. PBR scenes 000008/000009 được giữ cho validation, tách khỏi train.
Test Classic chính thức vẫn có 923 ảnh/1.931 instance.

Validation gồm Classic holdout cũ và 2.000 PBR frame nhiều vật. Các scene Classic
holdout gồm cả synthetic object 3, nên không gọi toàn bộ nhóm này là ảnh real.
Trường `real` trong log selection có nghĩa non-PBR/Classic holdout. Chọn detector
bằng `0,7 × Classic mask AP + 0,3 × PBR mask AP` trên cùng 100+100 frame cố định.
Không dùng test chọn checkpoint. Detector đã dừng epoch 12 đang dở theo yêu cầu,
hoàn tất 11 epoch và giữ best checkpoint epoch 6. `stop_after_epoch: 11` giữ
nguyên budget/scheduler 12 epoch nhưng ngăn train thêm epoch 12; quyết định và
checkpoint hash được lưu ở `reports/improvement/detector_training_decision.json`.
PBR clutter chỉ là proxy cho real clutter;
chưa có thêm real clutter validation độc lập trong bộ training hiện có.

Mask R-CNN được warm-start từ baseline checkpoint, reset optimizer, train 12
epoch với 4.096 draws/epoch từ pool bằng weighted sampler, batch 8 và AMP. Đây
là resampled epochs, không phải quét mọi ảnh một lần mỗi epoch. Color augmentation
và copy-paste tạo thêm overlap; mask của vật bị che được cập nhật và bbox dựng
lại từ visible mask. Copy-paste chỉ dùng cho detector, không tạo supervision
pose giả từ ảnh compositing.

## Pose RGB-D

ResNet-18/FPN dự đoán dense object coordinates chuẩn hóa bằng CAD bounds và
foreground theo pixel. Input gồm RGB, depth tương đối và instance mask; class
chọn coordinate head. Training targets được back-project từ registered depth
và đưa về object frame bằng pose annotation. GT poses không xuất hiện trong
inference. Input mask trong training được lấy từ visible mask, không được
lọc bằng GT pose; lọc coordinate targets theo CAD bounds chỉ tác động loss.

Depth tương đối giữ context toàn crop, dùng median depth hợp lệ của crop, không
triệt tiêu depth ngoài input mask. Cache `dense_v3` tách visible foreground khỏi
coordinate validity. Training dùng affine crop/mask perturbation và color/depth
noise; 40% prompt là toàn bounding crop để học phân đoạn từ RGB-D khi native mask
sai. Loss coordinate được cân bằng theo instance; loss foreground dùng GT visible
mask, cân bằng foreground/background, không phụ thuộc depth hoặc pose validity.
GT rotations không đạt ngưỡng trực chuẩn bị loại khỏi pose supervision. Instance
thiếu coordinate targets vẫn đóng góp foreground loss khi đã nằm trong dataset.

Sau training, so sánh native masks và RGB-D foreground trên cùng 100 Classic +
100 PBR validation frames. Chỉ bật refinement cho class có weighted per-class
mask AP tăng. Boxes, class và confidence vẫn từ Mask R-CNN. `configs/selected.yaml`
lưu quyết định, không dùng test để chọn class. Refinement không thể sửa missed
detections; coordinate checkpoint được chọn bằng validation coordinate RMSE,
chưa phải tối ưu trực tiếp pose recall hoặc mask AP.

Inference dựng cặp model-local/camera 3D points, dùng RANSAC loại outliers rồi
fit rigid transform. Depth ICP update chỉ được nhận nếu không làm correspondence
residual tăng quá tolerance. Trạng thái pose và gate grasp dùng residual/inlier
criteria, vẫn chưa phải confidence đã hiệu chuẩn theo GT pose error.

## Grasp và collision

Sampler mới lấy contact theo ray entry/exit và dùng anchors cách nhau trong 3D.
Scan mesh hở dùng convex envelope để đề xuất, nhưng cả hai contact cần gần CAD
surface gốc trong tolerance 4 mm (vertex distance làm upper bound, closest
triangle surface nếu cần); FCL kiểm tra CAD triangles gốc. Đây không
chứng minh CAD scan là solid đầy đủ hoặc tiếp xúc đạt force closure.

Min contact width đổi từ 12 mm sang 2 mm để không loại mặc định chi tiết mỏng.
Gripper opening khi approach có clearance 12 mm tổng cộng, trong giới hạn
85 mm, thay vì chỉ thêm 2 mm. `closing_width_m` tách khỏi opening; endpoint là
gripper còn mở. Chuyển động đóng ngón/lifting chưa được thực thi hoặc kiểm chứng.

Approach giữ nguyên orientation và di chuyển theo local Z, nên swept boxes
biểu diễn liên tục thể tích fingers/palm dọc đường đi. FCL kiểm tra swept boxes
với CAD triangles; observed scene points kiểm tra với cùng swept boxes có
margin. Target được kiểm tra bằng cả CAD và observed target points để không bỏ
qua sai lệch CAD/depth. Vật khuất không có annotation/depth và robot reachability vẫn chưa biết.
Sau khi pose của tất cả instance được ước lượng, candidate còn được kiểm tra
với CAD của các neighbor có fit đạt tiêu chí. Bước này dùng pose dự đoán, không
dùng GT; CAD đặt sai vẫn có thể gây reject nhầm hoặc bỏ sót va chạm.

Reference evaluator chạy sau planning, dùng GT CAD placements, cả target và
neighbors, cộng observed depth. Cùng evaluator mới cũng được áp dụng cho
candidate baseline đã lưu để so sánh công bằng. Các số collision/contact vẫn
là geometry diagnostics, không phải simulated/physical grasp success.

## Chạy lại

```powershell
.\.venv\Scripts\python.exe -m pip install -e '.[mesh]'
.\scripts\run_improvement.ps1
```

Nếu detector đang train và chỉ muốn nối tiếp training/evaluation mà không chạy
lại download/audit, dùng `.\scripts\continue_training.ps1`. Script chờ detector
hiện tại kết thúc, dùng best detector theo quyết định dừng sớm, chạy tests/GPU smoke, train hoặc resume dense pose 24 epoch,
đánh giá detector và chọn mask refinement bằng validation. Trạng thái nằm ở
`reports/improvement/training_status.json`. Full pose/grasp benchmark là bước
riêng; không xem training completion là downstream validation.

Sau khi có checkpoint dense pose và cấu hình selected, kiểm tra pose trên
validation trước benchmark đầy đủ:

```powershell
.\.venv\Scripts\python.exe scripts/evaluate_dense_validation.py
```

Script tái lập dataset audit/dedup, resume training chưa đủ epoch, test evaluation,
pipeline, ablations và báo cáo. Xem `reports/improvement/RESULTS_VI.md` để đọc
kết quả đo sau khi các job hoàn tất. Không suy ra improvement từ việc code chạy
hoặc training loss giảm.
