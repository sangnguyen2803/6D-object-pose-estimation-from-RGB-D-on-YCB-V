"""Export an instance-colored 3D diagnostic from a pipeline's actual PLY files."""
import argparse
import json
from pathlib import Path
import numpy as np
import trimesh


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory",type=Path)
    args = parser.parse_args()
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    detections = json.loads((args.directory/"detection.json").read_text(encoding="utf-8"))
    scene = trimesh.load(args.directory/"pointcloud.ply",process=False)
    points = np.asarray(scene.vertices)
    fig = plt.figure(figsize=(9,7))
    ax = fig.add_subplot(projection="3d")
    stride = max(1,len(points)//10000)
    background = points[::stride]
    ax.scatter(*background.T,c="lightgray",s=.3,alpha=.3)
    for i,instance in enumerate(detections["instances"]):
        cloud = trimesh.load(args.directory/"pointclouds"/f"instance_{i:03d}.ply",process=False)
        points = np.asarray(cloud.vertices)
        if len(points):
            ax.scatter(*points.T,s=2,color=plt.get_cmap("tab10")(i%10),
                       label=f"pred_{i:03d}: object {instance['obj_id']}")
    ax.set(xlabel="camera X (m)",ylabel="camera Y (m)",zlabel="camera Z (m)",
           title="Predicted instance point clouds (visible surfaces only)")
    ax.legend()
    fig.tight_layout()
    target = args.directory/"instances_3d.png"
    fig.savefig(target,dpi=160)
    plt.close(fig)
    print(target)


if __name__=="__main__":
    main()
