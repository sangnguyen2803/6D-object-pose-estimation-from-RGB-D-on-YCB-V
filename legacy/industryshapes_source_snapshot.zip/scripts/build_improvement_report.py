"""Report measured before/after artifacts; never insert predicted improvements."""
from pathlib import Path
import json
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from clutterpick.common import PROJECT,write_json


def read(relative):
    path = PROJECT/relative
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None


def pipeline_summary(rows):
    if not rows:
        return None
    total = sum(row['gt_instances'] for row in rows)
    errors = [error for row in rows for error in row['pose_diagnostics']]
    times = [row['timing']['inference_s_before_reference_evaluation'] for row in rows]
    return {'frames':len(rows),'gt_instances':total,'detections':sum(row['detections'] for row in rows),
            'matched_pose_records':len(errors),
            'ADD_recall_0_1d':sum(e['ADD_success_0_1d'] and e['pose_status']=='ok' for e in errors)/total,
            'ADD_S_recall_0_1d':sum(e['ADD_S_success_0_1d'] and e['pose_status']=='ok' for e in errors)/total,
            'frames_with_candidates':sum(row['exported_grasps']>0 for row in rows),
            'exported_candidates':sum(row['exported_grasps'] for row in rows),
            'median_inference_s_excluding_first':float(np.median(times[1:] or times)),
            'completion_status':'complete' if len(rows)==923 else 'partial'}


def plot_results(target, detector_history, pose_history, detection, pipelines):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figure, axes = plt.subplots(2, 2, figsize=(13, 8))
    epochs = [r['epoch'] for r in detector_history]
    for label, key in [('Classic holdout', 'real'), ('PBR holdout', 'pbr')]:
        axes[0, 0].plot(epochs, [r['val_mask_AP_by_source'][key] for r in detector_history], label=label)
    axes[0, 0].plot(epochs, [r['val_mask_AP'] for r in detector_history], label='Selection score', linestyle='--')
    axes[0, 0].set(title='Detector validation (fixed 100 + 100 frames)', xlabel='Resampled epoch', ylabel='Mask AP50:95')
    axes[0, 0].legend()
    axes[0, 1].plot([r['epoch'] for r in pose_history],
                    [r['validation_normalized_coordinate_rmse'] for r in pose_history])
    axes[0, 1].set(title='Dense coordinate validation', xlabel='Resampled epoch', ylabel='Normalized coordinate RMSE')
    available = [(name, report) for name, report in detection.items() if report]
    width = .8 / max(len(available), 1)
    for i, (name, report) in enumerate(available):
        values = [report['metrics']['segm']['per_class_AP'][str(label)] for label in range(1, 6)]
        axes[1, 0].bar(np.arange(5) + i * width, values, width=width, label=name)
    axes[1, 0].set(title='Classic Test masks', ylabel='AP50:95', xticks=np.arange(5) + width * (len(available)-1) / 2,
                   xticklabels=['1', '2', '3', '4', '5'], xlabel='Object class')
    axes[1, 0].legend(fontsize=8)
    available_pipelines = [(name, report) for name, report in pipelines.items() if report]
    for i, (name, report) in enumerate(available_pipelines):
        axes[1, 1].bar(np.arange(2) + i * .35,
                        [report['ADD_recall_0_1d'], report['ADD_S_recall_0_1d']], width=.35, label=name)
    axes[1, 1].set(title='Classic Test pose (all GT in denominator)', ylabel='Recall @ 0.1 diameter',
                   xticks=np.arange(2) + .35 * (len(available_pipelines)-1) / 2,
                   xticklabels=['ADD', 'ADD-S'], ylim=(0, 1))
    axes[1, 1].legend(fontsize=8)
    for axis in axes.flat:
        axis.grid(axis='y', alpha=.2)
    figure.tight_layout()
    figure.savefig(target / 'measured_comparison.png', dpi=180)
    plt.close(figure)


def main():
    target = PROJECT/'reports/improvement'; target.mkdir(parents=True,exist_ok=True)
    detector_history = read('artifacts/training/improved_maskrcnn/history.json') or []
    pose_history = read('artifacts/training/dense_pose/history.json') or []
    detection = {name:read(path) for name,path in [
        ('Baseline Mask R-CNN','artifacts/evaluation/maskrcnn_test.json'),
        ('Improved Mask R-CNN','artifacts/evaluation/improved_maskrcnn_test.json'),
        ('Validation-selected masks','artifacts/evaluation/selected_detector_test.json')]}
    pipelines = {name:pipeline_summary(read(path)) for name,path in [
        ('Baseline RGB corners + ICP','artifacts/benchmark/rgbd_full/run_summary.json'),
        ('Dense RGB-D + swept mesh checks','artifacts/benchmark/improved_full/run_summary.json')]}
    reference = read('reports/improvement/baseline_reference_mesh.json')
    improved_ablations = read('artifacts/experiments/improved_ablations/results.json') or []
    after = [row for row in improved_ablations if row['mode']=='predicted_mask']
    collision = {}
    if reference:
        evaluable = sum(row['after_filter_topk']['evaluable_against_matched_gt'] for row in reference)
        collisions = sum(row['after_filter_topk']['reference_collisions'] for row in reference)
        collision['baseline_saved_candidates'] = {'frames':len(reference),'evaluable_after':evaluable,
            'collisions_after':collisions,'collision_rate':collisions/evaluable if evaluable else None}
    if after:
        evaluable = sum(row['evaluable_candidates_after'] for row in after)
        collisions = sum(row['collision_after'] for row in after)
        collision['improved_candidates'] = {'frames':len(after),'evaluable_after':evaluable,
            'collisions_after':collisions,'collision_rate':collisions/evaluable if evaluable else None,
            'contact_supported_10mm':sum(row['contact_supported_after_10mm'] for row in after)}
    measured = {'detector_training':detector_history,'dense_pose_training':pose_history,
                'detection_evaluation':detection,'pipeline_evaluation':pipelines,
                'same_reference_mesh_checker':collision,'data_split':read('reports/improvement/data_split.json'),
                'data_audit':read('reports/improvement/local_data_audit.json'),
                'mask_refinement_selection':read('reports/improvement/mask_refinement_selection.json'),
                'detector_training_decision':read('reports/improvement/detector_training_decision.json'),
                'delivery_validation':read('reports/improvement/delivery_validation.json')}
    write_json(target/'measured_summary.json',measured)
    lines = ['# Kết quả cải thiện baseline','',
             'Các số dưới đây được đọc từ artifact đo thực tế. Mục thiếu artifact được ghi chưa hoàn tất, không suy ra từ training loss.','',
             f'Detector đã hoàn tất {len(detector_history)}/12 epoch; dense pose {len(pose_history)}/24 epoch. '
             'Train dùng resampling: 4.096 image draws/epoch cho detector, 8.192 instance draws/epoch cho dense pose.',
             '', '## Detection trên Classic Test','',
             '| Model | Frames | Box AP50:95 | Mask AP50:95 | Mask AP50 |',
             '|---|---:|---:|---:|---:|']
    for name,report in detection.items():
        if report:
            lines.append(f"| {name} | {report['frame_count']} | {report['metrics']['bbox']['AP_50_95']:.4f} | "
                         f"{report['metrics']['segm']['AP_50_95']:.4f} | {report['metrics']['segm']['AP_50']:.4f} |")
    decision = measured['detector_training_decision']
    if decision:
        lines += ['', f"Theo yêu cầu, dừng epoch 12 đang dở sau {decision['completed_epochs']} epoch hoàn tất; "
                  f"dùng best checkpoint epoch {decision['selected_epoch']} với weighted validation AP "
                  f"{decision['best_validation_mask_AP']:.4f}. Không resume detector để hoàn tất epoch 12."]
    if detection['Improved Mask R-CNN'] is None:
        lines += ['', 'Chưa có test evaluation của checkpoint mới.']
    selection = measured['mask_refinement_selection']
    if selection:
        lines += ['', f"RGB-D foreground refinement được bật cho classes {selection['selected_labels']} bằng validation AP. "
                  'Boxes/classes/scores vẫn từ Mask R-CNN; test không dùng chọn refinement.']
    lines += ['', '| Model | Obj 1 | Obj 2 | Obj 3 | Obj 4 | Obj 5 |','|---|---:|---:|---:|---:|---:|']
    for name,report in detection.items():
        if report:
            values = report['metrics']['segm']['per_class_AP']
            lines.append('| '+name+' | '+' | '.join(f"{values[str(i)]:.4f}" if values[str(i)] is not None else 'N/A' for i in range(1,6))+' |')
    lines += ['', '## Pose và candidate availability','',
              '| Pipeline | Frames | ADD recall @0.1d | ADD-S recall @0.1d | Frame có candidate | Median inference (s) |',
              '|---|---:|---:|---:|---:|---:|']
    for name,summary in pipelines.items():
        if summary:
            lines.append(f"| {name} | {summary['frames']} | {summary['ADD_recall_0_1d']:.3f} | {summary['ADD_S_recall_0_1d']:.3f} | "
                         f"{summary['frames_with_candidates']}/{summary['frames']} | {summary['median_inference_s_excluding_first']:.3f} |")
    lines += ['', 'Missed detections và failed/poor-fit poses là failures trong mẫu số tất cả GT instances. '
              'ADD/ADD-S diagnostic dùng tối đa 10.000 CAD vertices, threshold 10% diameter; chưa phải official BOP AR. '
              'Timing bỏ reference evaluation, visualization và PLY export, vẫn gồm input/mask IO. '
              'Candidate availability không phải grasp success.','', '## Cùng reference mesh evaluator','',
              '| Candidate set | Frames | Evaluable top-k | Reference collisions | Rate |',
              '|---|---:|---:|---:|---:|']
    for name,record in collision.items():
        rate = f"{record['collision_rate']*100:.1f}%" if record['collision_rate'] is not None else 'N/A'
        lines.append(f"| {name} | {record['frames']} | {record['evaluable_after']} | {record['collisions_after']} | {rate} |")
    lines += ['', 'Evaluator dùng GT CAD target/neighbors, FCL triangle/box checks trên swept approach volumes và observed depth, '
              'sau planning. Baseline candidate cũ cũng được kiểm tra lại bằng evaluator này; không trộn tỷ lệ từ hai evaluator khác nhau. '
              'N/A nghĩa không có candidate để đối chiếu, không có nghĩa collision rate bằng 0.','',
              '## Thay đổi và giới hạn','',
              '- Bổ sung onboarding/PBR, exact RGB dedup, balanced sampling, overlap augmentation và PBR scene holdout.',
              '- Dense correspondence pose/RANSAC thay cho 8-corner regression; ICP update kiểm tra bằng correspondence residual.',
              '- Foreground decoder dùng measured RGB-D context; refinement chỉ bật theo per-class validation AP.',
              '- Sampler ray exit/diverse anchors, CAD-contact support, gripper opening clearance và swept-volume mesh collision checks.',
              '- Dataset real clutter validation độc lập vẫn còn thiếu; PBR clutter là proxy. Classic holdout có cả synthetic object 3.',
              '- Scan mesh hở có thể thiếu geometry. Contact/closing/lifting, dynamics, friction thực tế và IK chưa được xác minh.',
              '- Không có simulation hoặc physical grasp success. Pose residual là gate heuristic, chưa phải uncertainty đã hiệu chuẩn.',
              '', 'Xem [phương pháp và lệnh tái lập](../../docs/IMPROVEMENT_VI.md). Các artifacts mới nằm trong '
              '`artifacts/training/improved_maskrcnn`, `artifacts/training/dense_pose`, `artifacts/benchmark/improved_full` '
              'và `artifacts/experiments/improved_ablations`.','']
    if detector_history and pose_history:
        plot_results(target, detector_history, pose_history, detection, pipelines)
        lines += ['![Measured comparison](measured_comparison.png)', '',
                  'Biểu đồ chỉ hiển thị model/pipeline có artifact đo; các kết quả mới còn thiếu không được điền giả.', '']
    (target/'RESULTS_VI.md').write_text('\n'.join(lines),encoding='utf-8')
    print(target/'RESULTS_VI.md')


if __name__=='__main__':
    main()
