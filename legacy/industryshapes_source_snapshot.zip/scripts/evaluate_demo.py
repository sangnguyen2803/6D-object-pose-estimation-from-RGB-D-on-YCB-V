"""Post-inference reference geometry diagnostic for a saved demo frame."""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from clutterpick.common import load_config,resolve,read_json
from clutterpick.data import load_index
from clutterpick.pose import GeometricPoseEstimator
from run_experiments import independent_collision_check


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory")
    args = parser.parse_args()
    directory = resolve(args.directory)
    provenance = read_json(directory/"detection.json")
    config = provenance["config"]
    index,_ = load_index(config)
    frame = next(frame for frame in index["frames"] if frame["key"]==provenance["frame_key"])
    result = independent_collision_check(frame,directory,config,GeometricPoseEstimator(config))
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
