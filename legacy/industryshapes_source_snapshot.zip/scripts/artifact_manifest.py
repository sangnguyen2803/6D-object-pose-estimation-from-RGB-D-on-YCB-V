"""Record portable source/checkpoint fingerprints for the measured project."""
import hashlib
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parents[1]
paths = list((ROOT/"src").rglob("*.py"))+list((ROOT/"configs").glob("*.yaml"))
paths += list((ROOT/"tests").glob("*.py"))+list((ROOT/"scripts").glob("*.py"))
paths += list((ROOT/"scripts").glob("*.ps1"))+list((ROOT/"docs").glob("*.md"))
paths += [ROOT/"reports"/name for name in ["RESULTS_VI.md","measured_summary.json","delivery_validation.json"] if (ROOT/"reports"/name).exists()]
paths += list((ROOT/"artifacts/evaluation").glob("*.json"))
paths += [ROOT/"README.md",ROOT/"pyproject.toml",ROOT/"requirements-measured.txt",ROOT/"data/splits.json"]
for part in ["maskrcnn","rgb_pose","yolo11n_seg/weights"]:
    for checkpoint in ["best.pt","last.pt"]:
        path = ROOT/"artifacts/training"/part/checkpoint
        if path.exists():
            paths.append(path)
entries = []
for path in sorted(paths):
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(4*1024*1024),b""):
            digest.update(block)
    entries.append({"path":path.relative_to(ROOT).as_posix(),"bytes":path.stat().st_size,"sha256":digest.hexdigest()})
report = {"python":platform.python_version(),"platform":platform.platform(),
          "dataset_revision":"39e2ccc49f7a3e258eab5cec84749c5817df417a","artifacts":entries}
target = ROOT/"reports/artifact_manifest.json"
target.write_text(json.dumps(report,indent=2),encoding="utf-8")
print(target)
