"""Small native-process monitor; avoids importing CUDA libraries."""
import argparse
from pathlib import Path
import psutil

ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument("--stop-pose-training",action="store_true")
p.add_argument("--stop-yolo-training",action="store_true")
p.add_argument("--stop-benchmark",action="store_true")
args = p.parse_args()
print(psutil.virtual_memory())
for process in psutil.process_iter(["name","cmdline","memory_info"]):
    try:
        if process.info["name"]!="python.exe":
            continue
        if Path(process.cwd()).resolve()!=ROOT:
            continue
        command = " ".join(process.info["cmdline"] or [])
        print(process.pid,round(process.info["memory_info"].rss/1e6),command)
        if args.stop_pose_training and "scripts/run.py train-pose" in command and Path(process.cwd()).resolve()==ROOT:
            process.terminate()
            print("Stopped owned RGB pose training process",process.pid)
        if args.stop_yolo_training and "scripts/run.py train --architecture yolo" in command and Path(process.cwd()).resolve()==ROOT:
            for child in process.children(recursive=True):
                try:
                    child.terminate()
                except psutil.NoSuchProcess:
                    pass
            process.terminate()
            print("Stopped owned YOLO process tree",process.pid)
        if args.stop_benchmark and "scripts/run.py infer" in command and "artifacts/benchmark/rgbd_full" in command:
            process.terminate()
            print("Stopped owned initial benchmark",process.pid)
    except (psutil.NoSuchProcess,psutil.AccessDenied):
        pass
for filename in ["rgb_pose_training.log","yolo_training.log"]:
    file = ROOT/"artifacts/training"/filename
    if file.exists():
        value = file.read_text(encoding="utf-16",errors="replace")[-900:]
        print(filename,value.encode("ascii",errors="replace").decode("ascii"))
