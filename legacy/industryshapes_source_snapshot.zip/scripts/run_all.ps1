param([int]$ExperimentFrames = 16, [switch]$Retrain)
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$projectPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $projectPython)) { throw 'Run scripts/bootstrap.ps1 first' }
function Invoke-ProjectPython {
    param([string[]]$Arguments)
    & $projectPython @Arguments
    if ($LASTEXITCODE -ne 0) { throw ('Command failed: ' + ($Arguments -join ' ')) }
}
Invoke-ProjectPython -Arguments @('scripts/download_dataset.py','--groups','classic')
Invoke-ProjectPython -Arguments @('scripts/run.py','index')
Invoke-ProjectPython -Arguments @('-m','pytest','-q')
if ($Retrain -or -not (Test-Path -LiteralPath 'artifacts/training/maskrcnn/best.pt')) {
    Invoke-ProjectPython -Arguments @('scripts/run.py','train','--epochs','8')
}
if ($Retrain -or -not (Test-Path -LiteralPath 'artifacts/training/yolo11n_seg/weights/best.pt')) {
    Invoke-ProjectPython -Arguments @('scripts/run.py','train','--architecture','yolo','--epochs','8')
}
if ($Retrain -or -not (Test-Path -LiteralPath 'artifacts/training/rgb_pose/best.pt')) {
    Invoke-ProjectPython -Arguments @('scripts/run.py','train-pose','--epochs','12')
}
Invoke-ProjectPython -Arguments @('scripts/run.py','evaluate','--checkpoint','artifacts/training/maskrcnn/best.pt','--split','test','--output','artifacts/evaluation/maskrcnn_test.json')
Invoke-ProjectPython -Arguments @('scripts/run.py','evaluate','--architecture','yolo','--checkpoint','artifacts/training/yolo11n_seg/weights/best.pt','--split','test','--output','artifacts/evaluation/yolo_test.json')
Invoke-ProjectPython -Arguments @('scripts/run.py','infer','--checkpoint','artifacts/training/maskrcnn/best.pt','--limit','8','--output','artifacts/inference/maskrcnn')
Invoke-ProjectPython -Arguments @('scripts/run.py','infer','--checkpoint','artifacts/training/maskrcnn/best.pt','--pose-backend','rgbd_keypoints','--frame-key','classic_test/000002/149','--output','artifacts/demo')
Invoke-ProjectPython -Arguments @('scripts/visualize_instances.py','artifacts/demo/classic_test_000002_149')
Invoke-ProjectPython -Arguments @('scripts/evaluate_demo.py','artifacts/demo/classic_test_000002_149')
Invoke-ProjectPython -Arguments @('scripts/run.py','infer','--checkpoint','artifacts/training/maskrcnn/best.pt','--pose-backend','rgbd_keypoints','--limit','923','--skip-cloud-export','--no-plots','--output','artifacts/benchmark/rgbd_full')
Invoke-ProjectPython -Arguments @('scripts/run_experiments.py','--checkpoint','artifacts/training/maskrcnn/best.pt','--limit',"$ExperimentFrames")
Invoke-ProjectPython -Arguments @('scripts/compare_pose_modalities.py','--checkpoint','artifacts/training/maskrcnn/best.pt','--limit',"$ExperimentFrames")
Invoke-ProjectPython -Arguments @('scripts/compare_detectors.py','--limit',"$ExperimentFrames")
Invoke-ProjectPython -Arguments @('scripts/build_report.py')
if ($ExperimentFrames -eq 16) {
    Invoke-ProjectPython -Arguments @('scripts/validate_delivery.py')
}
Invoke-ProjectPython -Arguments @('scripts/artifact_manifest.py')
