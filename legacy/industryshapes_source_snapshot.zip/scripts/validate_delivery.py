"""Check measured output consistency without loading neural networks."""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    directory = ROOT/"artifacts/benchmark/rgbd_full"
    summary = read(directory/"run_summary.json")
    assert len(summary)==923, f"Incomplete benchmark: {len(summary)}/923"
    assert len({r["frame_key"] for r in summary})==923
    assert sum(r["gt_instances"] for r in summary)==1931
    poses_count,grasps_count = 0,0
    for row in summary:
        frame = directory/row["frame_key"].replace("/","_")
        poses,grasps = read(frame/"poses.json"),read(frame/"grasps.json")
        for artifact in [poses,grasps]:
            assert artifact["frame_key"]==row["frame_key"]
            assert artifact["units"]=="m"
            assert not artifact["uses_ground_truth_masks"]
            assert not artifact["uses_ground_truth_pose_for_inference"]
            assert not artifact["simulation_performed"]
            assert not artifact["physical_success_measured"]
            assert artifact["pose_backend"]=="rgbd_keypoints"
            assert artifact["grasp_generator"]=="observed_surface_priority_best_antipodal_pair_v2"
        transforms = [p["T_camera_object"] for p in poses["instances"] if "T_camera_object" in p]
        transforms += [g[key] for g in grasps["grasps"] for key in ["T_camera_gripper","T_camera_pregrasp"]]
        for raw in transforms:
            matrix = np.asarray(raw)
            assert matrix.shape==(4,4) and np.isfinite(matrix).all()
            assert np.allclose(matrix[3],[0,0,0,1])
            rotation = matrix[:3,:3]
            assert np.allclose(rotation.T@rotation,np.eye(3),atol=1e-5)
            assert np.isclose(np.linalg.det(rotation),1,atol=1e-5)
        assert len(grasps["grasps"])==row["exported_grasps"]
        for grasp in grasps["grasps"]:
            assert 0<grasp["opening_width_m"]<=grasps["config"]["gripper"]["max_opening_m"]
        poses_count += len(poses["instances"])
        grasps_count += len(grasps["grasps"])
    cohorts = {}
    for experiment,label in [("ablations","mode"),("modalities","mode"),("detectors","architecture")]:
        rows = read(ROOT/"artifacts/experiments"/experiment/"results.json")
        groups = {name:{r["frame_key"] for r in rows if r[label]==name} for name in {r[label] for r in rows}}
        assert len(groups)==(3 if experiment=="ablations" else 2)
        assert all(len(frames)==16 for frames in groups.values())
        assert len({tuple(sorted(frames)) for frames in groups.values()})==1
        cohorts[experiment] = {name:len(frames) for name,frames in groups.items()}
    report = {"passed":True,"benchmark_frames":len(summary),"gt_instances":1931,
              "predicted_pose_records":poses_count,"exported_grasp_records":grasps_count,
              "experiment_cohorts":cohorts,"checks":["unique full test frames","proper SE3 transforms",
              "gripper opening constraints","no ground truth inference","consistent final generator",
              "no fabricated simulation/physical validation","matched experiment frame cohorts"]}
    target = ROOT/"reports/delivery_validation.json"
    target.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
