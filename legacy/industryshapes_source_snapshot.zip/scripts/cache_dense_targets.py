"""Build the RGB-D supervision cache on CPU without importing PyTorch."""
import concurrent.futures
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from clutterpick.common import load_config,read_json,resolve,write_json
from clutterpick.data import load_index,select_frames
from clutterpick.dense_pose import DenseCoordinateDataset

config = load_config('configs/improved.yaml')
index,splits = load_index(config)
dataset = DenseCoordinateDataset(select_frames(index,splits['train']),read_json(resolve(config['data']['models'])/'models_info.json'),config)
valid_counts = []
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for i,count in enumerate(pool.map(lambda item:int(dataset.arrays(item)[2].sum()),range(len(dataset)))):
        valid_counts.append(count)
        if (i+1)%1000==0:
            print(f'Cached {i+1}/{len(dataset)} dense training instances',flush=True)
write_json(resolve('reports/improvement/dense_cache_audit.json'),{
    'instances':len(dataset),'instances_with_at_least_16_valid_coordinate_targets':sum(n>=16 for n in valid_counts),
    'empty_coordinate_target_instances':sum(n==0 for n in valid_counts),'torch_imported':'torch' in sys.modules,
    'cache_version':'dense_v3',
    'scope':'training targets only; input visible masks and crop depth context do not depend on GT pose'})
print('Dense training cache complete',flush=True)
