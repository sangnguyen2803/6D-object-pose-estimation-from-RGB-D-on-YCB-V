"""Exercise new RGB-D supervision and GPU forward/backward on actual train data."""
from pathlib import Path
import sys
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from clutterpick.common import load_config,read_json,resolve,write_json
from clutterpick.data import load_index,select_frames
from clutterpick.dense_pose import DenseCoordinateDataset,create_dense_network

config = load_config('configs/improved.yaml')
index,splits = load_index(config)
frames = []
for group,number in [('classic_train',3),('onboarding',3),('pbr_upright',10)]:
    frames += select_frames(index,[i for i in splits['train'] if index['frames'][i]['group']==group],number)
dataset = DenseCoordinateDataset(frames,read_json(resolve(config['data']['models'])/'models_info.json'),config,True)
samples = [dataset[i] for i in range(min(16,len(dataset)))]
images,labels,targets,valid,segmentation = [torch.stack(parts).cuda() for parts in zip(*samples)]
torch.set_num_threads(4)
model = create_dense_network(False).cuda().train()
coordinates,confidence = model(images,labels)
loss = (((coordinates-targets)**2).mean(dim=1)*valid).sum()/valid.sum().clamp(min=1)
loss += .05*torch.nn.functional.binary_cross_entropy_with_logits(confidence,segmentation.float())
assert torch.isfinite(loss)
loss.backward()
assert model.head[0].weight.grad.abs().sum()>0
result = {'finite_forward_backward':True,'batch':len(samples),'loss':loss.item(),
          'valid_pixels_per_instance':[int(mask.sum()) for mask in valid],
          'source_groups':sorted({frame['group'] for frame,_ in dataset.items[:len(samples)]}),
          'instances':[{'id':obj['instance_id'],'class':obj['obj_id']} for _,obj in dataset.items[:len(samples)]],
          'ground_truth_used_for_training_targets_only':True}
write_json(resolve('reports/improvement/dense_smoke.json'),result)
print(result)
