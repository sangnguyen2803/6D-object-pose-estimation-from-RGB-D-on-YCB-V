"""Validate complete improved delivery and separation of inference/evaluation."""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from clutterpick.common import resolve, read_json, write_json


def main():
    root = resolve('artifacts/benchmark/improved_full')
    rows = read_json(root / 'run_summary.json')
    baseline = read_json(resolve('artifacts/benchmark/rgbd_full/run_summary.json'))
    assert len(rows) == 923 and sum(row['gt_instances'] for row in rows) == 1931
    assert len({row['frame_key'] for row in rows}) == 923
    assert {row['frame_key'] for row in rows} == {row['frame_key'] for row in baseline}
    selection = read_json(resolve('reports/improvement/mask_refinement_selection.json'))
    assert selection['selection_split'] == 'val' and not selection['test_used_for_selection']
    index = read_json(resolve('data/improved_index.json'))
    splits = read_json(resolve('data/improved_splits.json'))
    validation_keys = {index['frames'][i]['key'] for i in splits['val']}
    assert set(selection['validation_frame_keys']) <= validation_keys
    assert not set(selection['validation_frame_keys']) & {row['frame_key'] for row in rows}
    decision_path = resolve('reports/improvement/detector_training_decision.json')
    if decision_path.exists():
        expected_epochs = read_json(decision_path)['completed_epochs']
    else:
        expected_epochs = read_json(root / rows[0]['frame_key'].replace('/', '_') / 'poses.json')['config']['training'].get('stop_after_epoch', 12)
    assert len(read_json(resolve('artifacts/training/improved_maskrcnn/history.json'))) == expected_epochs
    assert len(read_json(resolve('artifacts/training/dense_pose/history.json'))) == 24
    counts = {'poses': 0, 'grasps': 0}
    for row in rows:
        directory = root / row['frame_key'].replace('/', '_')
        poses, grasps = [read_json(directory / name) for name in ['poses.json', 'grasps.json']]
        for artifact in [poses, grasps]:
            assert artifact['frame_key'] == row['frame_key'] and artifact['units'] == 'm'
            assert artifact['pose_backend'] == 'dense_rgbd'
            assert artifact['grasp_generator'] == 'ray_antipodal'
            assert not artifact['uses_ground_truth_masks']
            assert not artifact['uses_ground_truth_pose_for_inference']
            assert not artifact['simulation_performed'] and not artifact['physical_success_measured']
            assert Path(artifact['pose_checkpoint']).is_file()
        transforms = [p['T_camera_object'] for p in poses['instances'] if 'T_camera_object' in p]
        transforms += [g[key] for g in grasps['grasps'] for key in ['T_camera_gripper', 'T_camera_pregrasp']]
        for raw in transforms:
            matrix = np.asarray(raw)
            assert matrix.shape == (4, 4) and np.isfinite(matrix).all()
            np.testing.assert_allclose(matrix[3], [0, 0, 0, 1], atol=1e-6)
            rotation = matrix[:3, :3]
            np.testing.assert_allclose(rotation.T @ rotation, np.eye(3), atol=1e-5)
            assert np.isclose(np.linalg.det(rotation), 1., atol=1e-5)
        assert len(grasps['grasps']) == row['exported_grasps']
        for grasp in grasps['grasps']:
            assert 0 < grasp['closing_width_m'] < grasp['opening_width_m'] <= .085
            assert not grasp['closing_motion_validated']
        counts['poses'] += len(poses['instances'])
        counts['grasps'] += len(grasps['grasps'])
    experiments = read_json(resolve('artifacts/experiments/improved_ablations/results.json'))
    cohorts = {mode: {r['frame_key'] for r in experiments if r['mode'] == mode}
               for mode in ['predicted_mask', 'bbox', 'reference_mask']}
    old_cohort = {r['frame_key'] for r in read_json(resolve('artifacts/experiments/ablations/results.json'))}
    assert all(frames == old_cohort and len(frames) == 16 for frames in cohorts.values())
    reference = read_json(resolve('reports/improvement/baseline_reference_mesh.json'))
    assert {r['frame_key'] for r in reference} == old_cohort
    for name in ['improved_maskrcnn_test.json', 'selected_detector_test.json']:
        result = read_json(resolve('artifacts/evaluation') / name)
        assert result['frame_count'] == 923 and result['gt_instances'] == 1931
        assert not result['ground_truth_masks_used_for_predictions']
        assert set(result['frame_keys']) == {row['frame_key'] for row in rows}
    result = {'passed': True, 'benchmark_frames': 923, 'gt_instances': 1931, **counts,
              'validation_selected_refined_labels': selection['selected_labels'],
              'checks': ['complete fixed test cohort', 'proper SE3 and metric units',
                         'opening/closing constraints', 'validation-only mask selection',
                         'no ground truth inference', 'same reference collision checker',
                         'no fabricated simulation or physical success']}
    write_json(resolve('reports/improvement/delivery_validation.json'), result)
    print(result)


if __name__ == '__main__':
    main()
