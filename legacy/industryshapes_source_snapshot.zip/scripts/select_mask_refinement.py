"""Choose per-class RGB-D mask refinement on fixed validation frames only."""
import argparse
import copy
from pathlib import Path
import sys
import torch
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from clutterpick.common import load_config, resolve, write_json
from clutterpick.data import load_index
from clutterpick.dense_pose import balanced_validation_frames
from clutterpick.detection import RGBDMaskRefinedDetector
from clutterpick.evaluation import evaluate_detector


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='configs/improved.yaml')
    parser.add_argument('--checkpoint', default='artifacts/training/improved_maskrcnn/best.pt')
    parser.add_argument('--limit', type=int, default=200)
    parser.add_argument('--device', default='auto')
    parser.add_argument('--output-config', default='configs/selected.yaml')
    args = parser.parse_args()
    torch.set_num_threads(4)
    config = copy.deepcopy(load_config(args.config))
    config['detector']['refined_labels'] = list(range(1, 6))
    index, splits = load_index(config)
    frames = balanced_validation_frames(index, splits, args.limit, config['seed'])
    groups = {name: [frame for frame in frames
                    if frame['group'].startswith('pbr') == (name == 'pbr')]
              for name in ['classic', 'pbr']}
    if not all(groups.values()):
        raise ValueError('Selection requires both Classic and PBR validation holdouts')
    refined = RGBDMaskRefinedDetector(resolve(args.checkpoint), config, args.device)
    output = resolve('reports/improvement/mask_refinement_validation')
    reports = {}
    for name, detector in [('native', refined.base), ('rgbd', refined)]:
        reports[name] = {}
        for source, cohort in groups.items():
            print(f'Evaluating {name} masks on {len(cohort)} {source} validation frames', flush=True)
            reports[name][source] = evaluate_detector(detector, cohort, output / f'{name}_{source}.json')
    decisions = {}
    selected = []
    for label in range(1, 6):
        scores = {}
        for name in reports:
            values = {source: report['metrics']['segm']['per_class_AP'][str(label)]
                      for source, report in reports[name].items()}
            scores[name] = (.7 * values['classic'] + .3 * values['pbr']) if all(
                value is not None for value in values.values()) else None
        enabled = all(value is not None for value in scores.values()) and scores['rgbd'] > scores['native']
        if enabled:
            selected.append(label)
        decisions[str(label)] = {'weighted_validation_mask_AP': scores, 'refinement_enabled': enabled}
    config['detector']['refined_labels'] = selected
    config['detector']['architecture'] = 'rgbd_refined' if selected else 'maskrcnn'
    selected_reports = {}
    detector = refined if selected else refined.base
    refined.refined_labels = selected
    for source, cohort in groups.items():
        selected_reports[source] = evaluate_detector(detector, cohort, output / f'selected_{source}.json')
    target = resolve(args.output_config)
    target.write_text(yaml.safe_dump(config, sort_keys=False), encoding='utf-8')
    write_json(resolve('reports/improvement/mask_refinement_selection.json'), {
        'selection_split': 'val', 'test_used_for_selection': False,
        'selection_metric': '.7 Classic per-class mask AP50:95 + .3 PBR per-class mask AP50:95',
        'validation_frame_keys': [frame['key'] for frame in frames],
        'detector_checkpoint': refined.checkpoint, 'refiner_checkpoint': refined.refiner.checkpoint,
        'decisions': decisions, 'selected_labels': selected, 'selected_config': str(target),
        'selected_metrics_by_source': {name: report['metrics'] for name, report in selected_reports.items()},
        'ground_truth_masks_used_for_predictions': False})
    print(f'Selected labels: {selected}; config: {target}', flush=True)


if __name__ == '__main__':
    main()
