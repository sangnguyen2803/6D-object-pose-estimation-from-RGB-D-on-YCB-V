"""Build reports exclusively from measured artifacts, never placeholder scores."""
import csv
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from clutterpick.common import PROJECT,write_json


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def summarize_ablations(rows):
    summary = {}
    for mode in sorted({r["mode"] for r in rows}):
        selected = [r for r in rows if r["mode"]==mode]
        errors = [r["ADD_S_mm_mean"] for r in selected if r["ADD_S_mm_mean"] is not None]
        contamination = [r.get("point_contamination_fraction_mean") for r in selected if r.get("point_contamination_fraction_mean") is not None]
        before = sum(r["evaluable_candidates_before"] for r in selected)
        after = sum(r["evaluable_candidates_after"] for r in selected)
        collision_input = sum(r.get("collision_input_candidates",0) for r in selected)
        collision_accepted = sum(r.get("collision_accepted_candidates_before_topk",0) for r in selected)
        summary[mode] = {"frames":len(selected),"gt_instances":sum(r["gt_instances"] for r in selected),
            "detections":sum(r["detections"] for r in selected),"matched_pose_estimates":sum(r["matched_instances"] for r in selected),
            "frames_with_exported_grasp":sum(r["exported_grasps"]>0 for r in selected),
            "unique_scenes_with_exported_grasp":len({r["frame_key"].rsplit('/',1)[0] for r in selected if r["exported_grasps"]>0}),
            "mean_scene_conditional_ADD_S_mm":float(np.mean(errors)) if errors else None,
            "mean_point_contamination_fraction":float(np.mean(contamination)) if contamination else None,
            "mean_pipeline_seconds":float(np.mean([r["pipeline_seconds"] for r in selected])),
            "collision_input_candidates":collision_input,"collision_accepted_candidates_before_topk":collision_accepted,
            "collision_rejection_fraction":1-collision_accepted/collision_input if collision_input else None,
            "reference_collision_rate_before":sum(r["collision_before"] for r in selected)/before if before else None,
            "reference_collision_rate_after_topk":sum(r["collision_after"] for r in selected)/after if after else None,
            "reference_contact_supported_after_10mm_fraction":sum(r.get("contact_supported_after_10mm",0) for r in selected)/after if after else None,
            "reference_evaluable_candidates_before":before,"reference_evaluable_candidates_after":after}
    return summary


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    directory = PROJECT/"reports"
    directory.mkdir(exist_ok=True)
    history_path = PROJECT/"artifacts/training/maskrcnn/history.json"
    history = read(history_path) if history_path.exists() else []
    rgb_history_path = PROJECT/"artifacts/training/rgb_pose/history.json"
    rgb_history = read(rgb_history_path) if rgb_history_path.exists() else []
    evaluation = {}
    for name,filename in [("Mask R-CNN","maskrcnn_test.json"),("YOLO11n-seg","yolo_test.json")]:
        path = PROJECT/"artifacts/evaluation"/filename
        if path.exists():
            evaluation[name] = read(path)
    ablation_path = PROJECT/"artifacts/experiments/ablations/results.json"
    ablations = summarize_ablations(read(ablation_path)) if ablation_path.exists() else {}
    modality_path = PROJECT/"artifacts/experiments/modalities/results.json"
    detector_path = PROJECT/"artifacts/experiments/detectors/results.json"
    detectors = {}
    if detector_path.exists():
        raw_detectors = read(detector_path)
        for name in sorted({r["architecture"] for r in raw_detectors}):
            selected = [r for r in raw_detectors if r["architecture"]==name]
            ground_truth = sum(r["gt_instances"] for r in selected)
            times = [r["inference_seconds"] for r in selected]
            detectors[name] = {"frames":len(selected),"gt_instances":ground_truth,
                "detections":sum(r["detections"] for r in selected),
                "matched_pose_estimates":sum(r["matched_pose_estimates"] for r in selected),
                "ADD_recall_0_1d":sum(r["ADD_success_0_1d"] for r in selected)/ground_truth,
                "ADD_S_recall_0_1d":sum(r["ADD_S_success_0_1d"] for r in selected)/ground_truth,
                "frames_with_grasps":sum(r["exported_grasps"]>0 for r in selected),
                "median_inference_seconds_excluding_first":float(np.median(times[1:] or times))}
    full_path = PROJECT/"artifacts/benchmark/rgbd_full/run_summary.json"
    full_pipeline = {}
    if full_path.exists():
        raw_full = read(full_path)
        ground_truth = sum(r["gt_instances"] for r in raw_full)
        errors = [e for r in raw_full for e in r["pose_diagnostics"]]
        times = [r["timing"]["inference_s_before_reference_evaluation"] for r in raw_full]
        full_pipeline = {"frames":len(raw_full),"gt_instances":ground_truth,
            "completion_status":"complete" if len(raw_full)==923 else "partial",
            "detections":sum(r["detections"] for r in raw_full),"matched_pose_estimates":len(errors),
            "frames_with_grasps":sum(r["exported_grasps"]>0 for r in raw_full),
            "unique_scenes_with_grasps":len({r["frame_key"].rsplit('/',1)[0] for r in raw_full if r["exported_grasps"]>0}),
            "ADD_recall_0_1d":sum(e["ADD_success_0_1d"] and e["pose_status"]=="ok" for e in errors)/ground_truth,
            "ADD_S_recall_0_1d":sum(e["ADD_S_success_0_1d"] and e["pose_status"]=="ok" for e in errors)/ground_truth,
            "median_inference_seconds_excluding_first":float(np.median(times[1:] or times)),
            "mean_conditional_ADD_S_mm":float(np.mean([e["ADD_S_m"] for e in errors])*1000) if errors else None,
            "scope":"RGB keypoints + depth ICP; excludes reference evaluation/visualization; includes input and mask export IO; no PLY export"}
    modalities = {}
    if modality_path.exists():
        raw = read(modality_path)
        for mode in sorted({r["mode"] for r in raw}):
            selected = [r for r in raw if r["mode"]==mode]
            errors = [r["ADD_S_m_mean"] for r in selected if r["ADD_S_m_mean"] is not None]
            ground_truth = sum(r["gt_instances"] for r in selected)
            modalities[mode] = {"frames":len(selected),"gt_instances":ground_truth,
                "matched_pose_estimates":sum(r["matched_instances"] for r in selected),
                "conditional_mean_scene_ADD_S_mm":float(np.mean(errors)*1000) if errors else None,
                "end_to_end_ADD_recall_0_1d":sum(r["ADD_success_0_1d"] for r in selected)/ground_truth,
                "end_to_end_ADD_S_recall_0_1d":sum(r["ADD_S_success_0_1d"] for r in selected)/ground_truth,
                "frames_with_exported_grasp":sum(r["exported_grasps"]>0 for r in selected)}
    write_json(directory/"measured_summary.json",{"maskrcnn_training":history,"rgb_pose_training":rgb_history,
               "detection_evaluation":evaluation,"ablations":ablations,"pose_modalities":modalities,
               "detector_downstream_comparison":detectors,"full_pipeline":full_pipeline})
    lines = ["# Kết quả thực nghiệm ClutterPick", "", "Báo cáo được tạo từ artifact thực tế; không có số liệu giả lập.", "",
             "## Dữ liệu và giao thức", "", "Classic Train chia theo scene: 1.792 ảnh train và 1.908 ảnh validation. Classic Test: 923 ảnh. "
             "Mask R-CNN chọn checkpoint bằng mask AP trên 100 ảnh validation cố định, lấy mẫu đều theo scene. "
             "YOLO dùng native validation trên 1.908 ảnh validation; test không dùng chọn checkpoint. "
             "Class 3 có validation synthetic và training real; xem per-class AP để nhận diện domain shift.", ""]
    if history:
        best = max(history,key=lambda h:h["val_mask_AP"])
        lines += [f"Mask R-CNN đã hoàn thành **{len(history)} epoch** trên toàn bộ 1.792 ảnh train. "
                  f"Checkpoint tốt nhất ở epoch {best['epoch']}; mask AP validation subset = {best['val_mask_AP']:.4f}. "
                  "Hai epoch đầu dùng batch 1, accumulation 2; các epoch sau dùng batch 2, accumulation 1 nếu đã resume. "
                  "Effective batch vẫn là 2; lịch thực tế được ghi trong checkpoint/history.", ""]
        fig,axes = plt.subplots(1,2,figsize=(10,4))
        epochs = [r["epoch"] for r in history]
        axes[0].plot(epochs,[r["mean_training_loss"] for r in history],marker="o")
        axes[0].set(xlabel="Epoch",ylabel="Mean training loss",title="Mask R-CNN training")
        axes[1].plot(epochs,[r["val_mask_AP"] for r in history],marker="o",label="Mask AP")
        axes[1].plot(epochs,[r["val_box_AP"] for r in history],marker="o",label="Box AP")
        axes[1].set(xlabel="Epoch",ylabel="COCO AP",title="Fixed validation subset")
        axes[1].legend(); fig.tight_layout(); fig.savefig(directory/"training_curves.png",dpi=160); plt.close(fig)
    lines += ["## Detection và instance segmentation", ""]
    if evaluation:
        lines += ["| Model | Test frames | Box AP50:95 | Mask AP50:95 | Mask AP50 | Median detector latency (s) |",
                  "|---|---:|---:|---:|---:|---:|"]
        for name,e in evaluation.items():
            lines.append(f"| {name} | {e['frame_count']} | {e['metrics']['bbox']['AP_50_95']:.4f} | "
                         f"{e['metrics']['segm']['AP_50_95']:.4f} | {e['metrics']['segm']['AP_50']:.4f} | "
                         f"{e['latency_seconds']['median_excluding_first_frame']:.4f} |")
        lines += ["", "AP dùng confidence floor 0,05. Grasp inference dùng 0,5. Hai model có optimizer/augmentation và "
                  "input size khác nhau; đây là so sánh baseline thực dụng. YOLO polygon training không biểu diễn đầy đủ mask holes, "
                  "nhưng cả hai được đánh giá bằng cùng visible mask BOP gốc.", "", "### Mask AP theo class", "",
                  "| Model | Obj 1 | Obj 2 | Obj 3 | Obj 4 | Obj 5 |", "|---|---:|---:|---:|---:|---:|"]
        for name,e in evaluation.items():
            values = e["metrics"]["segm"]["per_class_AP"]
            lines.append("| "+name+" | "+" | ".join(f"{values[str(i)]:.4f}" if values[str(i)] is not None else "N/A" for i in range(1,6))+" |")
        fig,axes = plt.subplots(1,2,figsize=(11,4))
        names = list(evaluation)
        axes[0].bar(names,[evaluation[name]["metrics"]["segm"]["AP_50_95"] for name in names])
        axes[0].set(ylabel="COCO visible mask AP50:95",ylim=(0,1),title="Classic Test: 923 frames")
        locations = np.arange(1,6)
        width = .8/len(names)
        for j,name in enumerate(names):
            values = evaluation[name]["metrics"]["segm"]["per_class_AP"]
            axes[1].bar(locations+(j-(len(names)-1)/2)*width,[values[str(i)] or 0 for i in range(1,6)],width=width,label=name)
        axes[1].set(xlabel="Object class",ylabel="Mask AP50:95",xticks=locations,ylim=(0,1),title="Per-class performance")
        axes[1].legend()
        fig.tight_layout()
        fig.savefig(directory/"detection_comparison.png",dpi=160)
        plt.close(fig)
        lines += ["", "### Recall theo visibility", "",
                  "| Model | Visible 0–25% | 25–50% | 50–75% | 75–100% |",
                  "|---|---:|---:|---:|---:|"]
        for name,e in evaluation.items():
            groups = e["visibility_mask_recall_iou50_score50"]
            lines.append("| "+name+" | "+" | ".join(f"{groups[key]['matched']}/{groups[key]['gt']} ({groups[key]['recall']:.3f})"
                         for key in ["0_25","25_50","50_75","75_100"])+" |")
        lines += ["", "Recall dùng predicted mask IoU ≥0,5, cùng class và score ≥0,5; numerator/denominator "
                  "được ghi để thể hiện các nhóm ít mẫu. Đây là recall theo visibility GT, không phải AP riêng từng nhóm. "
                  "Khác biệt class/domain có thể ảnh hưởng kết quả cùng với occlusion.", "",
                  "![Detection comparison](detection_comparison.png)", ""]
    else:
        lines += ["Chưa có artifact đánh giá test. Không suy ra test accuracy từ training loss."]
    lines += ["", "## Downstream pose và grasp", ""]
    if full_pipeline:
        lines += [f"Pipeline RGB keypoints + depth ICP đã chạy {full_pipeline['frames']}/923 frame Classic Test "
                  f"({full_pipeline['gt_instances']} GT instances). Có candidate sau lọc ở {full_pipeline['frames_with_grasps']} frame. "
                  f"End-to-end ADD recall @0,1d = {full_pipeline['ADD_recall_0_1d']:.3f}; "
                  f"ADD-S recall @0,1d = {full_pipeline['ADD_S_recall_0_1d']:.3f}. "
                  f"Median thời gian inference = {full_pipeline['median_inference_seconds_excluding_first']:.3f} s/frame.",
                  "", "Thời gian này tính từ đọc RGB-D đến lọc grasp, loại reference evaluation và visualization, "
                  "vẫn gồm mask export IO; benchmark bỏ PLY export để tránh ảnh hưởng lớn từ lưu point cloud. "
                  "Candidate availability không phải grasp success rate.", ""]
    if rgb_history:
        best_rgb = min(rgb_history,key=lambda r:r["validation_normalized_keypoint_rmse"])
        lines += [f"Baseline ResNet-18 + CAD corners/PnP đã hoàn thành {len(rgb_history)} epoch. "
                  f"Checkpoint chọn ở epoch {best_rgb['epoch']}, normalized keypoint RMSE trên validation = "
                  f"{best_rgb['validation_normalized_keypoint_rmse']:.4f}. Đây không phải metric pose 6D; pose được đánh giá riêng dưới đây.", ""]
    if modalities:
        lines += ["### RGB pose và RGB-D refinement", "",
                  "| Backend | Frames | Conditional mean frame ADD-S (mm) | End-to-end ADD recall @0.1d | ADD-S recall @0.1d |",
                  "|---|---:|---:|---:|---:|"]
        for mode,m in modalities.items():
            error = f"{m['conditional_mean_scene_ADD_S_mm']:.1f}" if m["conditional_mean_scene_ADD_S_mm"] is not None else "N/A"
            lines.append(f"| {mode} | {m['frames']} | {error} | {m['end_to_end_ADD_recall_0_1d']:.3f} | {m['end_to_end_ADD_S_recall_0_1d']:.3f} |")
        lines += ["", "Hai cấu hình dùng cùng detector và keypoint model; khác biệt là thêm depth ICP refinement. "
                  "Grasp/collision vẫn dùng depth ở cả hai. Missed detections và failed pose estimates nằm trong denominator end-to-end recall. "
                  "ADD-S chỉ là chẩn đoán đối xứng gần đúng; không gọi đây là official BOP AR.", ""]
    if ablations:
        lines += ["| Input geometry | Frames | Frame có candidate | Point contamination | Mean conditional frame ADD-S (mm) | Reference collision trước lọc | Sau lọc top-k |",
                  "|---|---:|---:|---:|---:|---:|---:|"]
        def percentage(value):
            return f"{value*100:.1f}%" if value is not None else "N/A"
        for mode,s in ablations.items():
            error = f"{s['mean_scene_conditional_ADD_S_mm']:.1f}" if s["mean_scene_conditional_ADD_S_mm"] is not None else "N/A"
            lines.append(f"| {mode} | {s['frames']} | {s['frames_with_exported_grasp']}/{s['frames']} | {percentage(s['mean_point_contamination_fraction'])} | {error} | "
                         f"{percentage(s['reference_collision_rate_before'])} | {percentage(s['reference_collision_rate_after_topk'])} |")
        lines += ["", "Pose errors là conditional trên instance mask matched; misses vẫn nằm trong số GT của summary. "
                  "Reference-mask row là oracle diagnostic. Reference collision dùng GT CAD placement + observed depth "
                  "sau khi planning hoàn tất; không dùng GT pose trong inference. Bộ kiểm tra vẫn dựa trên sampled surfaces "
                  "và approach rời rạc, không mô phỏng vật lý.", ""]
        for mode,s in ablations.items():
            lines.append(f"- `{mode}`: collision input {s['collision_input_candidates']}, còn {s['collision_accepted_candidates_before_topk']} "
                         f"candidate trước top-k; rejection rate {percentage(s['collision_rejection_fraction'])}. "
                         f"Scene có candidate: {s['unique_scenes_with_exported_grasp']}.")
        lines.append("")
        predicted = ablations.get("predicted_mask",{})
        if predicted.get("reference_evaluable_candidates_after",0):
            lines += [f"Trên subset predicted-mask này, reference collision rate sau lọc vẫn là "
                      f"**{percentage(predicted['reference_collision_rate_after_topk'])}** trên "
                      f"{predicted['reference_evaluable_candidates_after']} candidate có thể đối chiếu. "
                      f"Contact support cả hai điểm trong 10 mm chỉ đạt "
                      f"{percentage(predicted['reference_contact_supported_after_10mm_fraction'])}. "
                      "Bộ lọc trên pose dự đoán chưa chứng minh an toàn khi đối chiếu geometry reference. "
                      "Không được dùng candidate availability để kết luận grasp chất lượng tốt, kể cả khi dùng oracle masks.", ""]
    if detectors:
        lines += ["### Ảnh hưởng của detector xuống pipeline RGB-D", "",
                  "| Detector | Frames | ADD recall @0.1d | ADD-S recall @0.1d | Frame có candidate | Median inference (s) |",
                  "|---|---:|---:|---:|---:|---:|"]
        for name,m in detectors.items():
            lines.append(f"| {name} | {m['frames']} | {m['ADD_recall_0_1d']:.3f} | {m['ADD_S_recall_0_1d']:.3f} | "
                         f"{m['frames_with_grasps']}/{m['frames']} | {m['median_inference_seconds_excluding_first']:.3f} |")
        lines += ["", "Hai detector chạy trên cùng frame subset cố định, cùng RGB keypoint checkpoint, depth ICP và gripper config. "
                  "Đây là diagnostic trên subset nhỏ; detection AP phía trên dùng đầy đủ 923 ảnh. "
                  "Timing gồm đọc dữ liệu/mask IO, loại reference evaluation và visualization; bỏ PLY export.", ""]
    lines += ["## Giới hạn cần trình bày", "",
              "- Pipeline chính dùng RGB CAD corners/PnP và depth ICP. Backend hình học dùng CAD registration đa khởi tạo với trimmed ICP; FoundationPose adapter chưa được chạy. "
              "Partial geometry và đối xứng có thể cho residual nhỏ nhưng orientation sai.",
              "- Render-and-compare và FPFH là backend/chẩn đoán tùy chọn đã thử trên validation samples; "
              "không mặc định coi chúng cải thiện mọi object.",
              "- `ok` ở pose là vượt tiêu chí geometric fit, không phải xác nhận đúng GT pose. ADD/ADD-S và contact support "
              "giúp nhận diện lỗi downstream; symmetry metadata và official BOP AR chưa được xác minh đầy đủ.",
              "- ADD/ADD-S dùng tối đa 10.000 CAD vertices lấy mẫu xác định, vì vậy là diagnostic xấp xỉ với mesh lớn; "
              "vertex counts được lưu trong từng pose diagnostic.",
              "- Candidate không va chạm có thể không chạm đúng vật. Xem `reference_contact_supported_after_10mm_fraction`; "
              "đây cũng chỉ là chẩn đoán hình học, không phải force closure hay grasp success.",
              "- Không có kết quả mô phỏng hoặc robot vật lý trong phiên triển khai này. Không báo grasp success rate.",
              "", "## Artifact", "", "Checkpoint: `artifacts/training/`. Metrics: `artifacts/evaluation/`. "
              "Ablations: `artifacts/experiments/ablations/`. Demo RGB-D: `artifacts/demo/classic_test_000002_149/`. "
              "Code/setup/inference: README.md. Data pixel audit: reports/local_data_audit.json.", ""]
    (directory/"RESULTS_VI.md").write_text("\n".join(lines),encoding="utf-8")
    print(directory/"RESULTS_VI.md",flush=True)


if __name__=="__main__":
    main()
