param([switch]$SkipValidationSelection, [switch]$UseExistingDetectorBest)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$projectPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
$statusPath = Join-Path $projectRoot 'reports\improvement\training_status.json'
$driverPhase = 'starting'

function Set-TrainingStatus {
    param([string]$Phase, [string]$Detail)
    $script:driverPhase = $Phase
    $status = @{phase=$Phase; detail=$Detail; updated_utc=[DateTime]::UtcNow.ToString('o')}
    $json = $status | ConvertTo-Json
    [System.IO.File]::WriteAllText($statusPath, $json, [System.Text.UTF8Encoding]::new($false))
    Write-Output ($Phase + ': ' + $Detail)
}

function Get-CompletedEpochs {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return 0 }
    return @((Get-Content -Raw -Encoding UTF8 -LiteralPath $Path | ConvertFrom-Json)).Count
}

function Invoke-TrainingStep {
    param([string]$Phase, [string]$Log, [string[]]$Arguments)
    Set-TrainingStatus -Phase $Phase -Detail ($Arguments -join ' ')
    # One child process at a time avoids duplicate Torch/CUDA memory on Windows.
    # These logs use PowerShell's redirected encoding; Get-Content detects the BOM.
    $savedPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    & $projectPython @Arguments *> $Log
    $stepExitCode = $LASTEXITCODE
    $ErrorActionPreference = $savedPreference
    if ($stepExitCode -ne 0) { throw ($Phase + ' failed with exit code ' + $stepExitCode + '; see ' + $Log) }
}

try {
    $decisionPath = 'reports/improvement/detector_training_decision.json'
    $detectorTarget = 12
    if (Test-Path -LiteralPath $decisionPath) {
        $decision = Get-Content -Raw -Encoding UTF8 -LiteralPath $decisionPath | ConvertFrom-Json
        if ($decision.use_existing_best) { $UseExistingDetectorBest = $true }
        $detectorTarget = [int]$decision.completed_epochs
    }
    $running = @(Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" |
        Where-Object { $_.CommandLine -like '*configs/improved.yaml*' -and $_.CommandLine -like '*train --epochs 12*' })
    $existing = @($running | ForEach-Object { Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue })
    while (@($existing | Where-Object { -not $_.HasExited }).Count -gt 0) {
        Set-TrainingStatus -Phase 'waiting_for_active_detector' -Detail ('Existing detector: ' +
            (Get-CompletedEpochs 'artifacts/training/improved_maskrcnn/history.json') + '/12 completed epochs')
        Start-Sleep -Seconds 30
    }
    if (-not $UseExistingDetectorBest -and (Get-CompletedEpochs 'artifacts/training/improved_maskrcnn/history.json') -lt $detectorTarget) {
        $arguments = @('scripts/run.py','--config','configs/improved.yaml','train','--epochs','12','--val-limit','200','--device','cuda')
        if (Test-Path -LiteralPath 'artifacts/training/improved_maskrcnn/last.pt') {
            $arguments += @('--resume','artifacts/training/improved_maskrcnn/last.pt')
        }
        Invoke-TrainingStep -Phase 'detector_resume' -Log 'artifacts/continued_detector_training.log' -Arguments $arguments
    }
    if (-not (Test-Path -LiteralPath 'artifacts/training/improved_maskrcnn/best.pt')) {
        throw 'Selected detector best checkpoint is missing'
    }
    if (-not $UseExistingDetectorBest -and (Get-CompletedEpochs 'artifacts/training/improved_maskrcnn/history.json') -ne $detectorTarget) {
        throw 'Detector did not complete the selected epoch target'
    }
    Invoke-TrainingStep -Phase 'tests' -Log 'artifacts/improvement_tests.log' -Arguments @('-m','pytest','-q')
    Invoke-TrainingStep -Phase 'native_detector_test' -Log 'artifacts/improved_detector_test.log' -Arguments @(
        'scripts/run.py','--config','configs/improved.yaml','evaluate','--checkpoint','artifacts/training/improved_maskrcnn/best.pt',
        '--split','test','--output','artifacts/evaluation/improved_maskrcnn_test.json')
    Invoke-TrainingStep -Phase 'dense_gpu_smoke' -Log 'artifacts/dense_gpu_smoke.log' -Arguments @('scripts/smoke_improved.py')
    if ((Get-CompletedEpochs 'artifacts/training/dense_pose/history.json') -lt 24) {
        $arguments = @('scripts/run.py','--config','configs/improved.yaml','train-dense-pose','--epochs','24','--device','cuda')
        if (Test-Path -LiteralPath 'artifacts/training/dense_pose/last.pt') {
            $arguments += @('--resume','artifacts/training/dense_pose/last.pt')
        }
        Invoke-TrainingStep -Phase 'dense_pose_training' -Log 'artifacts/dense_pose_training.log' -Arguments $arguments
    }
    if ((Get-CompletedEpochs 'artifacts/training/dense_pose/history.json') -ne 24) {
        throw 'Dense pose did not complete the configured 24 epochs'
    }
    if (-not $SkipValidationSelection) {
        Invoke-TrainingStep -Phase 'mask_refinement_selection' -Log 'artifacts/mask_refinement_selection.log' -Arguments @('scripts/select_mask_refinement.py')
        Invoke-TrainingStep -Phase 'selected_detector_test' -Log 'artifacts/selected_detector_test.log' -Arguments @(
            'scripts/run.py','--config','configs/selected.yaml','evaluate','--checkpoint','artifacts/training/improved_maskrcnn/best.pt',
            '--split','test','--output','artifacts/evaluation/selected_detector_test.json')
    }
    Invoke-TrainingStep -Phase 'report' -Log 'artifacts/improvement_report.log' -Arguments @('scripts/build_improvement_report.py')
    Set-TrainingStatus -Phase 'training_and_detection_evaluation_complete' -Detail ('Detector best selected after ' +
        (Get-CompletedEpochs 'artifacts/training/improved_maskrcnn/history.json') + ' completed epochs; dense pose 24/24. Full downstream pose/grasp benchmark is still pending.')
} catch {
    $failedPhase = $driverPhase
    Set-TrainingStatus -Phase 'failed' -Detail ($failedPhase + ': ' + $_.Exception.Message)
    Write-Error $_
    exit 1
}
