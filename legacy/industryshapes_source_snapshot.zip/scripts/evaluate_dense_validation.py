"""Measure held-out dense pose accuracy before the full grasp benchmark."""
import argparse
from collections import Counter
from pathlib import Path
import sys
import numpy as np
import torch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from clutterpick.common import load_config, resolve, read_json, write_json, set_seed
from clutterpick.data import load_index, load_rgbd
from clutterpick.dense_pose import DenseRGBDEstimator, balanced_validation_frames
from clutterpick.detection import load_detector
from clutterpick.pipeline import reference_detections, match_references
from clutterpick.evaluation import pose_errors


def summarize(rows, counts):
    output = {}
    for label in range(1, 6):
        selected = [row for row in rows if row['obj_id'] == label]
        matched = [row for row in selected if 'ADD_m' in row]
        success = [row for row in matched if row['status'] == 'ok']
        output[str(label)] = {
            'gt_instances': counts[label], 'detections': len(selected), 'matched_transform_records': len(matched),
            'ADD_recall_0_1d': sum(row['ADD_success_0_1d'] for row in success) / counts[label] if counts[label] else None,
            'ADD_S_recall_0_1d': sum(row['ADD_S_success_0_1d'] for row in success) / counts[label] if counts[label] else None,
            'median_conditional_ADD_S_mm': float(np.median([row['ADD_S_m'] * 1000 for row in matched])) if matched else None,
            'poses_passing_grasp_fit_gate': sum(row['passes_grasp_fit_gate'] for row in selected)}
    total = sum(counts.values())
    return {'gt_instances': total, 'per_class': output,
            'ADD_recall_0_1d': sum(row.get('ADD_success_0_1d', False) and row['status'] == 'ok' for row in rows) / total,
            'ADD_S_recall_0_1d': sum(row.get('ADD_S_success_0_1d', False) and row['status'] == 'ok' for row in rows) / total,
            'poses_passing_grasp_fit_gate': sum(row['passes_grasp_fit_gate'] for row in rows)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='configs/selected.yaml')
    parser.add_argument('--checkpoint', default='artifacts/training/improved_maskrcnn/best.pt')
    parser.add_argument('--limit', type=int, default=60)
    parser.add_argument('--output', default='reports/improvement/dense_pose_validation.json')
    args = parser.parse_args()
    torch.set_num_threads(4)
    config = load_config(args.config)
    set_seed(config['seed'])
    index, splits = load_index(config)
    frames = balanced_validation_frames(index, splits, args.limit, config['seed'])
    info = read_json(resolve(config['data']['models']) / 'models_info.json')
    detector = load_detector(resolve(args.checkpoint), config)
    estimator = detector.refiner if hasattr(detector, 'refiner') else DenseRGBDEstimator(config['dense_pose']['checkpoint'], config)
    counts = Counter(obj['obj_id'] for frame in frames for obj in frame['instances'])
    report = {'split': 'val', 'frame_keys': [frame['key'] for frame in frames],
              'detector_checkpoint': detector.checkpoint, 'pose_checkpoint': estimator.checkpoint,
              'ground_truth_pose_used_for_inference': False, 'modes': {}}
    for mode in ['predicted_mask', 'reference_mask']:
        rows = []
        for frame in frames:
            rgb, depth, k = load_rgbd(frame)
            if mode == 'reference_mask':
                prediction = reference_detections(frame)
            elif getattr(detector, 'requires_depth', False):
                prediction = detector.predict(rgb, depth=depth, k=k)
            else:
                prediction = detector.predict(rgb)
            items = [{'obj_id': int(label), 'mask': mask}
                     for label, mask in zip(prediction['labels'], prediction['masks'])]
            poses = [estimator.estimate_rgbd(rgb, depth, k, box, item['mask'], item['obj_id'])
                     for box, item in zip(prediction['boxes'], items)]
            # Reference annotation appears only after all predictions are made.
            matches = match_references(items, frame)
            for position, (item, pose) in enumerate(zip(items, poses)):
                row = {'frame_key': frame['key'], 'obj_id': item['obj_id'], 'status': pose['status'],
                       'correspondence_count': pose.get('correspondence_count'),
                       'inlier_fraction': pose.get('inlier_fraction'),
                       'correspondence_rmse_m': pose.get('correspondence_rmse_m'),
                       'observed_trimmed_rmse_m': pose.get('observed_trimmed_rmse_m'),
                       'passes_grasp_fit_gate': pose['status'] == 'ok' and
                           pose.get('observed_trimmed_rmse_m', float('inf')) <= config['grasp']['max_pose_fit_rmse_m']}
                if position in matches and 'T_camera_object' in pose:
                    obj, iou = matches[position]
                    truth = np.eye(4)
                    truth[:3, :3] = np.asarray(obj['R_m2c']).reshape(3, 3)
                    truth[:3, 3] = np.asarray(obj['t_m2c_mm']) / 1000
                    mesh, _, _ = estimator.geometry.mesh(obj['obj_id'])
                    errors = pose_errors(mesh, np.asarray(pose['T_camera_object']), truth)
                    threshold = info[str(obj['obj_id'])]['diameter'] / 1000 * .1
                    row.update(errors, reference_instance_id=obj['instance_id'], mask_iou=iou,
                               ADD_success_0_1d=errors['ADD_m'] < threshold,
                               ADD_S_success_0_1d=errors['ADD_S_m'] < threshold)
                rows.append(row)
            print(f'{mode}: {frame["key"]}, detections={len(items)}', flush=True)
        report['modes'][mode] = {'uses_ground_truth_masks': mode == 'reference_mask',
                                 'summary': summarize(rows, counts), 'records': rows}
        write_json(resolve(args.output), report)
    print({mode: values['summary'] for mode, values in report['modes'].items()}, flush=True)


if __name__ == '__main__':
    main()
