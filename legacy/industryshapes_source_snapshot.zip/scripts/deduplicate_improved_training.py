"""Remove exact redundant training RGB frames; keep held-out images untouched."""
from pathlib import Path
from collections import Counter
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from clutterpick.common import load_config,read_json,resolve,write_json
from clutterpick.data import load_index

config = load_config('configs/improved.yaml')
index,splits = load_index(config)
audit = read_json(resolve('reports/improvement/local_data_audit.json'))
assert not audit['errors']
by_key = {frame['key']:frame['id'] for frame in index['frames']}
training,held_out = set(splits['train']),set(splits['val']+splits['test'])
excluded = set()
for group in audit['duplicate_rgb_groups']:
    ids = sorted(by_key[key] for key in group)
    candidates = [i for i in ids if i in training]
    if any(i in held_out for i in ids):
        excluded.update(candidates)
    else:
        excluded.update(candidates[1:])
splits['train'] = [i for i in splits['train'] if i not in excluded]
splits['policy'] = 'Official Classic Test; fixed Classic holdout; PBR scenes 000008/000009 held out; exact RGB training duplicates excluded'
splits['pbr_validation_scenes'] = config['data']['pbr_validation_scenes']
splits['onboarding_in_training'] = True
splits['training_duplicate_rgb_exclusions'] = sorted(set(splits.get('training_duplicate_rgb_exclusions',[]))|{index['frames'][i]['key'] for i in excluded})
write_json(resolve(config['data']['splits']),splits)
report = read_json(resolve(config['data']['index_report']))
for split in ['train','val','test']:
    frames = [index['frames'][i] for i in splits[split]]
    report['frame_counts'][split] = len(frames)
    report['multi_object_frames'][split] = sum(len(f['instances'])>1 for f in frames)
    report['source_groups'][split] = dict(Counter(f['group'] for f in frames))
    report['class_instances'][split] = dict(Counter(obj['obj_id'] for f in frames for obj in f['instances']))
report['exact_duplicate_training_frames_excluded'] = len(splits['training_duplicate_rgb_exclusions'])
write_json(resolve(config['data']['index_report']),report)
print({'training_frames':len(splits['train']),'duplicate_exclusions':len(splits['training_duplicate_rgb_exclusions'])})
