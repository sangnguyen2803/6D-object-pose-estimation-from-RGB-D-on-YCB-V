param([switch]$Retrain)
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$projectPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
function Invoke-ImprovementPython {
    param([string[]]$Arguments)
    & $projectPython @Arguments
    if ($LASTEXITCODE -ne 0) { throw ('Command failed: '+($Arguments -join ' ')) }
}
Invoke-ImprovementPython -Arguments @('scripts/download_dataset.py','--groups','classic','onboarding','pbr-upright')
Invoke-ImprovementPython -Arguments @('scripts/run.py','--config','configs/improved.yaml','index')
Invoke-ImprovementPython -Arguments @('scripts/audit_local.py','--config','configs/improved.yaml','--output','reports/improvement/local_data_audit.json')
Invoke-ImprovementPython -Arguments @('scripts/deduplicate_improved_training.py')
Invoke-ImprovementPython -Arguments @('-m','pytest','-q')
$detectorHistory = 'artifacts/training/improved_maskrcnn/history.json'
$detectorEpochs = if (Test-Path -LiteralPath $detectorHistory) { @((Get-Content -Raw -LiteralPath $detectorHistory | ConvertFrom-Json)).Count } else { 0 }
$detectorTarget = 11
if ($Retrain -or $detectorEpochs -lt $detectorTarget) {
    $trainingArguments = @('scripts/run.py','--config','configs/improved.yaml','train','--epochs','12','--val-limit','200')
    if (-not $Retrain -and (Test-Path -LiteralPath 'artifacts/training/improved_maskrcnn/last.pt')) {
        $trainingArguments += @('--resume','artifacts/training/improved_maskrcnn/last.pt')
    }
    Invoke-ImprovementPython -Arguments $trainingArguments
}
$poseHistory = 'artifacts/training/dense_pose/history.json'
$poseEpochs = if (Test-Path -LiteralPath $poseHistory) { @((Get-Content -Raw -LiteralPath $poseHistory | ConvertFrom-Json)).Count } else { 0 }
if ($Retrain -or $poseEpochs -lt 24) {
    Invoke-ImprovementPython -Arguments @('scripts/cache_dense_targets.py')
    $poseArguments = @('scripts/run.py','--config','configs/improved.yaml','train-dense-pose','--epochs','24')
    if (-not $Retrain -and (Test-Path -LiteralPath 'artifacts/training/dense_pose/last.pt')) {
        $poseArguments += @('--resume','artifacts/training/dense_pose/last.pt')
    }
    Invoke-ImprovementPython -Arguments $poseArguments
}
Invoke-ImprovementPython -Arguments @('scripts/select_mask_refinement.py')
Invoke-ImprovementPython -Arguments @('scripts/run.py','--config','configs/improved.yaml','evaluate','--checkpoint','artifacts/training/improved_maskrcnn/best.pt','--split','test','--output','artifacts/evaluation/improved_maskrcnn_test.json')
Invoke-ImprovementPython -Arguments @('scripts/run.py','--config','configs/selected.yaml','evaluate','--checkpoint','artifacts/training/improved_maskrcnn/best.pt','--split','test','--output','artifacts/evaluation/selected_detector_test.json')
Invoke-ImprovementPython -Arguments @('scripts/run.py','--config','configs/selected.yaml','infer','--checkpoint','artifacts/training/improved_maskrcnn/best.pt','--pose-backend','dense_rgbd','--limit','923','--skip-cloud-export','--no-plots','--output','artifacts/benchmark/improved_full')
Invoke-ImprovementPython -Arguments @('scripts/run_experiments.py','--config','configs/selected.yaml','--checkpoint','artifacts/training/improved_maskrcnn/best.pt','--pose-backend','dense_rgbd','--limit','16','--output','artifacts/experiments/improved_ablations')
Invoke-ImprovementPython -Arguments @('scripts/reference_mesh_audit.py','--input','artifacts/experiments/ablations/predicted_mask','--output','reports/improvement/baseline_reference_mesh.json')
Invoke-ImprovementPython -Arguments @('scripts/validate_improvement.py')
Invoke-ImprovementPython -Arguments @('scripts/build_improvement_report.py')
Invoke-ImprovementPython -Arguments @('scripts/improvement_manifest.py')
