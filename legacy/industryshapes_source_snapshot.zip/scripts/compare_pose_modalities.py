"""Same detector and RGB keypoint model; compare with/without depth refinement."""
import argparse
from pathlib import Path
import sys
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from clutterpick.common import load_config,resolve,write_json
from clutterpick.data import load_index,select_frames
from clutterpick.detection import load_detector
from clutterpick.pipeline import run_frame


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint",required=True)
    p.add_argument("--pose-checkpoint",default="artifacts/training/rgb_pose/best.pt")
    p.add_argument("--limit",type=int,default=16)
    args = p.parse_args()
    torch.set_num_threads(4)
    config = load_config()
    index,splits = load_index(config)
    frames = select_frames(index,splits["test"],args.limit,config["seed"])
    detector = load_detector(resolve(args.checkpoint),config)
    rows = []
    runtime = {}
    for mode in ["rgb_keypoints","rgbd_keypoints"]:
        for frame in frames:
            output = resolve("artifacts/experiments/modalities")/mode/frame["key"].replace("/","_")
            result = run_frame(frame,config,detector,output,pose_backend=mode,pose_checkpoint=args.pose_checkpoint,plots=False,runtime=runtime)
            errors = result["pose_diagnostics"]
            rows.append({"mode":mode,"frame_key":frame["key"],"gt_instances":len(frame["instances"]),
                         "matched_instances":len(errors),"poses_ok":result["poses_ok"],
                         "ADD_m_mean":float(np.mean([e["ADD_m"] for e in errors])) if errors else None,
                         "ADD_S_m_mean":float(np.mean([e["ADD_S_m"] for e in errors])) if errors else None,
                         "ADD_success_0_1d":sum(e["ADD_success_0_1d"] and e["pose_status"]=="ok" for e in errors),
                         "ADD_S_success_0_1d":sum(e["ADD_S_success_0_1d"] and e["pose_status"]=="ok" for e in errors),
                         "exported_grasps":result["exported_grasps"],"timing":result["timing"]})
            write_json(resolve("artifacts/experiments/modalities/results.json"),rows)
            print(f"mode={mode} frame={frame['key']} matched={len(errors)}",flush=True)


if __name__=="__main__":
    main()
