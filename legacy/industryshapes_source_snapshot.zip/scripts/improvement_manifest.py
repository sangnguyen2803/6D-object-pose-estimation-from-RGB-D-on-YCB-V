"""Fingerprint source, splits, checkpoints and measured improvement artifacts."""
import hashlib
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parents[1]
paths = []
for folder, pattern in [('src', '*.py'), ('scripts', '*.py'), ('scripts', '*.ps1'),
                        ('tests', '*.py'), ('configs', '*.yaml'), ('docs', '*.md'),
                        ('reports/improvement', '*.json'), ('reports/improvement', '*.md')]:
    paths.extend((ROOT / folder).rglob(pattern))
paths.extend((ROOT / 'artifacts/evaluation').glob('*test.json'))
for name in ['README.md', 'pyproject.toml', 'requirements-measured.txt', 'data/improved_splits.json']:
    paths.append(ROOT / name)
for part in ['improved_maskrcnn', 'dense_pose']:
    paths.extend((ROOT / 'artifacts/training' / part).glob('*.pt'))
    paths.extend((ROOT / 'artifacts/training' / part).glob('history.json'))
for name in ['artifacts/benchmark/improved_full/run_summary.json',
             'artifacts/experiments/improved_ablations/results.json']:
    paths.append(ROOT / name)
target = ROOT / 'reports/improvement/artifact_manifest.json'
entries = []
for path in sorted(set(paths) - {target}):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    entries.append({'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
                    'sha256': digest.hexdigest()})
target.write_text(json.dumps({'python': platform.python_version(), 'platform': platform.platform(),
                             'dataset_revision': '39e2ccc49f7a3e258eab5cec84749c5817df417a',
                             'artifacts': entries}, indent=2), encoding='utf-8')
print(target)
