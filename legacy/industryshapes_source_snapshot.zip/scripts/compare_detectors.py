"""Compare detector effects with the same RGB-D pose/grasp backend and test frames."""
import argparse
import csv
from pathlib import Path
import sys
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from clutterpick.common import load_config,resolve,write_json
from clutterpick.data import load_index,select_frames
from clutterpick.detection import load_detector
from clutterpick.pipeline import run_frame


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit",type=int,default=16)
    args = parser.parse_args()
    torch.set_num_threads(4)
    config = load_config()
    index,splits = load_index(config)
    frames = select_frames(index,splits["test"],args.limit,config["seed"])
    directory = resolve("artifacts/experiments/detectors")
    rows,runtime = [],{}
    for architecture,checkpoint in [("maskrcnn","artifacts/training/maskrcnn/best.pt"),
                                    ("yolo","artifacts/training/yolo11n_seg/weights/best.pt")]:
        detector = load_detector(resolve(checkpoint),config,architecture=architecture)
        for frame in frames:
            result = run_frame(frame,config,detector,directory/architecture/frame["key"].replace("/","_"),
                               pose_backend="rgbd_keypoints",plots=False,runtime=runtime,export_clouds=False)
            errors = result["pose_diagnostics"]
            rows.append({"architecture":architecture,"frame_key":frame["key"],
                         "gt_instances":result["gt_instances"],"detections":result["detections"],
                         "matched_pose_estimates":len(errors),"poses_ok":result["poses_ok"],
                         "ADD_success_0_1d":sum(e["ADD_success_0_1d"] and e["pose_status"]=="ok" for e in errors),
                         "ADD_S_success_0_1d":sum(e["ADD_S_success_0_1d"] and e["pose_status"]=="ok" for e in errors),
                         "conditional_ADD_S_mm":float(np.mean([e["ADD_S_m"] for e in errors])*1000) if errors else None,
                         "exported_grasps":result["exported_grasps"],
                         "inference_seconds":result["timing"]["inference_s_before_reference_evaluation"]})
            write_json(directory/"results.json",rows)
            print(f"detector={architecture} frame={frame['key']} grasps={result['exported_grasps']}",flush=True)
        del detector
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    with (directory/"results.csv").open("w",encoding="utf-8",newline="") as handle:
        writer = csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__=="__main__":
    main()
