"""Apply the same strengthened reference checker to previously saved candidates."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from clutterpick.common import load_config,resolve,read_json,write_json
from clutterpick.data import load_index,select_frames
from clutterpick.pose import GeometricPoseEstimator
from run_experiments import independent_collision_check

parser = argparse.ArgumentParser()
parser.add_argument('--input',required=True)
parser.add_argument('--output',required=True)
parser.add_argument('--limit',type=int,default=16)
args = parser.parse_args()
config = load_config('configs/improved.yaml')
index,splits = load_index(config)
geometry = GeometricPoseEstimator(config)
frames = select_frames(index,splits['test'],args.limit,config['seed'])
rows = []
for frame in frames:
    directory = resolve(args.input)/frame['key'].replace('/','_')
    if not (directory/'grasps.json').exists():
        continue
    evaluation = independent_collision_check(frame,directory,config,geometry)
    rows.append({'frame_key':frame['key'],**evaluation})
    write_json(resolve(args.output),rows)
    print(frame['key'],evaluation['after_filter_topk'],flush=True)
