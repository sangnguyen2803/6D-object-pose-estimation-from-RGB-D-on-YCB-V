"""Controlled bbox/predicted-mask/reference-mask ablations on fixed test frames.

GT geometry appears ONLY in the evaluator after grasp candidates are generated.
Collision numbers remain surface-geometry proxies, not grasp success rates.
"""
import argparse
import copy
import csv
from pathlib import Path
import sys
import numpy as np
import torch
from scipy.spatial import cKDTree
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from clutterpick.common import load_config,resolve,read_json,write_json
from clutterpick.data import load_index,select_frames,load_rgbd
from clutterpick.detection import load_detector
from clutterpick.pipeline import run_frame
from clutterpick.pose import GeometricPoseEstimator
from clutterpick.geometry import backproject,transform_points,voxel_downsample
from clutterpick.collision import filter_candidates


def independent_collision_check(frame,directory,config,geometry):
    candidate_data = read_json(directory/"grasp_candidates.json")
    accepted_data = read_json(directory/"grasps.json")
    diagnostics = read_json(directory/"pose_diagnostics.json")["matched_instances"]
    predicted_to_gt = {d["instance_id"]:d["reference_instance_id"] for d in diagnostics}
    reference_objects = {o["instance_id"]:o for o in frame["instances"]}
    rgb,depth,k = load_rgbd(frame)
    placed,reference_meshes = {},{}
    for obj in frame["instances"]:
        mesh,model,_ = geometry.mesh(obj["obj_id"])
        truth = np.eye(4)
        truth[:3,:3] = np.array(obj["R_m2c"]).reshape(3,3)
        truth[:3,3] = np.array(obj["t_m2c_mm"])/1000
        placed[obj["instance_id"]] = transform_points(model,truth)
        reference_meshes[obj['instance_id']] = (mesh,truth)
    known,colliding,contact_support = {},{},{}
    for instance_id,gt_id in predicted_to_gt.items():
        target_mask = np.array(Image.open(reference_objects[gt_id]["mask_visib"]))>0
        obstacles,_ = backproject(depth,k,~target_mask,config["geometry"]["depth_min_m"],config["geometry"]["depth_max_m"])
        neighbors = [p for ident,p in placed.items() if ident!=gt_id]
        if neighbors:
            obstacles = np.concatenate([obstacles,*neighbors])
        obstacles = voxel_downsample(obstacles,config["geometry"]["voxel_size_m"])
        candidates = [g for g in candidate_data["candidates"] if g["target_instance_id"]==instance_id]
        check_config = copy.deepcopy(config)
        check_config["grasp"]["output_limit"] = len(candidates)+1
        mesh_mode = config['grasp'].get('collision_backend')=='mesh'
        if mesh_mode:
            from clutterpick.geometry import instance_cloud
            target_proxy,_,_ = instance_cloud(depth,k,target_mask,rgb,config)
        else:
            target_proxy = placed[gt_id]
        _,rejected,_ = filter_candidates(candidates,obstacles,target_proxy,check_config)
        if mesh_mode:
            from clutterpick.mesh_collision import MeshCollisionChecker
            rejected_ids = {g['grasp_id'] for g in rejected}
            checkers = {key:MeshCollisionChecker(mesh,pose) for key,(mesh,pose) in reference_meshes.items()}
            for candidate in candidates:
                if candidate['grasp_id'] in rejected_ids:
                    continue
                for key,checker in checkers.items():
                    reason = checker.reject_reason(candidate,check_config)
                    if reason:
                        rejected.append({'grasp_id':candidate['grasp_id'],'reason':('reference_target_' if key==gt_id else 'reference_neighbor_')+reason})
                        break
        target_tree = cKDTree(placed[gt_id])
        for g in candidates:
            known[g["grasp_id"]] = True
            distances,_ = target_tree.query(np.asarray(g["contacts_camera"]))
            contact_support[g["grasp_id"]] = bool(np.all(distances<.01))
        colliding.update({g["grasp_id"]:g["reason"] for g in rejected})
    def counts(grasps):
        evaluated = [g for g in grasps if g["grasp_id"] in known]
        count = sum(g["grasp_id"] in colliding for g in evaluated)
        return {"count":len(grasps),"evaluable_against_matched_gt":len(evaluated),"reference_collisions":count,
                "reference_contact_supported_10mm":sum(contact_support[g["grasp_id"]] for g in evaluated),
                "reference_collision_rate":count/len(evaluated) if evaluated else None}
    report = {"before_filter":counts(candidate_data["candidates"]),"after_filter_topk":counts(accepted_data["grasps"]),
              "geometry":"GT CAD placement plus observed non-target depth",
              "scope":"FCL swept boxes vs GT CAD triangles plus observed depth; no physics" if config['grasp'].get('collision_backend')=='mesh' else "same surface-check algorithm on independent reference geometry; unannotated hidden obstacles remain unknown; not physics validation"}
    filename = 'independent_mesh_collision_evaluation.json' if config['grasp'].get('collision_backend')=='mesh' else 'independent_collision_evaluation.json'
    write_json(directory/filename,report)
    return report


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config",default="configs/default.yaml")
    p.add_argument("--checkpoint",required=True)
    p.add_argument("--architecture",choices=["maskrcnn","yolo","rgbd_refined"],default=None)
    p.add_argument("--limit",type=int,default=16)
    p.add_argument("--output",default="artifacts/experiments/ablations")
    p.add_argument('--pose-backend')
    p.add_argument('--pose-checkpoint')
    p.add_argument('--split',choices=['val','test'],default='test')
    args = p.parse_args()
    torch.set_num_threads(4)
    config = load_config(args.config)
    index,splits = load_index(config)
    if args.split=='val' and config['data'].get('include_pbr_in_training',False):
        from clutterpick.dense_pose import balanced_validation_frames
        frames = balanced_validation_frames(index,splits,args.limit,config['seed'])
    else:
        frames = select_frames(index,splits[args.split],args.limit,config["seed"])
    detector = load_detector(resolve(args.checkpoint),config,architecture=args.architecture)
    geometry = GeometricPoseEstimator(config)
    rows = []
    runtime = {}
    for mode,oracle,extraction in [("predicted_mask",False,"mask"),("bbox",False,"bbox"),("reference_mask",True,"mask")]:
        for frame in frames:
            out = resolve(args.output)/mode/frame["key"].replace("/","_")
            result = run_frame(frame,config,detector,out,oracle,plots=False,depth_extraction=extraction,runtime=runtime,
                               pose_backend=args.pose_backend,pose_checkpoint=args.pose_checkpoint,export_clouds=False)
            evaluation = independent_collision_check(frame,out,config,geometry)
            errors = result["pose_diagnostics"]
            point_errors = read_json(out/"geometry_diagnostics.json")["instances"]
            contamination = [e["point_contamination_fraction"] for e in point_errors if e["point_contamination_fraction"] is not None]
            row = {"mode":mode,"frame_key":frame["key"],"gt_instances":len(frame["instances"]),
                "detections":result["detections"],"matched_instances":len(errors),"poses_ok":result["poses_ok"],
                "generated_candidates":result["candidate_count"],"exported_grasps":result["exported_grasps"],
                "ADD_mm_mean":np.mean([e["ADD_m"]*1000 for e in errors]) if errors else None,
                "ADD_S_mm_mean":np.mean([e["ADD_S_m"]*1000 for e in errors]) if errors else None,
                "pipeline_seconds":result["timing"]["inference_s_before_reference_evaluation"],
                "collision_before":evaluation["before_filter"]["reference_collisions"],
                "collision_after":evaluation["after_filter_topk"]["reference_collisions"],
                "evaluable_candidates_before":evaluation["before_filter"]["evaluable_against_matched_gt"],
                "evaluable_candidates_after":evaluation["after_filter_topk"]["evaluable_against_matched_gt"]}
            row["contact_supported_after_10mm"] = evaluation["after_filter_topk"]["reference_contact_supported_10mm"]
            row["point_contamination_fraction_mean"] = float(np.mean(contamination)) if contamination else None
            grasp_output = read_json(out/"grasps.json")
            row["collision_input_candidates"] = sum(s.get("collision_input_candidates",0) for s in grasp_output["instance_summaries"])
            row["collision_accepted_candidates_before_topk"] = sum(s.get("accepted",0) for s in grasp_output["instance_summaries"])
            rows.append(row)
            write_json(resolve(args.output)/"results.json",rows)
            print(f"mode={mode} frame={frame['key']} grasps={result['exported_grasps']}",flush=True)
    path = resolve(args.output)/"results.csv"
    with path.open("w",newline="",encoding="utf-8") as f:
        writer = csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


if __name__=="__main__":
    main()
