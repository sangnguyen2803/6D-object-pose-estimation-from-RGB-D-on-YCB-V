"""Download pinned BOP archives, verify SHA256, and safely extract on D/workspace."""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path
import zipfile
import time
import requests

ROOT = Path(__file__).resolve().parents[1]
REVISION = "39e2ccc49f7a3e258eab5cec84749c5817df417a"
GROUPS = {"classic": ["Classic_train", "Classic_test", "cad_models"],
          "extended": ["Extended_test"], "onboarding": ["Onboardings_static"],
          "pbr": ["PBR_train_random", "PBR_train_upright", "textured_cad_models"],
          "pbr-upright": ["PBR_train_upright"]}


def download(entry, revision, destination):
    folder = destination / "downloads"
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / Path(entry["path"]).name
    expected = entry["lfs"]["oid"]
    if not archive.exists() or archive.stat().st_size != entry["size"]:
        partial = archive.with_suffix(".zip.part")
        url = f"https://huggingface.co/datasets/POSE-Lab/IndustryShapes/resolve/{revision}/{entry['path']}"
        for attempt in range(5):
            offset = partial.stat().st_size if partial.exists() else 0
            if offset==entry['size']:
                break
            try:
                headers = {'Range':f'bytes={offset}-'} if offset else {}
                with requests.get(url,headers=headers,params={'resume_offset':offset},stream=True,timeout=(30,120)) as response:
                    response.raise_for_status()
                    append = offset>0 and response.status_code==206
                    if append and not response.headers.get('Content-Range','').startswith(f'bytes {offset}-'):
                        raise ValueError('Incorrect resume range')
                    if not append:
                        offset=0
                    received=offset
                    last_progress=received
                    with partial.open('ab' if append else 'wb') as f:
                        for chunk in response.iter_content(4*1024*1024):
                            f.write(chunk); received+=len(chunk)
                            if received-last_progress>=128*1024*1024:
                                print(f'{archive.name}: {received/1e9:.2f}/{entry["size"]/1e9:.2f} GB',flush=True)
                                last_progress=received
                if partial.stat().st_size!=entry['size']:
                    raise IOError('Archive transfer incomplete')
                break
            except (requests.RequestException,IOError) as error:
                if attempt==4:
                    raise
                print(f'Resuming {archive.name} after {type(error).__name__}',flush=True)
                time.sleep(min(2**attempt,8))
        partial.replace(archive)
    sha = hashlib.sha256()
    with archive.open("rb") as f:
        for chunk in iter(lambda: f.read(4*1024*1024), b""):
            sha.update(chunk)
    if sha.hexdigest() != expected:
        raise ValueError(f"Checksum mismatch: {archive}")
    out = (destination / "raw").resolve()
    out.mkdir(parents=True, exist_ok=True)
    marker = out / (archive.stem + ".extracted.json")
    if not marker.exists():
        with zipfile.ZipFile(archive) as z:
            for member in z.infolist():
                target = (out / member.filename).resolve()
                if not target.is_relative_to(out):
                    raise ValueError("Unsafe ZIP member")
                if ((member.external_attr >> 16) & 0o170000) == 0o120000:
                    raise ValueError("Symlink in dataset ZIP")
            z.extractall(out)
        marker.write_text(json.dumps({"revision": revision, "sha256": expected}), encoding="utf-8")
    print(f"Verified and extracted: {archive.name}", flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--groups", nargs="+", choices=list(GROUPS), default=["classic"])
    p.add_argument("--revision", default=REVISION)
    p.add_argument("--destination", type=Path, default=ROOT / "data")
    args = p.parse_args()
    response = requests.get(f"https://huggingface.co/api/datasets/POSE-Lab/IndustryShapes/tree/{args.revision}",
                            params={"recursive": "true", "expand": "false"}, timeout=30)
    response.raise_for_status()
    entries = response.json()
    needed = {f"IndustryShapes_{name}.zip" for group in args.groups for name in GROUPS[group]}
    chosen = [x for x in entries if Path(x["path"]).name in needed]
    if len(chosen) != len(needed):
        raise ValueError("Requested archives missing from pinned revision")
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(download, x, args.revision, args.destination) for x in chosen]
        for future in concurrent.futures.as_completed(futures):
            future.result()


if __name__ == "__main__":
    main()
