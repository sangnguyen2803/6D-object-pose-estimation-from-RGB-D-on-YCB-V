"""Decode the downloaded corpus and inspect cross-split duplicate RGB files."""
import concurrent.futures
import hashlib
import io
import argparse
from pathlib import Path
import sys
import numpy as np
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from clutterpick.common import load_config,resolve,write_json
from clutterpick.data import load_index


def check_frame(frame):
    rgb_bytes = Path(frame["rgb"]).read_bytes()
    rgb = np.array(Image.open(io.BytesIO(rgb_bytes)).convert("RGB"))
    depth = np.array(Image.open(frame["depth"]))
    if depth.dtype!=np.uint16 or depth.shape!=rgb.shape[:2]:
        raise ValueError("Depth type or alignment dimensions invalid")
    for obj in frame["instances"]:
        visible = np.array(Image.open(obj["mask_visib"]))>0
        full = np.array(Image.open(obj["mask"]))>0
        if visible.shape!=depth.shape or full.shape!=depth.shape:
            raise ValueError("Mask dimensions mismatch")
        if np.any(visible & ~full):
            raise ValueError("Visible mask not contained in projected full mask")
    return {"key":frame["key"],"group":frame["group"],"rgb_sha256":hashlib.sha256(rgb_bytes).hexdigest(),
            "invalid_depth_fraction":float((depth==0).mean()),"instances":len(frame["instances"])}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config',default='configs/default.yaml')
    parser.add_argument('--output',default='reports/local_data_audit.json')
    args = parser.parse_args()
    config = load_config(args.config)
    index,_ = load_index(config)
    results,errors = [],[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs = {pool.submit(check_frame,f):f["key"] for f in index["frames"]}
        for future in concurrent.futures.as_completed(jobs):
            try:
                results.append(future.result())
            except Exception as e:
                errors.append({"frame_key":jobs[future],"error":repr(e)})
    duplicates = {}
    for record in results:
        duplicates.setdefault(record["rgb_sha256"],[]).append(record["key"])
    duplicates = [frames for frames in duplicates.values() if len(frames)>1]
    across = [frames for frames in duplicates if len({f.split('/')[0] for f in frames})>1]
    report = {"decoded_frames":len(results),"decoded_instances":sum(r["instances"] for r in results),
              "errors":errors,"duplicate_rgb_groups":duplicates,"cross_group_duplicate_rgb_groups":across,
              "invalid_depth_fraction_mean":float(np.mean([r["invalid_depth_fraction"] for r in results])),
              "scope":"exact compressed RGB SHA256, not perceptual near-duplicate detection; RGB/depth/masks fully decoded"}
    write_json(resolve(args.output),report)
    print({k:v for k,v in report.items() if 'groups' not in k},flush=True)
    if errors:
        raise SystemExit(1)


if __name__=="__main__":
    main()
