"""Validation-only oracle-pose control for grasp generation and surface checks."""
import json
import argparse
from collections import Counter
from pathlib import Path
import sys
import numpy as np
from scipy.spatial import cKDTree
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from clutterpick.common import load_config,write_json,resolve
from clutterpick.data import load_index,select_frames,load_rgbd
from clutterpick.pose import GeometricPoseEstimator
from clutterpick.geometry import transform_points,backproject,voxel_downsample,instance_cloud
from clutterpick.grasp import generate_candidates,require_observed_contact
from clutterpick.collision import filter_candidates
from PIL import Image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config",default="configs/default.yaml")
    parser.add_argument("--output",default="reports/improvement/collision_oracle_pose_control.json")
    parser.add_argument("--baseline-index",action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    if args.baseline_index:
        config['data']['index'] = 'data/index.json'
        config['data']['splits'] = 'data/splits.json'
    index,splits = load_index(config)
    frames = select_frames(index,splits["val"],10,config["seed"])
    geometry = GeometricPoseEstimator(config)
    rows = []
    for frame in frames:
        rgb,depth,k = load_rgbd(frame)
        placed = {}
        for obj in frame["instances"]:
            truth = np.eye(4)
            truth[:3,:3] = np.asarray(obj["R_m2c"]).reshape(3,3)
            truth[:3,3] = np.asarray(obj["t_m2c_mm"])/1000
            mesh,model,_ = geometry.mesh(obj["obj_id"])
            placed[obj["instance_id"]] = (mesh,truth,transform_points(model,truth))
        for obj in frame["instances"]:
            mesh,truth,target = placed[obj["instance_id"]]
            mask = np.asarray(Image.open(obj["mask_visib"]))>0
            observed,_,_ = instance_cloud(depth,k,mask,rgb,config)
            obstacles,_ = backproject(depth,k,~mask,.1,2.)
            other = [value[2] for key,value in placed.items() if key!=obj["instance_id"]]
            if other:
                obstacles = np.concatenate([obstacles,*other])
            obstacles = voxel_downsample(obstacles,.003)
            candidates = generate_candidates(mesh,truth,obj["instance_id"],config,observed)
            candidates,rejected_support = require_observed_contact(candidates,observed,config['grasp'].get('observed_contact_tolerance_m',.02))
            import copy
            collision_config = copy.deepcopy(config)
            collision_config['grasp']['output_limit'] = len(candidates)+1
            target_proxy = observed if config['grasp'].get('collision_backend')=='mesh' else target
            accepted,rejected,count = filter_candidates(candidates,obstacles,target_proxy,collision_config)
            if config['grasp'].get('collision_backend')=='mesh' and accepted:
                from clutterpick.mesh_collision import filter_mesh_candidates
                accepted,extra = filter_mesh_candidates(accepted,mesh,truth,config)
                rejected += extra
                from clutterpick.mesh_collision import MeshCollisionChecker
                for identifier,(neighbor_mesh,neighbor_pose,_) in placed.items():
                    if identifier==obj['instance_id'] or not accepted:
                        continue
                    checker = MeshCollisionChecker(neighbor_mesh,neighbor_pose)
                    keep = []
                    for candidate in accepted:
                        reason = checker.reject_reason(candidate,config)
                        if reason:
                            rejected.append({'grasp_id':candidate['grasp_id'],'reason':'reference_neighbor_'+reason})
                        else:
                            keep.append(candidate)
                    accepted = keep
                count = len(accepted)
            distances,_ = cKDTree(target).query(observed) if len(observed) else (np.array([]),None)
            row = {"frame_key":frame["key"],"obj_id":obj["obj_id"],"generated_supported":len(candidates),
                   "accepted_before_topk":count,"rejections":dict(Counter(r["reason"] for r in rejected)),
                   "support_rejections":len(rejected_support),
                   "median_observed_to_gt_cad_mm":float(np.median(distances)*1000) if len(distances) else None,
                   "scope":"validation-only GT pose control, never ordinary prediction"}
            rows.append(row)
            write_json(resolve(args.output),rows)
            print(json.dumps(row),flush=True)


if __name__=="__main__":
    main()
