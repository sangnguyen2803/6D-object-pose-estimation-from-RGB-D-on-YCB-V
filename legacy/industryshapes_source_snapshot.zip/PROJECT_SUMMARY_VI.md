# Tổng hợp đồ án ClutterPick và kết quả hiện tại

**Tên đề tài:** RGB-D 3D Perception and 6-DoF Grasp Planning for Occluded Industrial Components.  
**Ngày tổng hợp:** 12/10/2026.  
**Dữ liệu chính:** IndustryShapes, 5 lớp vật thể.  
**Trạng thái:** baseline đã huấn luyện và đánh giá; lượt cải thiện đang thực hiện.

Tài liệu này là bản tổng hợp tại thời điểm viết, dựa trên checkpoint, history và
artifact đã có trong project. Các job đang chạy có thể cập nhật kết quả sau thời
điểm này; xem các file history và báo cáo nguồn để lấy số mới nhất.

**Cập nhật sau bản tổng hợp ban đầu:** theo yêu cầu, đã dừng epoch 12 đang dở.
Detector hoàn tất 11 epoch và sử dụng best checkpoint **epoch 6**, weighted
validation mask AP **57,37%**. Không chạy tiếp epoch 12. Xem
[quyết định chọn checkpoint](reports/improvement/detector_training_decision.json).
Các bảng tiến độ 8 epoch bên dưới là snapshot ban đầu, không phải trạng thái mới nhất.

Checkpoint epoch 6 đã được đánh giá trên đủ 923 ảnh test: **box AP50:95
54,53%**, **mask AP50:95 32,09%**, **mask AP50 59,86%**. Baseline mask AP50:95
là 27,63%; chênh lệch +4,46 điểm phần trăm. Xem
[test evaluation mới](artifacts/evaluation/improved_maskrcnn_test.json).
Toàn bộ 23 tests đã passed; GPU forward/backward của dense model trên 16
instances thuộc Classic/onboarding/PBR đã passed. Dense RGB-D pose đang train
riêng; chưa có downstream pose/grasp benchmark mới tại thời điểm cập nhật này.

## 1. Kết quả chính và mức độ hoàn thành

Project đã có pipeline offline nhận RGB, depth và camera intrinsics, phát hiện
từng instance, dựng point cloud, ước lượng pose và xuất grasp candidates sau
kiểm tra va chạm. Baseline đã chạy trên toàn bộ **923 ảnh Classic Test, gồm
1.931 instance**.

| Nội dung | Kết quả baseline đã đo |
|---|---:|
| Mask R-CNN detection AP50:95 | 42,37% |
| Mask R-CNN mask AP50:95 | 27,63% |
| Mask R-CNN mask AP50 | 48,02% |
| Pose ADD recall tại ngưỡng 0,1 đường kính | 13,31% |
| Pose ADD-S recall tại ngưỡng 0,1 đường kính | 32,47% |
| Ảnh có grasp candidate sau lọc | 192/923 — 20,80% |
| Tổng grasp candidates được xuất sau lọc | 377 |
| Thời gian inference pipeline trung vị | 0,768 giây/ảnh |

**Đánh giá hiện tại:** pipeline đã chạy và có đầu ra đầy đủ, nhưng chất lượng
pose và grasp còn thấp. Trong thí nghiệm riêng trên 16 ảnh với predicted masks,
**9/9 candidate được xuất bị evaluator hình học tham chiếu đánh dấu va chạm**.
Đây là kết quả trên subset nhỏ, không phải phép đo va chạm của toàn bộ 377
candidate, và cũng không phải thử nghiệm robot.

Lượt cải thiện đã hoàn tất **8/12 epoch detector**; log đang ở epoch 9.
Weighted validation mask AP tốt nhất là **57,37% tại epoch 6**. Chưa có kết quả
test đầy đủ của model cải thiện, chưa có checkpoint dense pose đã huấn luyện
và chưa có kết quả mô phỏng hoặc gắp thực tế.

## 2. Mục tiêu và phạm vi đồ án

Mục tiêu là nghiên cứu cách kết hợp instance segmentation và hình học RGB-D
để định vị vật thể công nghiệp trong cảnh có che khuất, sau đó tạo grasp
candidates có kiểm tra va chạm.

Các câu hỏi nghiên cứu được triển khai:

1. Mask R-CNN tách từng vật thể tốt đến mức nào, so với YOLO segmentation?
2. Dùng mask thay bounding box có giảm lẫn point cloud và cải thiện pose không?
3. Bổ sung depth refinement có giúp pose so với RGB/PnP không?
4. Bộ lọc va chạm loại candidate thế nào, và candidate còn lại có vượt kiểm tra tham chiếu không?
5. Detector ảnh hưởng đến pose, số ảnh có candidate và thời gian toàn pipeline ra sao?

Phạm vi hiện tại là perception và grasp planning **offline trong camera frame**.
Project chưa có controller robot, camera-to-base calibration, robot URDF,
inverse kinematics hay thực thi thao tác đóng ngón và nâng vật.

## 3. Dataset, annotation và kiểm tra dữ liệu

### 3.1. Dữ liệu sử dụng

Dataset được tải từ IndustryShapes tại revision cố định:

```text
39e2ccc49f7a3e258eab5cec84749c5817df417a
```

Loader dùng BOP format, giữ từng instance kể cả khi nhiều vật cùng class xuất
hiện trong một ảnh. Các annotation đã xác minh gồm:

| Dữ liệu | Cách sử dụng |
|---|---|
| RGB và registered depth | Input perception, back-projection và refinement |
| Camera intrinsics K | Đưa pixel/depth về tọa độ camera 3D |
| Class và instance identity | Supervision detection, giữ riêng từng vật |
| `mask_visib` | Visible mask cho segmentation và đánh giá |
| `mask` | Full object mask trong dữ liệu; không đồng nghĩa có depth bề mặt khuất |
| Bounding boxes, visibility | Detection targets và phân nhóm độ che khuất |
| CAD models | Pose registration, kích thước và grasp geometry |
| Reference 6-DoF poses | Supervision pose và đánh giá sau inference |

**Không có nhãn grasp ground truth.** Grasp được đề xuất bằng hình học, không
có grasp network đã huấn luyện. Project cũng chưa huấn luyện PointNet++ hoặc
mô hình point-wise 3D instance segmentation.

### 3.2. Đơn vị và hệ tọa độ

- Depth: `Z_m = raw_depth × depth_scale_mm / 1000`.
- Classic dùng scale 1 mm; onboarding/PBR dùng scale 0,1 mm ở các nguồn đã kiểm tra.
- CAD và annotation translation được chuyển từ mm sang m.
- Camera frame BOP/OpenCV: X sang phải, Y xuống dưới, Z hướng về phía trước.
- Pose object-to-camera: `p_camera = R × p_object + t`.
- Gripper frame: X là trục đóng ngón, Z là hướng approach; origin tại tâm contact.

Back-projection:

```text
X = (u - cx) × Z / fx
Y = (v - cy) × Z / fy
```

Depth thiếu hoặc nằm ngoài khoảng 0,1–2,0 m bị loại. Point cloud theo instance
chỉ biểu diễn phần bề mặt có depth quan sát được, chưa phải tái tạo đầy đủ vật
bị che.

### 3.3. Split baseline

| Split | Số ảnh | Ghi chú |
|---|---:|---|
| Train | 1.792 | Từ Classic Train |
| Validation | 1.908 | Tách theo scene |
| Test | 923 | Giữ nguyên Classic Test chính thức |

Classic Train gốc có 3.700 ảnh. Validation scenes là `000001`, `000003`,
`000009`, `000011`, `000013`. Object 3 có training real và validation synthetic,
nên có thay đổi miền dữ liệu và mất cân bằng class. Không trộn ngẫu nhiên các
frame cùng scene giữa train và validation.

Có **82 pose annotation training** vượt ngưỡng lỗi trực chuẩn rotation.
Dữ liệu gốc được giữ nguyên và ghi diagnostic; các instance này bị loại khỏi
pose supervision, vẫn có thể dùng cho detector training.

### 3.4. Dữ liệu bổ sung cho lượt cải thiện

Đã tải và kiểm tra thêm onboarding và 10 scene PBR upright. Pixel audit đã đọc
**20.932 frame và 62.153 instance**, không ghi nhận lỗi file trong corpus được
kiểm tra. Không có exact RGB duplicates giữa train/validation/test. Đã loại
617 RGB frames lặp trong training.

| Split cải thiện | Số ảnh | Thành phần |
|---|---:|---|
| Train | 15.484 | 1.792 Classic + 5.692 onboarding + 8.000 PBR |
| Validation | 3.908 | 1.908 Classic + 2.000 PBR |
| Test | 923 | Classic Test giữ nguyên |

PBR scenes `000008` và `000009` chỉ dùng cho validation. Train pool mới có
8.213 frame nhiều vật thể. PBR clutter là dữ liệu synthetic; chưa có thêm bộ
real clutter validation độc lập. Exact duplicate audit không chứng minh đã
loại toàn bộ ảnh gần giống nhau.

Nguồn: [data split](reports/improvement/data_split.json),
[pixel audit](reports/improvement/local_data_audit.json),
[feasibility audit](audit/FEASIBILITY_VI.md).

## 4. Kiến trúc pipeline baseline đã đánh giá

```mermaid
flowchart TD
    A[RGB + registered depth + K] --> B[Mask R-CNN / YOLO segmentation]
    B --> C[Class + score + bbox + visible mask]
    C --> D[Valid depth selection + back-projection]
    D --> E[Per-instance point cloud]
    C --> F[RGB CAD corners regression + PnP]
    E --> G[Trimmed depth ICP]
    F --> G
    G --> H[Estimated object pose + fit diagnostics]
    H --> I[Antipodal CAD grasp candidates]
    E --> I
    I --> J[Observed contact support]
    J --> K[Finger + palm + approach collision filtering]
    K --> L[Ranked candidates / no feasible candidate]
    L -.-> M[Reference evaluation after inference]
    N[GT masks and poses] -.-> M
```

GT annotations được dùng làm training targets hoặc trong evaluator sau
inference. Chế độ `--oracle-masks` là ngoại lệ chẩn đoán có đánh dấu rõ, không
được tính là prediction bình thường.

### 4.1. Detection và instance segmentation

Primary model là Mask R-CNN ResNet-50/FPN, fine-tune từ pretrained COCO.
YOLO11n-seg pretrained là speed baseline. Output gồm class, confidence,
bounding box và visible mask cho từng detection.

COCO AP evaluation dùng confidence floor **0,05**; inference để lập grasp dùng
**0,5**. Hai model được giới hạn tối đa 30 detections/frame khi đánh giá cuối.
Mask R-CNN dùng min/max image size 480/640.

### 4.2. Point cloud

Mask chọn các pixel depth thuộc instance, sau đó back-project bằng K. Pipeline
lọc depth không hợp lệ, xử lý biên mask và voxel downsample 3 mm. Scene point
cloud và từng object có thể xuất thành PLY, đơn vị m.

Point contamination được chẩn đoán bằng cách chiếu các points giữ lại lên GT
visible mask sau inference. Chỉ số này không đo đầy đủ phần bề mặt bị thiếu.

### 4.3. Pose 6-DoF

Full benchmark sử dụng backend **`rgbd_keypoints`**:

1. ResNet-18 dự đoán ảnh chiếu của 8 góc bounding box CAD từ RGB crop và class.
2. PnP dùng các điểm CAD, keypoints và K để dựng pose ban đầu.
3. Trimmed ICP dùng depth của instance để refine pose.

Backend hình học `geometric` dùng CAD registration đa khởi tạo; có thêm
FPFH/render-and-compare tùy chọn. `configs/default.yaml` mặc định là
`geometric`; lệnh benchmark đầy đủ ghi rõ override `--pose-backend rgbd_keypoints`.

FoundationPose có adapter nhưng **chưa chạy được trong môi trường hiện tại**.
Chưa hoàn thành đối chiếu bằng official pose baseline và official BOP metrics.
Pose status `ok` nghĩa là vượt tiêu chí fit của backend, không xác nhận đúng
reference pose; ICP có thể fit tốt một phần bề mặt nhưng orientation sai.

### 4.4. Grasp generation, collision và ranking

Baseline tạo cặp contact antipodal trên CAD, ưu tiên vùng gần depth của vật,
thử các roll và giới hạn opening theo gripper. Trước collision filtering,
candidate cần ít nhất một contact gần observed target depth trong 20 mm.

Gripper giả định có opening tối đa 85 mm, finger thickness 8 mm, finger depth
20 mm, finger length 45 mm và friction coefficient 0,5. Đây là tham số cấu
hình, chưa hiệu chuẩn với một gripper vật lý cụ thể.

Bộ lọc baseline kiểm tra fingers, palm, target body và 12 vị trí trên approach
dài 80 mm. Scene obstacles lấy từ depth ngoài target mask; clearance margin
4 mm. Ranking kết hợp contact, clearance và accessibility với weights
0,45/0,35/0,20; xuất tối đa 10 candidate/instance.

Kiểm tra hiện tại chưa xác minh force closure, đóng ngón động, lực nâng, robot
reachability hoặc geometry chưa quan sát. `no_feasible_candidate` là đầu ra hợp lệ.

## 5. Huấn luyện baseline và giao thức đánh giá

| Model | Training | Checkpoint selection |
|---|---|---|
| Mask R-CNN | 8 epoch trên 1.792 train images; effective batch 2 | Best epoch 7; mask AP trên 100 validation frames cố định = 47,07% |
| YOLO11n-seg | 8 epoch, cùng scene split | Native validation trên 1.908 frames |
| RGB CAD corners/PnP | 12 epoch | Best epoch 11; normalized keypoint RMSE = 0,2674 |

Normalized keypoint RMSE không phải pose accuracy 6D. Test không được dùng để
chọn checkpoint. Mask R-CNN và YOLO khác architecture, optimizer, augmentation
và input resolution; kết quả là so sánh hai baseline thực dụng, chưa cô lập
hoàn toàn ảnh hưởng của architecture. YOLO polygon training không biểu diễn
đầy đủ mask holes, nhưng evaluation cuối dùng cùng BOP visible masks gốc.

ADD dùng khoảng cách giữa các CAD vertices tương ứng sau transformation.
ADD-S dùng nearest-neighbor distance. Diagnostic threshold là **10% đường
kính CAD**. Với mesh lớn, evaluator dùng tối đa 10.000 vertices lấy mẫu xác định.
Symmetry metadata chưa được xác minh đầy đủ; các số ADD/ADD-S là diagnostic,
**chưa phải official BOP AR**. End-to-end recall tính missed detections và
failed/poor-fit poses là failures trong mẫu số tất cả GT instances.

## 6. Kết quả detection và segmentation trên toàn bộ test

### 6.1. Kết quả tổng

| Model | Box AP50:95 | Mask AP50:95 | Mask AP50 | Median detector latency |
|---|---:|---:|---:|---:|
| Mask R-CNN | 42,37% | 27,63% | 48,02% | 88,8 ms/ảnh |
| YOLO11n-seg | 36,95% | 24,05% | 40,38% | 20,0 ms/ảnh |

Mask R-CNN có AP cao hơn trong phép đo hiện tại; YOLO có detector latency thấp
hơn khoảng 4,4 lần. Đối với Mask R-CNN, tại mask IoU ≥0,5 và score ≥0,5,
precision khoảng **67,52%**, recall **64,47%**, F1 **65,96%**. Mean IoU của
các mask ghép thành công là **77,39%**; đây là giá trị conditional, không tính
missed detections như IoU bằng 0.

### 6.2. Mask AP50:95 theo class

| Model | Object 1 | Object 2 | Object 3 | Object 4 | Object 5 |
|---|---:|---:|---:|---:|---:|
| Mask R-CNN | 66,06% | 33,24% | 34,39% | 4,44% | 0,0071% |
| YOLO11n-seg | 69,89% | 3,96% | 32,09% | 14,33% | 0,00% |

Class 4 và đặc biệt class 5 là điểm yếu lớn. AP tổng không thể hiện đầy đủ sự
chênh lệch này; không thể dùng kết quả tổng để khẳng định cả 5 lớp đều tốt.

### 6.3. Recall theo visibility của Mask R-CNN

| Tỷ lệ vật nhìn thấy | Instance ghép được / GT | Recall |
|---|---:|---:|
| 0–25% | 0/23 | 0,00% |
| 25–50% | 20/102 | 19,61% |
| 50–75% | 48/146 | 32,88% |
| 75–100% | 1.177/1.660 | 70,90% |

Điều kiện ghép là cùng class, mask IoU ≥0,5 và score ≥0,5. Nhóm che khuất nặng
có ít mẫu; class/domain cũng có thể tác động, nên chưa quy toàn bộ chênh lệch
recall cho occlusion.

## 7. Kết quả pose và grasp của full pipeline

Full benchmark dùng Mask R-CNN + RGB CAD corners/PnP + depth ICP:

| Chỉ số | Giá trị |
|---|---:|
| Test frames / GT instances | 923 / 1.931 |
| Detections và pose records được xuất | 1.844 |
| Matched pose diagnostics có transform | 1.124 |
| ADD recall @0,1d | 13,31% |
| ADD-S recall @0,1d | 32,47% |
| Mean conditional ADD-S | 76,88 mm |
| Frames có candidate sau lọc | 192/923 |
| Exported candidates | 377 |
| Median inference | 0,768 giây/ảnh |

Pose records gồm cả failure status; không phải cả 1.844 records đều là pose
đúng hoặc pose thành công. Mean conditional ADD-S chỉ xét estimate đã ghép,
cần đọc cùng end-to-end recall để tránh bỏ qua misses.

Timing từ đọc RGB-D đến lọc grasp, loại reference evaluation và visualization;
benchmark bỏ PLY export, vẫn tính input/mask IO. **Candidate availability
20,80% không phải grasp success rate.**

Nguồn: [full run summary](artifacts/benchmark/rgbd_full/run_summary.json),
[delivery validation](reports/delivery_validation.json).

## 8. Thí nghiệm downstream trên cùng 16 ảnh

### 8.1. Bounding box, predicted mask và reference mask

Thí nghiệm này dùng pose backend hình học theo cấu hình mặc định; không đồng
nhất với full benchmark RGB keypoints + ICP. Các error trong bảng là
conditional mean theo frame, không phải recall toàn test.

| Input geometry | Point contamination | Frame có candidate | Mean conditional frame ADD-S | Reference collision sau lọc |
|---|---:|---:|---:|---:|
| Bounding box | 62,5% | 0/16 | 18,7 mm | N/A — không có candidate |
| Predicted mask | 30,8% | 5/16 | 19,1 mm | 9/9 |
| Reference mask | 0,0% | 1/16 | 29,3 mm | 1/1 |

Mask giảm lẫn point cloud trong subset này, nhưng chưa chứng minh grasp tốt.
Reference-mask row là oracle diagnostic. Với predicted masks, bộ lọc loại
khoảng 99,4% candidate đưa vào kiểm tra nhưng 9 candidate còn lại vẫn bị
reference evaluator đánh dấu va chạm. Chỉ **4/9 candidate** có cả hai contact
trong 10 mm so với sampled reference CAD.

Evaluator dùng GT CAD placement và observed depth **sau planning**, cùng
thuật toán sampled-surface/approach checks của baseline. Đây là chẩn đoán
hình học tham chiếu, chưa phải simulator hoặc chứng minh an toàn vật lý.

### 8.2. RGB pose so với RGB-D refinement

| Backend | Mean conditional frame ADD-S | ADD recall | ADD-S recall |
|---|---:|---:|---:|
| RGB keypoints/PnP | 144,4 mm | 5,71% | 14,29% |
| RGB keypoints/PnP + depth ICP | 127,6 mm | 14,29% | 31,43% |

Hai cấu hình dùng cùng detector và keypoint checkpoint. Depth ICP cải thiện
pose trên subset được đo, nhưng grasp/collision vẫn dùng depth trong cả hai;
không gọi đây là so sánh toàn pipeline RGB-only với RGB-D.

### 8.3. Ảnh hưởng của detector đến pipeline RGB-D

| Detector | ADD recall | ADD-S recall | Frame có candidate | Median pipeline latency |
|---|---:|---:|---:|---:|
| Mask R-CNN | 14,29% | 31,43% | 3/16 | 0,492 giây |
| YOLO11n-seg | 11,43% | 20,00% | 5/16 | 0,190 giây |

Hai detector dùng cùng RGB-D pose backend và gripper config. YOLO tạo
candidate ở nhiều frame hơn trong subset, nhưng số candidate không xác nhận
chất lượng gắp. Subset nhỏ, chưa có nhiều lần chạy để kết luận thống kê mạnh.

Nguồn: [ablations](artifacts/experiments/ablations/results.json),
[pose modalities](artifacts/experiments/modalities/results.json),
[detector comparison](artifacts/experiments/detectors/results.json).

## 9. Các vấn đề chính được phát hiện

1. **Training baseline ít cảnh clutter và có domain shift.** Baseline chưa có
   PBR/onboarding trong training; Classic validation mất cân bằng và object 3
   thay đổi miền real/synthetic.
2. **Class 4/5 segmentation yếu.** Một số ví dụ class 5 là vật trắng trên nền
   trắng, khó phân biệt bằng RGB. Đây là quan sát chẩn đoán; chưa có thí nghiệm
   cô lập chứng minh đây là nguyên nhân duy nhất.
3. **Sai mask gây lẫn depth.** Point cloud có background hoặc vật bên cạnh,
   làm pose registration và grasp geometry kém chính xác.
4. **Pose là nút thắt lớn.** Keypoint/PnP ban đầu yếu; ICP trên partial geometry
   có thể vào local optimum hoặc orientation sai dù residual nhỏ.
5. **Grasp filter chưa đủ đáng tin cậy.** Geometry được đặt theo pose dự đoán,
   sampled surfaces và approach rời rạc có thể bỏ sót va chạm. Contact support
   một phía không xác nhận hai ngón kẹp được vật.
6. **Chưa có xác minh thực thi.** Không có simulated/physical grasp success,
   robot kinematics, lực, friction đã hiệu chuẩn hoặc thao tác đóng/nâng vật.

Train thêm detector có thể cải thiện segmentation, nhưng không tự sửa được
sai pose, candidate generation hoặc collision model. Mask AP 60% cũng không
có nghĩa robot gắp thành công 60% và chưa đủ để khẳng định hệ thống vận hành
tin cậy.

## 10. Lượt cải thiện: thay đổi và tiến độ thực tế

Chi tiết nằm trong [IMPROVEMENT_VI.md](docs/IMPROVEMENT_VI.md) và cấu hình
[improved.yaml](configs/improved.yaml).

### 10.1. Detector và dữ liệu

- Warm-start từ baseline Mask R-CNN best checkpoint; reset optimizer.
- Train pool tăng lên 15.484 ảnh sau dedup, thêm onboarding/PBR và scene holdout.
- Balanced sampling, color augmentation và copy-paste tạo overlap; cập nhật
  visible masks của vật bị che, không tạo pose supervision giả từ compositing.
- Batch 8, AMP, SGD learning rate 0,0015, threaded prefetch trong một process.
- Mỗi epoch lấy mẫu 4.096 image draws; đây là resampled epoch, không quét đủ
  15.484 ảnh một lần. GPU allocation peak ghi nhận khoảng 4,4 GB.
- Checkpoint selection: `0,7 × Classic mask AP + 0,3 × PBR mask AP` trên
  100 Classic + 100 PBR validation frames cố định. Nhóm `real` trong log
  nghĩa là Classic/non-PBR holdout, bao gồm synthetic object 3.

| Epoch đã hoàn tất | Classic mask AP | PBR mask AP | Weighted selection AP |
|---|---:|---:|---:|
| 1 | 50,36% | 52,40% | 50,98% |
| 2 | 52,07% | 55,86% | 53,20% |
| 3 | 54,09% | 57,91% | 55,23% |
| 4 | 54,25% | 58,41% | 55,50% |
| 5 | 54,94% | 59,68% | 56,36% |
| 6 | 56,09% | 60,35% | **57,37%** |
| 7 | 55,67% | 60,66% | 57,17% |
| 8 | 54,74% | 61,22% | 56,69% |

Tại thời điểm viết đang chạy epoch 9/12. Best checkpoint vẫn từ epoch 6;
validation gần đây chưa vượt điểm đó. **Không so trực tiếp weighted validation
AP 57,37% với baseline test mask AP 27,63% để kết luận cải thiện trên test.**

### 10.2. Dense RGB-D pose và foreground refinement

Đã triển khai network ResNet-18/FPN nhận RGB, depth tương đối và mask prompt;
output là normalized object coordinates và foreground theo pixel. Coordinate
targets được dựng từ depth và GT pose chỉ trong training.

Cache `dense_v3` đã hoàn tất **46.792 training instances**; 46.665 có ít nhất
16 coordinate targets hợp lệ. GT visible foreground được tách khỏi coordinate
validity để vùng thiếu depth vẫn có supervision mask. Depth giữ context toàn
crop; 40% training prompt là box-only để học foreground khi mask đầu vào sai.

Inference dự kiến dùng dense 3D correspondences, RANSAC và rigid fit, sau đó
kiểm tra depth ICP update bằng correspondence residual. Kế hoạch training là
24 resampled epochs, 8.192 instance draws/epoch. **Chưa có training history
hoặc checkpoint dense pose hoàn tất tại thời điểm viết.**

Đã có script chọn RGB-D mask refinement theo từng class bằng weighted
validation AP. Script chưa chạy selection với checkpoint đã train; chưa có
`configs/selected.yaml` làm cấu hình cuối đã được kiểm chứng.

### 10.3. Grasp và va chạm

Đã triển khai sampler ray entry/exit, anchors cách nhau trong 3D và contact
support với CAD surface. Min contact width giảm từ 12 xuống 2 mm để giữ chi
tiết mỏng; opening clearance tổng 12 mm, vẫn trong giới hạn opening 85 mm.
Opening width và closing width được ghi riêng.

Collision mới dùng FCL CAD triangles với swept gripper boxes dọc approach cố
định orientation, kết hợp observed target/scene depth và CAD của neighbors có
predicted pose đủ fit. Reference evaluator mới được thiết kế kiểm tra GT CAD
target/neighbors sau planning; cần áp dụng cùng checker cho candidate cũ và
mới khi so sánh.

**Chưa có full test benchmark của tổ hợp dense pose + sampler mới + FCL.**
Các kiểm tra hình học đã chạy không xác nhận đóng ngón, force closure hoặc
nâng vật thành công. Không suy ra chất lượng end-to-end chỉ từ việc code mới
chạy được.

## 11. Artifact và cấu trúc mã nguồn

```text
clutterpick-rgb-d-perception-and-robotic-grasping/
├── src/clutterpick/       # Data, detector, pose, geometry, grasp, collision, pipeline
├── configs/              # Baseline, improved và các backend tùy chọn
├── scripts/              # Download, audit, training, benchmark, visualization, reports
├── tests/                # Scale, instance identity, pose fitting, collision, evaluator
├── data/                 # Index, splits, raw data và dense supervision cache
├── artifacts/training/   # Model checkpoints và training history
├── artifacts/evaluation/ # Detection/mask metrics
├── artifacts/benchmark/  # Full pipeline outputs
├── artifacts/experiments/# Ablations và controlled comparisons
├── artifacts/demo/       # Demo đầy đủ một frame
├── reports/              # Báo cáo, validation và fingerprints
└── audit/                # Dataset feasibility và kiểm tra ban đầu
```

Mỗi inference frame có thể xuất:

| Artifact | Nội dung |
|---|---|
| `detection.json`, `masks/` | Class, score, boxes và instance masks |
| `pointcloud.ply`, `pointclouds/` | Scene/per-instance visible point clouds, đơn vị m |
| `poses.json` | Object-to-camera transforms, fit metrics và failure statuses |
| `grasp_candidates.json` | Candidates sau contact-support check, trước collision filter |
| `grasps.json` | Ranked candidates sau lọc và rejection reasons |
| `pose_diagnostics.json` | ADD/ADD-S, translation/rotation so GT sau inference |
| `geometry_diagnostics.json` | Point contamination theo reference visible mask |
| `timing.json` | Thời gian các stage |
| `final_visualization.png`, `scene_3d.png` | Visualization 2D và 3D |

Demo đã có ở [classic_test_000002_149](artifacts/demo/classic_test_000002_149/).
Candidate trong demo là đề xuất của baseline, chưa phải ví dụ gắp thành công.

Checkpoints baseline:

```text
artifacts/training/maskrcnn/best.pt
artifacts/training/yolo11n_seg/weights/best.pt
artifacts/training/rgb_pose/best.pt
```

`reports/delivery_validation.json` đã xác nhận full test cohort, proper SE(3),
đơn vị, opening constraints, provenance và cùng tập 16 frame giữa các cấu hình
thí nghiệm. Kiểm tra tính nhất quán artifact không xác nhận độ chính xác pose
hay grasp success. Lượt kiểm tra gần nhất cho các module geometry/pose/collision
đã có **15 tests passed**; không coi đây là toàn bộ test suite của mọi thay đổi mới.

## 12. Thiết lập và các lệnh tái lập chính

Môi trường đo hiện tại: Windows, Python 3.11, NVIDIA RTX 4060 Laptop 8 GB;
PyTorch 2.10.0+cu128, torchvision 0.25.0+cu128. Các phiên bản thư viện được
lưu ở [requirements-measured.txt](requirements-measured.txt).

Chạy từ thư mục gốc project bằng PowerShell:

### 12.1. Thiết lập và baseline

```powershell
.\scripts\bootstrap.ps1
.\.venv\Scripts\python.exe scripts/download_dataset.py --groups classic
.\.venv\Scripts\python.exe scripts/run.py index
.\.venv\Scripts\python.exe -m pytest -q
```

### 12.2. Đánh giá checkpoints đã có

```powershell
.\.venv\Scripts\python.exe scripts/run.py evaluate --checkpoint artifacts/training/maskrcnn/best.pt --split test --output artifacts/evaluation/maskrcnn_test.json
.\.venv\Scripts\python.exe scripts/run.py evaluate --architecture yolo --checkpoint artifacts/training/yolo11n_seg/weights/best.pt --split test --output artifacts/evaluation/yolo_test.json
```

### 12.3. Demo RGB-D đầy đủ

```powershell
.\.venv\Scripts\python.exe scripts/run.py infer --checkpoint artifacts/training/maskrcnn/best.pt --pose-backend rgbd_keypoints --frame-key classic_test/000002/149 --output artifacts/demo
.\.venv\Scripts\python.exe scripts/visualize_instances.py artifacts/demo/classic_test_000002_149
.\.venv\Scripts\python.exe scripts/evaluate_demo.py artifacts/demo/classic_test_000002_149
```

### 12.4. Benchmark và báo cáo baseline

```powershell
.\.venv\Scripts\python.exe scripts/run.py infer --checkpoint artifacts/training/maskrcnn/best.pt --pose-backend rgbd_keypoints --limit 923 --skip-cloud-export --no-plots --output artifacts/benchmark/rgbd_full
.\.venv\Scripts\python.exe scripts/run_experiments.py --checkpoint artifacts/training/maskrcnn/best.pt --limit 16
.\.venv\Scripts\python.exe scripts/build_report.py
.\.venv\Scripts\python.exe scripts/validate_delivery.py
```

### 12.5. Lượt cải thiện

```powershell
.\scripts\run_improvement.ps1
```

Script gồm download/index/audit/dedup, training/resume, validation mask
selection, test evaluation, pipeline benchmark, ablations và báo cáo. Đây là
workflow được chuẩn bị, **chưa chạy hoàn tất tất cả các stage của lượt mới**.
Không khởi chạy thêm một training job trùng khi job hiện tại vẫn đang chạy.

## 13. Việc còn lại và tiêu chí đánh giá tiếp

1. Hoàn tất detector training, chọn checkpoint bằng validation và đánh giá trên
   cùng 923 ảnh test; kiểm tra per-class AP, đặc biệt class 4/5 và occlusion.
2. Huấn luyện dense RGB-D pose, đánh giá với predicted masks trên validation,
   kiểm tra ADD/ADD-S thay vì chỉ coordinate loss hoặc ICP residual.
3. Chọn các class bật mask refinement bằng validation; không chọn theo test.
4. Chạy full pipeline cải thiện và cùng 16-frame ablations, dùng cùng reference
   mesh evaluator cho candidate baseline và candidate mới.
5. Báo cáo đồng thời pose recall, contact support, candidate availability,
   reference collision và latency; không thay chỉ số an toàn bằng số candidate.
6. Nếu thực hiện mô phỏng, công bố giả định geometry/mass/friction, tiêu chí
   tiếp cận–đóng ngón–nâng–giữ vật và tỷ lệ simulated success. Robot thật cần
   thêm calibration, kinematics và đánh giá thực thi riêng.

Project hiện có giá trị như baseline nghiên cứu và hệ thống chẩn đoán lỗi
truyền từ segmentation sang pose/grasp. **Chưa có căn cứ xác nhận hệ thống
sẵn sàng vận hành bin-picking thực tế**, chưa có simulated/physical grasp
success rate và chưa có official BOP pose benchmark result.

## 14. Báo cáo và nguồn đối chiếu

- [README](README.md): setup, training và inference.
- [Kết quả baseline](reports/RESULTS_VI.md) và [measured summary](reports/measured_summary.json).
- [Phạm vi triển khai](docs/IMPLEMENTATION_VI.md).
- [Phương pháp cải thiện](docs/IMPROVEMENT_VI.md).
- [Kết quả cải thiện](reports/improvement/RESULTS_VI.md): có thể cần tạo lại sau các epoch mới.
- [Detector improvement history](artifacts/training/improved_maskrcnn/history.json).
- [Dense target cache audit](reports/improvement/dense_cache_audit.json).
- [Dataset feasibility audit](audit/FEASIBILITY_VI.md).
- [IndustryShapes website](https://pose-lab.github.io/IndustryShapes/).
- [Dataset repository](https://huggingface.co/datasets/POSE-Lab/IndustryShapes).
- [Official benchmark repository](https://github.com/POSE-Lab/IndustryShapes_benchmark).

Số liệu trong tài liệu này mô tả các phép đo đã có tại thời điểm tổng hợp.
Phần mới chưa có artifact được ghi chưa hoàn tất, không suy ra kết quả từ
training loss, validation AP hoặc việc triển khai code.
