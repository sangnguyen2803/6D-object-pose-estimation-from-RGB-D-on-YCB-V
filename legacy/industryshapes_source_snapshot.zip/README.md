# ClutterPick: RGB-D perception and collision-aware grasp planning

Đồ án trên IndustryShapes: Mask R-CNN → visible RGB-D point clouds → CAD pose
registration → antipodal parallel-jaw grasp candidates → scene/approach collision
filtering. Có baseline YOLO segmentation và adapter FoundationPose tùy chọn.

Đọc [kết quả thực nghiệm](reports/RESULTS_VI.md) và
[phạm vi triển khai](docs/IMPLEMENTATION_VI.md) để xem số liệu, phương pháp và giới hạn.

[Tổng hợp chi tiết project và kết quả hiện tại](PROJECT_SUMMARY_VI.md) trình bày
mục tiêu, dataset, pipeline, thí nghiệm, tiến độ cải thiện và các giới hạn.

Lượt cải thiện dùng thêm onboarding/PBR, dense RGB-D correspondence pose và
FCL swept-volume collision: [phương pháp](docs/IMPROVEMENT_VI.md),
[kết quả mới](reports/improvement/RESULTS_VI.md). Chạy lại bằng
`.\scripts\run_improvement.ps1`; artifacts baseline và lượt mới được lưu riêng.

Đây là pipeline nghiên cứu. Candidate vượt kiểm tra bề mặt chưa phải grasp đã
gắp thành công; hệ thống chưa đo kết quả robot hoặc mô phỏng vật lý.

## Chạy lại các bước đã tích hợp

Sau khi thiết lập environment, dùng `.\scripts\run_all.ps1` để kiểm tra dataset,
đánh giá checkpoint hiện có, chạy inference/ablations và tạo báo cáo. Thêm
`-Retrain` để huấn luyện lại, hoặc `-ExperimentFrames 8` để giảm tập downstream.
Script tự train model nếu checkpoint của model đó chưa tồn tại.

## Thiết lập

Windows PowerShell, Python 3.11 và NVIDIA GPU:

```powershell
.\scripts\bootstrap.ps1
.\.venv\Scripts\python.exe scripts/download_dataset.py --groups classic
.\.venv\Scripts\python.exe scripts/run.py index
.\.venv\Scripts\python.exe -m pytest -q
```

Thêm `-CpuOnly` vào bootstrap nếu cần CPU. Huấn luyện Mask R-CNN trên CPU sẽ chậm.
Linux: tạo venv, cài PyTorch/torchvision phù hợp CUDA từ hướng dẫn chính thức,
sau đó `pip install -e '.[yolo,test,geometry]'`. Môi trường phiên làm việc đầu
tiên dùng venv kế thừa thư viện Python sẵn có; bootstrap mới tạo venv độc lập.

Archive được tải ở dataset revision cố định, kiểm tra SHA256 và giải nén vào
`data/raw/`. Dùng BOP thay vì Parquet để giữ toàn bộ instance của mỗi frame.
Không commit dataset, checkpoint và cache. Các metadata/split nhỏ vẫn được giữ.

## Huấn luyện và đánh giá

```powershell
.\.venv\Scripts\python.exe scripts/run.py train --epochs 8 --device cuda
.\.venv\Scripts\python.exe scripts/run.py evaluate --checkpoint artifacts/training/maskrcnn/best.pt --split test --output artifacts/evaluation/maskrcnn_test.json
.\.venv\Scripts\python.exe scripts/run.py train --architecture yolo --epochs 8 --device cuda
.\.venv\Scripts\python.exe scripts/run.py evaluate --architecture yolo --checkpoint artifacts/training/yolo11n_seg/weights/best.pt --split test --output artifacts/evaluation/yolo_test.json
```

Resume: `train --epochs 8 --resume artifacts/training/maskrcnn/last.pt`.
Default batch size 2, effective batch 2; initial profiling epochs may use batch
1 with accumulation 2. Checkpoint history records the final training regime.
Pilot: thêm `--limit 100 --epochs 1`; đây là training subset, không phải full run.
`--val-limit 100` là mặc định chọn checkpoint nhanh; evaluate `--split val`
không giới hạn để đánh giá validation đầy đủ. `best.pt` chọn bằng mask AP trên
validation, không chọn bằng test. COCO AP dùng confidence ≥0,05 để giữ recall;
inference/grasp mặc định confidence ≥0,5.
Đánh giá cuối dùng tối đa 30 detections/frame ở cả hai model. Checkpoint YOLO
được chọn bằng native validation đầy đủ; checkpoint Mask R-CNN dùng subset 100
ảnh validation đã cố định. Cả hai cùng được đánh giá COCO trên test BOP gốc.

YOLO dùng yolo11n-seg pretrained. Cùng scene splits nhưng kiến trúc, optimizer,
augmentation và độ phân giải khác Mask R-CNN, nên so sánh là hai baseline thực
dụng, không phải thí nghiệm cô lập hoàn toàn kiến trúc. Chuyển mask sang polygon
YOLO dùng contour ngoài và nối các component; holes không được biểu diễn đầy
đủ. Đánh giá cuối vẫn dùng visible masks BOP gốc và cùng COCO evaluator.

## Chạy pipeline

```powershell
.\.venv\Scripts\python.exe scripts/run.py infer --checkpoint artifacts/training/maskrcnn/best.pt --limit 8 --output artifacts/inference/maskrcnn
.\.venv\Scripts\python.exe scripts/run.py infer --checkpoint artifacts/training/maskrcnn/best.pt --pose-backend rgbd_keypoints --frame-key classic_test/000002/149 --output artifacts/demo
.\.venv\Scripts\python.exe scripts/visualize_instances.py artifacts/demo/classic_test_000002_149
.\.venv\Scripts\python.exe scripts/evaluate_demo.py artifacts/demo/classic_test_000002_149
```

Mỗi frame xuất:

- `detection.json`, `masks/`: class, score, bounding box, visible masks.
- `pointcloud.ply`, `pointclouds/`: scene và từng object, đơn vị mét.
- `poses.json`: CAD-to-camera transform, fit diagnostics và failure status.
- `grasp_candidates.json`: tất cả candidate trước lọc.
- `grasps.json`: top-k sau lọc và rejection reasons.
- `pose_diagnostics.json`: so GT sau inference, ADD/ADD-S và translation/rotation.
- `timing.json`, `final_visualization.png`, `scene_3d.png`.

Các transform có dạng `p_camera = R p_local + t`. Camera frame BOP/OpenCV:
X sang phải, Y xuống dưới, Z về phía trước. Gripper origin tại tâm tiếp xúc,
X là trục đóng ngón, Z là hướng approach vào vật; palm nằm ở Z âm. CAD được
chuyển mm→m đúng một lần. Quaternion nếu xuất phải ghi rõ thứ tự xyzw.

`infer --oracle-masks` là chế độ chẩn đoán với GT visible masks. Output và ảnh
được đánh dấu rõ, không được dùng làm kết quả detector end-to-end. Pose luôn
được ước lượng từ dữ liệu quan sát; GT pose chỉ xuất hiện trong evaluator.

Benchmark pipeline RGB-D trên toàn Classic Test sau khi train pose:

```powershell
.\.venv\Scripts\python.exe scripts/run.py infer --checkpoint artifacts/training/maskrcnn/best.pt --pose-backend rgbd_keypoints --limit 923 --skip-cloud-export --no-plots --output artifacts/benchmark/rgbd_full
```

`--skip-cloud-export` giữ nguyên tính toán hình học, bỏ lưu PLY để giảm IO/dung
lượng. Timing có mốc trước reference evaluation; các GT diagnostics không nằm
trong thời gian inference này. Mask PNG export và đọc RGB-D vẫn được tính.

## Thí nghiệm downstream

```powershell
.\.venv\Scripts\python.exe scripts/run_experiments.py --checkpoint artifacts/training/maskrcnn/best.pt --limit 16
```

Chạy trên cùng tập frame cố định: predicted mask, bbox depth và reference mask.
Xuất CSV/JSON với point/pose/grasp diagnostics và kiểm tra candidate bằng CAD
đặt theo GT sau khi planning xong. Geometry evaluator độc lập với pose dự đoán,
nhưng vẫn dùng thuật toán kiểm tra sampled surfaces; kết quả không thay cho
physics simulation. Các frame không detect được vẫn được tính ở thống kê scene.

Baseline pose RGB dùng ResNet-18 dự đoán 8 góc bounding box CAD rồi giải PnP.
Training targets được chiếu từ pose annotation; 82 pose vượt ngưỡng trực chuẩn
được bỏ khỏi supervision pose, vẫn giữ trong detector training. Inference nhận
RGB, predicted box/class và K, không nhận pose/mask GT. Đây là baseline của dự
án, không phải DOPE hoặc FoundationPose.

```powershell
.\.venv\Scripts\python.exe scripts/run.py train-pose --epochs 12
.\.venv\Scripts\python.exe scripts/run.py infer --checkpoint artifacts/training/maskrcnn/best.pt --pose-backend rgbd_keypoints --limit 8 --output artifacts/inference/rgbd_pose
.\.venv\Scripts\python.exe scripts/compare_pose_modalities.py --checkpoint artifacts/training/maskrcnn/best.pt --limit 16
.\.venv\Scripts\python.exe scripts/compare_detectors.py --limit 16
.\.venv\Scripts\python.exe scripts/build_report.py
.\.venv\Scripts\python.exe scripts/validate_delivery.py
.\.venv\Scripts\python.exe scripts/artifact_manifest.py
```

`rgb_keypoints` dùng RGB/PnP cho pose; `rgbd_keypoints` thêm cùng một depth ICP
refinement. Cả hai vẫn dùng depth cho point cloud và collision/grasp downstream,
nên thí nghiệm là RGB-pose vs RGB-D-pose, không phải toàn pipeline RGB-only.
Optional `--pose-backend rendered` dùng offscreen OpenGL render-and-compare;
cài `pip install -e '.[render]'`. `configs/pose_fpfh.yaml` thêm global feature
initializations; cần extra `geometry`. Các backend này chưa đảm bảo cải thiện
mọi object; xem kết quả validation và pose diagnostics.

## Dữ liệu và phạm vi đánh giá

Classic Train 3.700 ảnh được chia thành train 1.792 và val 1.908 theo scene;
Classic Test 923 ảnh giữ nguyên. Val scenes: 000001, 000003, 000009, 000011,
000013. Scene 000009 là synthetic của object 3, trong khi train giữ object 3
ở scene real 000002. Val lớn và không cân bằng; phải xem per-class AP thay vì
chỉ AP tổng. Xem `data/index_report.json` và `data/splits.json`.

Extended và PBR là mở rộng: `download_dataset.py --groups extended` rồi index
lại; đánh giá `--split extended_test`. Script tải PBR và loader đã hỗ trợ cấu
trúc, nhưng training hiện tại là Classic-only; không tự động thêm PBR.

Một số GT rotation chưa trực chuẩn; loader ghi diagnostic, giữ nguyên dữ liệu
gốc. Rotation error ghi rõ nếu chiếu reference rotation sang SO(3), ADD vẫn dùng
reference gốc. Symmetry metadata chưa được khai báo trong CAD: báo cáo ADD/ADD-S
như diagnostic, không gọi chúng là official BOP AR. Xem audit/FEASIBILITY_VI.md.

Grasp trước lọc va chạm phải có ít nhất một contact được depth của vật đích hỗ
trợ trong tolerance 20 mm; kiểm tra này loại candidate nằm xa vật quan sát.
`grasp_candidates.json` chứa các candidate đã qua bước support này. Đây chưa
phải xác nhận contact vật lý, force closure hay grasp success.
Collision checks gồm fingers, palm, target body và approach được lấy mẫu. Scene
obstacles chứa depth ngoài target mask, gồm background và distractors. Bề mặt
khuất chưa quan sát của các vật khác, thể tích kín, thao tác đóng ngón động và
robot reachability chưa được xác minh. `no_feasible_candidate` là output hợp lệ.

## Cấu trúc

`src/clutterpick/`: data, detection, training, evaluation, geometry, pose, grasp,
collision, pipeline và visualization. `configs/`: YAML. `scripts/`: tải dữ liệu,
bootstrap và thí nghiệm. `tests/`: kiểm tra metric scale, instance identity,
registration, collision trajectory và evaluator. `reports/`: kết quả thực nghiệm.

Nguồn: [IndustryShapes](https://pose-lab.github.io/IndustryShapes/),
[dataset](https://huggingface.co/datasets/POSE-Lab/IndustryShapes),
[benchmark](https://github.com/POSE-Lab/IndustryShapes_benchmark),
[BOP format](https://github.com/thodan/bop_toolkit/blob/master/docs/bop_datasets_format.md),
[Mask R-CNN](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.detection.maskrcnn_resnet50_fpn.html).
