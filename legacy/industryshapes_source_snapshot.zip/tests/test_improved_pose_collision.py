import numpy as np
import trimesh
from scipy.spatial.transform import Rotation
from clutterpick.common import load_config
from clutterpick.dense_pose import robust_correspondence_pose,prepare_crop
from clutterpick.geometry import transform_points
from clutterpick.mesh_collision import MeshCollisionChecker,filter_estimated_neighbors
from clutterpick.grasp import generate_candidates
from clutterpick.collision import filter_candidates


def test_correspondence_ransac_rejects_outliers():
    rng = np.random.default_rng(123)
    model = rng.uniform(-.08,.08,(250,3))
    truth = np.eye(4)
    truth[:3,:3] = Rotation.from_euler('xyz',[20,50,-30],degrees=True).as_matrix()
    truth[:3,3] = [.1,-.03,.6]
    observed = transform_points(model,truth)+rng.normal(0,.001,model.shape)
    observed[:100] = rng.uniform(-.2,.2,(100,3))
    cfg = load_config('configs/improved.yaml')['dense_pose']
    estimate,inliers = robust_correspondence_pose(model,observed,cfg)
    assert inliers.sum()>=145
    assert inliers[:100].sum()==0
    assert np.linalg.norm(estimate[:3,3]-truth[:3,3])<.001
    assert Rotation.from_matrix(estimate[:3,:3]@truth[:3,:3].T).magnitude()<.02


def test_crop_keeps_depth_and_pixel_geometry_consistent():
    depth = np.ones((60,80))*.7
    rgb = np.zeros((60,80,3),dtype=np.uint8)
    mask = np.ones_like(depth,dtype=bool)
    k = np.array([[120,0,40],[0,120,30],[0,0,1.]])
    _,_,valid,camera,pixels = prepare_crop(rgb,depth,k,[20,10,50,40],mask,32,.1)
    assert valid.all()
    projected = camera@k.T
    assert np.allclose(projected[...,:2]/projected[...,2:],pixels,atol=1e-4)


def test_depth_context_does_not_change_with_foreground_prompt():
    depth = np.tile(np.linspace(.5, .8, 80), (60, 1))
    rgb = np.zeros((60, 80, 3), dtype=np.uint8)
    mask = np.zeros_like(depth, dtype=bool)
    mask[20:30, 30:40] = True
    k = np.array([[120, 0, 40], [0, 120, 30], [0, 0, 1.]])
    _, context, valid, _, _ = prepare_crop(rgb, depth, k, [20, 10, 50, 40], mask, 32, .1)
    _, box_context, box_valid, _, _ = prepare_crop(rgb, depth, k, [20, 10, 50, 40],
                                                np.ones_like(mask), 32, .1)
    np.testing.assert_array_equal(context, box_context)
    assert valid.sum() < box_valid.sum()
    assert np.any(context[~valid] != 0)


def test_exact_mesh_collision_and_inside_volume():
    cfg = load_config('configs/improved.yaml')
    mesh = trimesh.creation.box(extents=[.02,.02,.02])
    pose = np.eye(4); pose[:3,3] = [0,0,.6]
    checker = MeshCollisionChecker(mesh,pose)
    clear = np.eye(4); clear[:3,3] = [.15,0,.6]
    pre = clear.copy(); pre[2,3] -= .08
    candidate = {'T_camera_gripper':clear,'T_camera_pregrasp':pre,'opening_width_m':.03}
    assert checker.reject_reason(candidate,cfg) is None
    blocked = clear.copy(); blocked[:3,3] = [0,0,.61]
    candidate.update(T_camera_gripper=blocked,T_camera_pregrasp=blocked)
    candidate['opening_width_m'] = .006
    assert checker.reject_reason(candidate,cfg) is not None


def test_ray_grasps_exit_surface_and_opening_limits():
    cfg = load_config('configs/improved.yaml')
    mesh = trimesh.creation.box(extents=[.04,.05,.05])
    pose = np.eye(4); pose[2,3] = .6
    candidates = generate_candidates(mesh,pose,'test',cfg)
    assert len(candidates)>0
    for candidate in candidates:
        assert candidate['opening_width_m']<=cfg['gripper']['max_opening_m']
        assert np.allclose(candidate['T_camera_gripper'][:3,:3].T@candidate['T_camera_gripper'][:3,:3],np.eye(3))
        local = (candidate['contacts_camera']-pose[:3,3])@pose[:3,:3]
        assert np.all(np.isclose(np.abs(local)/np.array([.02,.025,.025]),1,atol=1e-5).any(axis=1))


def test_swept_check_catches_obstacle_between_sampled_poses():
    cfg = load_config('configs/improved.yaml')
    cfg['gripper']['finger_length_m'] = .002
    cfg['gripper']['palm_thickness_m'] = .002
    cfg['grasp']['clearance_margin_m'] = 0
    cfg['grasp']['approach_steps'] = 2
    final = np.eye(4); final[2,3] = .6
    pre = final.copy(); pre[2,3] -= .08
    candidate = {'grasp_id':'test','opening_width_m':.04,'contact_width_m':.04,'contact_score':1.,
                 'T_camera_gripper':final,'T_camera_pregrasp':pre}
    obstacle = np.array([[.024,0,.56]])
    accepted,rejected,_ = filter_candidates([candidate],obstacle,np.empty((0,3)),cfg)
    assert not accepted and rejected[0]['reason']=='scene_swept_volume_collision'


def test_estimated_neighbor_checks_exclude_target_and_block_approach():
    cfg = load_config('configs/improved.yaml')
    mesh = trimesh.creation.box(extents=[.01,.01,.01])
    class Geometry:
        def mesh(self,identifier):
            return mesh,None,None
    final = np.eye(4); final[2,3] = .6
    pre = final.copy(); pre[2,3] -= .08
    target = final.copy(); target[:3,3] = [.024,0,.56]
    grasp = {'grasp_id':'g','target_instance_id':'target','opening_width_m':.04,
             'T_camera_gripper':final,'T_camera_pregrasp':pre}
    poses = [{'instance_id':'target','obj_id':1,'status':'ok','observed_trimmed_rmse_m':.001,'T_camera_object':target}]
    passed,rejected = filter_estimated_neighbors([grasp],poses,Geometry(),cfg)
    assert len(passed)==1 and not rejected
    poses.append({**poses[0],'instance_id':'neighbor'})
    passed,rejected = filter_estimated_neighbors([grasp],poses,Geometry(),cfg)
    assert not passed and rejected[0]['neighbor_instance_id']=='neighbor'
