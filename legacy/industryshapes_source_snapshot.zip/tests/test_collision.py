import numpy as np
from clutterpick.common import load_config
from clutterpick.collision import filter_candidates


def candidate():
    pose = np.eye(4)
    pose[:3,3] = [0,0,.6]
    pre = pose.copy(); pre[2,3]-=.08
    return {"grasp_id":"g0","T_camera_gripper":pose,"T_camera_pregrasp":pre,
            "opening_width_m":.04,"contact_width_m":.038,"contact_score":1.}


def test_obstacle_on_approach_is_rejected_even_if_final_pose_is_clear():
    config = load_config()
    grasp = candidate()
    obstacle = np.array([[.024,0,.515]])
    accepted,rejected,_ = filter_candidates([grasp],obstacle,np.empty((0,3)),config)
    assert not accepted
    assert rejected[0]["reason"]=="scene_or_approach_collision"


def test_clear_grasp_is_kept_and_has_explicit_validation_scope():
    grasp = candidate()
    accepted,rejected,total = filter_candidates([grasp],np.array([[1.,1.,1.]]),np.empty((0,3)),load_config())
    assert total==1 and len(accepted)==1 and not rejected
    assert "reachability_not_verified" in accepted[0]["validation_scope"]


def test_palm_target_penetration_is_rejected():
    accepted,rejected,_ = filter_candidates([candidate()],np.empty((0,3)),np.array([[0,0,.545]]),load_config())
    assert not accepted and rejected[0]["reason"]=="target_body_collision"
