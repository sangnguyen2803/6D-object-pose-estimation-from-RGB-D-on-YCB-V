import numpy as np
from PIL import Image
from clutterpick.data import BOPDetectionDataset,select_frames,load_rgbd


def test_multiple_instances_same_class_remain_separate(tmp_path):
    rgb = tmp_path/"rgb.png"
    Image.fromarray(np.zeros((10,20,3),dtype=np.uint8)).save(rgb)
    objects = []
    for i,offset in enumerate([1,11]):
        mask = np.zeros((10,20),dtype=np.uint8)
        mask[2:8,offset:offset+5]=255
        path = tmp_path/f"{i}.png"; Image.fromarray(mask).save(path)
        objects.append({"obj_id":3,"mask_visib":str(path),"visib_fract":1})
    _,target = BOPDetectionDataset([{"id":0,"rgb":str(rgb),"instances":objects}])[0]
    assert target["labels"].tolist()==[3,3]
    assert target["masks"].shape==(2,10,20)
    assert target["boxes"].tolist()==[[1,2,6,8],[11,2,16,8]]


def test_depth_scale_is_applied_per_frame(tmp_path):
    rgb,depth = tmp_path/"rgb.png",tmp_path/"depth.png"
    Image.fromarray(np.zeros((2,2,3),dtype=np.uint8)).save(rgb)
    Image.fromarray(np.full((2,2),5000,dtype=np.uint16)).save(depth)
    _,z,_ = load_rgbd({"rgb":str(rgb),"depth":str(depth),"depth_scale_mm":.1,"K":np.eye(3).ravel().tolist()})
    np.testing.assert_allclose(z,.5)


def test_missing_depth_keeps_foreground_supervision(tmp_path):
    from clutterpick.common import load_config
    from clutterpick.dense_pose import DenseCoordinateDataset
    rgb, depth, visible = [tmp_path / name for name in ['rgb.png', 'depth.png', 'mask.png']]
    Image.fromarray(np.zeros((40, 40, 3), dtype=np.uint8)).save(rgb)
    Image.fromarray(np.zeros((40, 40), dtype=np.uint16)).save(depth)
    mask = np.zeros((40, 40), dtype=np.uint8)
    mask[10:30, 10:30] = 255
    Image.fromarray(mask).save(visible)
    obj = {'obj_id': 1, 'instance_id': 'missing-depth', 'visib_fract': 1., 'px_count_visib': 400,
           'rotation_orthogonality_error': 0., 'R_m2c': np.eye(3).ravel().tolist(),
           't_m2c_mm': [0, 0, 600], 'mask_visib': str(visible)}
    frame = {'key': 'missing-depth', 'rgb': str(rgb), 'depth': str(depth),
             'K': [120, 0, 20, 0, 120, 20, 0, 0, 1], 'depth_scale_mm': 1., 'instances': [obj]}
    config = load_config('configs/improved.yaml')
    config['dense_pose']['cache'] = str(tmp_path / 'cache')
    info = {'1': {'min_x': -20, 'min_y': -20, 'min_z': -20,
                  'size_x': 40, 'size_y': 40, 'size_z': 40, 'diameter': 70}}
    images, _, _, valid, foreground = DenseCoordinateDataset([frame], info, config)[0]
    assert not valid.any()
    assert foreground.sum() > 0
    np.testing.assert_array_equal(images[4].numpy() > 0, foreground.numpy())


def test_pilot_sampling_covers_scenes_instead_of_first_class_only():
    frames = [{"id":i,"group":"train","scene_id":str(i//10)} for i in range(30)]
    selected = select_frames({"frames":frames},list(range(30)),6)
    assert {f["scene_id"] for f in selected}=={"0","1","2"}


def test_copy_paste_updates_visible_masks_and_boxes(tmp_path):
    import torch
    np.random.seed(9); torch.manual_seed(9)
    rgb = np.zeros((80,100,3),dtype=np.uint8)
    objects = []
    for i in range(5):
        mask = np.zeros((80,100),dtype=np.uint8)
        mask[25:40,5+i*18:18+i*18] = 255
        rgb[mask>0] = [40+i*30,120,150]
        path = tmp_path/f'mask_{i}.png'; Image.fromarray(mask).save(path)
        objects.append({'obj_id':i+1,'mask_visib':str(path),'visib_fract':1.})
    path = tmp_path/'rgb.png'; Image.fromarray(rgb).save(path)
    frame = {'id':0,'rgb':str(path),'instances':objects}
    image,target = BOPDetectionDataset([frame],training=True,augmentation={'copy_paste_probability':1.})[0]
    assert image.shape==(3,80,100)
    assert target['masks'].sum(dim=0).max()<=1
    for mask,box in zip(target['masks'].numpy(),target['boxes'].numpy()):
        y,x = np.nonzero(mask)
        assert len(x)>=10
        np.testing.assert_array_equal(box,[x.min(),y.min(),x.max()+1,y.max()+1])
