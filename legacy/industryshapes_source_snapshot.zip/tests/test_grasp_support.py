import numpy as np
from clutterpick.grasp import require_observed_contact


def test_floating_grasp_is_rejected_but_one_visible_contact_is_sufficient():
    candidates = [{"grasp_id":"near","contacts_camera":np.array([[0,0,.5],[.04,0,.5]])},
                  {"grasp_id":"floating","contacts_camera":np.array([[0,0,1.5],[.04,0,1.5]])}]
    accepted,rejected = require_observed_contact(candidates,np.array([[.001,0,.5]]),.02)
    assert [g["grasp_id"] for g in accepted]==["near"]
    assert rejected==[{"grasp_id":"floating","reason":"no_observed_contact_support"}]
