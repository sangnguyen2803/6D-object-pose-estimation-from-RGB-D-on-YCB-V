import numpy as np
import torch
from clutterpick.rgb_pose import RGBKeypointEstimator,cad_corners,crop_rgb


def test_rgb_pnp_recovers_metric_pose_from_known_projected_keypoints():
    info = {"min_x":-10,"min_y":-20,"min_z":-5,"size_x":20,"size_y":40,"size_z":10}
    corners = cad_corners(info)
    rgb = np.zeros((100,100,3),dtype=np.uint8)
    box = [30,30,70,70]
    k = np.array([[200.,0.,50.],[0.,200.,50.],[0.,0.,1.]])
    _,origin,extent = crop_rgb(rgb,box)
    points = corners+np.array([.005,-.003,.4])
    uvh = points@k.T
    normalized = (uvh[:,:2]/uvh[:,2:]-origin)/extent
    class KnownKeypoints(torch.nn.Module):
        def forward(self,images,labels):
            return torch.tensor(normalized,dtype=torch.float32)[None]
    estimator = object.__new__(RGBKeypointEstimator)
    estimator.device = torch.device("cpu")
    estimator.network = KnownKeypoints()
    estimator.payload = {"model_info":{"1":info}}
    estimator.checkpoint = "synthetic_fixture"
    estimator.config = {"seed":42}
    result = estimator.estimate_rgb(rgb,k,box,1)
    assert result["status"]=="ok"
    assert result["uses_depth_for_pose"] is False
    np.testing.assert_allclose(result["T_camera_object"][:3,3],[.005,-.003,.4],atol=1e-5)
    np.testing.assert_allclose(result["T_camera_object"][:3,:3],np.eye(3),atol=1e-3)
