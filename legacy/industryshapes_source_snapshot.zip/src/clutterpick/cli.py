import argparse
import os
from pathlib import Path
from .common import load_config,resolve,write_json


def main():
    os.environ.setdefault("TORCH_HOME",str(resolve("artifacts/cache/torch")))
    yolo_config = resolve("artifacts/cache/ultralytics")
    (yolo_config/"Ultralytics").mkdir(parents=True,exist_ok=True)
    os.environ.setdefault("YOLO_CONFIG_DIR",str(yolo_config))
    p = argparse.ArgumentParser(description="IndustryShapes RGB-D perception and grasp planning")
    p.add_argument("--config",default="configs/default.yaml")
    sub = p.add_subparsers(dest="command",required=True)
    sub.add_parser("index")
    pose_train = sub.add_parser("train-pose")
    pose_train.add_argument("--epochs",type=int,default=12)
    pose_train.add_argument("--device",default="auto")
    pose_train.add_argument("--resume")
    dense_train = sub.add_parser("train-dense-pose")
    dense_train.add_argument("--epochs",type=int)
    dense_train.add_argument("--device",default="auto")
    dense_train.add_argument("--resume")
    train = sub.add_parser("train")
    train.add_argument("--architecture",choices=["maskrcnn","yolo"],default="maskrcnn")
    train.add_argument("--epochs",type=int)
    train.add_argument("--limit",type=int)
    train.add_argument("--val-limit",type=int,default=100)
    train.add_argument("--resume")
    train.add_argument("--device",default="auto")
    ev = sub.add_parser("evaluate")
    ev.add_argument("--checkpoint",required=True)
    ev.add_argument("--architecture",choices=["maskrcnn","yolo","rgbd_refined"],default=None)
    ev.add_argument("--split",choices=["val","test","extended_test"],default="test")
    ev.add_argument("--limit",type=int)
    ev.add_argument("--device",default="auto")
    ev.add_argument("--output",default="artifacts/evaluation/detection.json")
    infer = sub.add_parser("infer")
    infer.add_argument("--checkpoint")
    infer.add_argument("--architecture",choices=["maskrcnn","yolo","rgbd_refined"],default=None)
    infer.add_argument("--frame-key")
    infer.add_argument("--split",choices=["val","test","extended_test"],default="test")
    infer.add_argument("--limit",type=int,default=1)
    infer.add_argument("--device",default="auto")
    infer.add_argument("--oracle-masks",action="store_true",help="REFERENCE MASK diagnostic; not end-to-end predictions")
    infer.add_argument("--pose-backend",choices=["geometric","rendered","foundationpose","rgb_keypoints","rgbd_keypoints","dense_rgbd"],default=None)
    infer.add_argument("--pose-checkpoint")
    infer.add_argument("--output",default="artifacts/inference")
    infer.add_argument("--no-plots",action="store_true")
    infer.add_argument("--depth-extraction",choices=["mask","bbox"],default="mask")
    infer.add_argument("--skip-cloud-export",action="store_true",help="Keep geometry computation and metrics but omit large PLY files")
    args = p.parse_args()
    config = load_config(args.config)
    if args.command in ["infer","evaluate"]:
        import torch
        torch.set_num_threads(4)
    if args.command=="index":
        from .data import build_index
        _,splits = build_index(config)
        print({k:len(v) for k,v in splits.items()},flush=True)
    elif args.command=="train-pose":
        from .rgb_pose import train_rgb_pose
        print(f"CHECKPOINT={train_rgb_pose(config,args.epochs,device=args.device,resume=args.resume)}",flush=True)
    elif args.command=="train-dense-pose":
        from .dense_pose import train_dense_pose
        print(f"CHECKPOINT={train_dense_pose(config,args.epochs,args.resume,args.device)}",flush=True)
    elif args.command=="train":
        if args.architecture=="maskrcnn":
            from .training import train_maskrcnn
            checkpoint = train_maskrcnn(config,args.epochs,args.limit,args.val_limit,args.resume,args.device)
        else:
            from .yolo import train_yolo
            checkpoint = train_yolo(config,args.epochs or config["training"]["epochs"],args.limit,args.device,args.resume)
        print(f"CHECKPOINT={checkpoint}",flush=True)
    elif args.command=="evaluate":
        from .data import load_index,select_frames
        from .detection import load_detector
        from .evaluation import evaluate_detector
        index,splits = load_index(config)
        frames = select_frames(index,splits[args.split],args.limit,config["seed"])
        if not frames:
            p.error("Requested split is unavailable; download that dataset group and rebuild index")
        detector = load_detector(resolve(args.checkpoint),config,args.device,args.architecture)
        report = evaluate_detector(detector,frames,resolve(args.output))
        print(report["metrics"],flush=True)
    else:
        if not args.oracle_masks and not args.checkpoint:
            p.error("infer requires --checkpoint, or explicit --oracle-masks for diagnostic mode")
        from .data import load_index,select_frames
        from .detection import load_detector
        from .pipeline import run_frame
        index,splits = load_index(config)
        if args.frame_key:
            frames = [f for f in index["frames"] if f["key"]==args.frame_key]
            if not frames:
                p.error("Unknown frame key; see data/index.json")
        else:
            frames = select_frames(index,splits[args.split],args.limit,config["seed"])
        if not frames:
            p.error("Requested inference split is unavailable; download that group and rebuild index")
        detector = None if args.oracle_masks else load_detector(resolve(args.checkpoint),config,args.device,args.architecture)
        summaries = []
        runtime = {}
        for frame in frames:
            output = resolve(args.output)/frame["key"].replace("/","_")
            result = run_frame(frame,config,detector,output,args.oracle_masks,args.pose_backend,not args.no_plots,
                               args.depth_extraction,args.pose_checkpoint,runtime,not args.skip_cloud_export)
            summaries.append(result)
            print({k:v for k,v in result.items() if k!="pose_diagnostics"},flush=True)
            if len(summaries)%10==0:
                write_json(resolve(args.output)/"run_summary.json",summaries)
        write_json(resolve(args.output)/"run_summary.json",summaries)
        if "rendered" in runtime:
            runtime["rendered"].close()


if __name__=="__main__":
    main()
