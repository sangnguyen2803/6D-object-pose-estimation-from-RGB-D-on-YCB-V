from pathlib import Path
import numpy as np


def choose_device(requested="auto"):
    import torch
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable in this Python environment")
    return torch.device(requested)


def create_maskrcnn(config, pretrained=False):
    import torch
    from torchvision.ops.misc import FrozenBatchNorm2d
    from torchvision.models.detection import maskrcnn_resnet50_fpn, MaskRCNN_ResNet50_FPN_Weights
    from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
    from torchvision.models.detection.mask_rcnn import MaskRCNNPredictor
    d = config["detector"]
    model = maskrcnn_resnet50_fpn(weights=MaskRCNN_ResNet50_FPN_Weights.DEFAULT if pretrained else None,
                                weights_backbone=None, min_size=d["min_size"], max_size=d["max_size"],
                                box_detections_per_img=d["max_detections"], box_score_thresh=0.05)
    # Torchvision otherwise changes normalization/freezing when weights=None.
    # Preserve the pretrained architecture for loading and resuming checkpoints.
    def freeze_batch_norm(module):
        for name,child in list(module.named_children()):
            if isinstance(child,torch.nn.BatchNorm2d):
                replacement = FrozenBatchNorm2d(child.num_features,eps=child.eps)
                replacement.load_state_dict({k:v for k,v in child.state_dict().items() if k!="num_batches_tracked"})
                setattr(module,name,replacement)
            else:
                freeze_batch_norm(child)
    freeze_batch_norm(model.backbone.body)
    for name,param in model.backbone.body.named_parameters():
        param.requires_grad_(name.startswith(("layer2.","layer3.","layer4.")))
    model.roi_heads.box_predictor = FastRCNNPredictor(model.roi_heads.box_predictor.cls_score.in_features, 6)
    model.roi_heads.mask_predictor = MaskRCNNPredictor(model.roi_heads.mask_predictor.conv5_mask.in_channels, 256, 6)
    return model


class MaskRCNNDetector:
    def __init__(self, checkpoint, config, device="auto"):
        import torch
        self.device = choose_device(device)
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        self.config = payload.get("config", config)
        self.model = create_maskrcnn(self.config)
        self.model.load_state_dict(payload["model"])
        self.model.to(self.device).eval()
        self.checkpoint = str(Path(checkpoint).resolve())

    def predict(self, rgb, score_threshold=None):
        import torch
        image = torch.from_numpy(rgb.copy()).permute(2,0,1).float().to(self.device)/255
        with torch.inference_mode():
            out = self.model([image])[0]
        threshold = self.config["detector"]["score_threshold"] if score_threshold is None else score_threshold
        keep = out["scores"] >= threshold
        result = {k: v[keep].detach().cpu().numpy() for k,v in out.items()}
        result["masks"] = result["masks"][:,0] >= self.config["detector"]["mask_threshold"]
        return result


class YOLODetector:
    def __init__(self, checkpoint, config, device="auto"):
        from ultralytics import YOLO
        self.model, self.config = YOLO(str(checkpoint)), config
        self.device = str(choose_device(device))
        self.checkpoint = str(Path(checkpoint).resolve())

    def predict(self, rgb, score_threshold=None):
        from PIL import Image
        threshold = self.config["detector"]["score_threshold"] if score_threshold is None else score_threshold
        pred = self.model.predict(source=Image.fromarray(rgb), conf=threshold, device=self.device,
                                  imgsz=self.config["detector"]["max_size"], retina_masks=True,
                                  max_det=self.config["detector"]["max_detections"],verbose=False)[0]
        h,w = rgb.shape[:2]
        if pred.masks is None:
            return {"boxes": np.zeros((0,4)), "scores": np.zeros(0), "labels": np.zeros(0,dtype=int), "masks": np.zeros((0,h,w),dtype=bool)}
        return {"boxes": pred.boxes.xyxy.cpu().numpy(), "scores": pred.boxes.conf.cpu().numpy(),
                "labels": pred.boxes.cls.cpu().numpy().astype(int)+1,
                "masks": pred.masks.data.cpu().numpy()>0.5}


class RGBDMaskRefinedDetector:
    """Keep Mask R-CNN boxes/classes; refine selected masks with measured RGB-D."""
    requires_depth = True
    def __init__(self,checkpoint,config,device='auto'):
        from .dense_pose import DenseRGBDEstimator
        self.base = MaskRCNNDetector(checkpoint,config,device)
        self.refiner = DenseRGBDEstimator(config['dense_pose']['checkpoint'],config,device)
        self.config,self.device = config,self.base.device
        self.checkpoint = self.base.checkpoint
        self.refined_labels = config['detector'].get('refined_labels',[5])

    def predict(self,rgb,score_threshold=None,depth=None,k=None):
        if depth is None or k is None:
            raise ValueError('RGB-D refinement requires measured depth and K')
        result = self.base.predict(rgb,score_threshold)
        for i,(box,label) in enumerate(zip(result['boxes'],result['labels'])):
            if int(label) in self.refined_labels:
                mask = self.refiner.refine_mask(rgb,depth,k,box,int(label))
                if mask.sum()>=10:
                    result['masks'][i] = mask
        return result


def load_detector(checkpoint, config, device="auto", architecture=None):
    cls = {'yolo':YOLODetector,'maskrcnn':MaskRCNNDetector,'rgbd_refined':RGBDMaskRefinedDetector}[architecture or config['detector']['architecture']]
    return cls(checkpoint, config, device)

