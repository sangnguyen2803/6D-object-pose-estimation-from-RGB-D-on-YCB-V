"""Direct CAD triangle collision checks using FCL, separate from point proxies."""
import numpy as np
from .collision import gripper_boxes


class MeshCollisionChecker:
    def __init__(self,mesh,pose):
        import fcl
        self.fcl = fcl
        self.mesh,self.pose = mesh,np.asarray(pose)
        if not hasattr(mesh,'_clutterpick_fcl_bvh'):
            model = fcl.BVHModel()
            model.beginModel()
            model.addSubModel(np.asarray(mesh.vertices),np.asarray(mesh.faces))
            model.endModel()
            mesh._clutterpick_fcl_bvh = model
        model = mesh._clutterpick_fcl_bvh
        self.target = fcl.CollisionObject(model,fcl.Transform(self.pose[:3,:3],self.pose[:3,3]))

    def reject_reason(self,candidate,config):
        final,pre = np.asarray(candidate["T_camera_gripper"]),np.asarray(candidate["T_camera_pregrasp"])
        if not np.allclose(final[:3,:3],pre[:3,:3]):
            raise ValueError('Swept-box approach requires fixed orientation')
        delta = (pre[:3,3]-final[:3,3])@final[:3,:3]
        for lo,hi in gripper_boxes(candidate['opening_width_m'],config['gripper']):
            # Exact swept volume for our fixed-orientation local-Z approach.
            # For an oblique translation this is a conservative enclosing box.
            low,high = lo+np.minimum(delta,0),hi+np.maximum(delta,0)
            center = (low+high)/2
            position = final[:3,:3]@center+final[:3,3]
            box = self.fcl.CollisionObject(self.fcl.Box(*(high-low)),self.fcl.Transform(final[:3,:3],position))
            request,result = self.fcl.CollisionRequest(),self.fcl.CollisionResult()
            if self.fcl.collide(self.target,box,request,result)>0:
                return 'target_mesh_swept_volume_collision'
            if self.mesh.is_watertight:
                object_center = (position-self.pose[:3,3])@self.pose[:3,:3]
                if self.mesh.contains(object_center[None]).any():
                    return "gripper_inside_target_solid"
        return None


def filter_mesh_candidates(candidates,mesh,pose,config):
    checker = MeshCollisionChecker(mesh,pose)
    accepted,rejected = [],[]
    for candidate in candidates:
        reason = checker.reject_reason(candidate,config)
        if reason:
            rejected.append({"grasp_id":candidate["grasp_id"],"reason":reason})
        else:
            accepted.append({**candidate,"target_mesh_collision_status":"passed_FCL_triangle_checks",
                             "validation_scope":"FCL_CAD_triangles_vs_swept_gripper_boxes; scene_from_observed_depth; no robot IK or physics"})
    return accepted,rejected


def filter_estimated_neighbors(grasps,poses,geometry,config):
    neighbors = {}
    for pose in poses:
        if pose['status']=='ok' and pose.get('observed_trimmed_rmse_m',float('inf'))<=config['pose']['max_observed_rmse_m']:
            mesh,_,_ = geometry.mesh(pose['obj_id'])
            neighbors[pose['instance_id']] = MeshCollisionChecker(mesh,pose['T_camera_object'])
    accepted,rejected = [],[]
    for grasp in grasps:
        target_id = grasp['target_instance_id']
        collision = next((identifier for identifier,checker in neighbors.items()
                          if identifier!=target_id and checker.reject_reason(grasp,config)),None)
        if collision:
            rejected.append({'grasp_id':grasp['grasp_id'],'target_instance_id':target_id,
                'reason':'estimated_neighbor_mesh_swept_collision','neighbor_instance_id':collision})
        else:
            accepted.append({**grasp,'neighbor_mesh_collision_status':'passed_estimated_CAD_checks',
                'estimated_neighbor_mesh_count':sum(identifier!=target_id for identifier in neighbors)})
    return accepted,rejected
