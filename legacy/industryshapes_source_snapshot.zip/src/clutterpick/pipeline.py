import time
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.optimize import linear_sum_assignment
from .common import resolve,write_json,read_json
from .data import load_rgbd
from .geometry import backproject,instance_cloud,voxel_downsample,write_ply,transform_points
from .pose import GeometricPoseEstimator,FoundationPoseEstimator
from .grasp import generate_candidates,require_observed_contact
from .collision import filter_candidates
from .evaluation import mask_iou,pose_errors
from .visualization import overlay,plot_scene


def reference_detections(frame):
    masks,boxes,labels = [],[],[]
    for obj in frame["instances"]:
        mask = np.array(Image.open(obj["mask_visib"]))>0
        y,x = np.nonzero(mask)
        if len(x):
            masks.append(mask); boxes.append([x.min(),y.min(),x.max()+1,y.max()+1]); labels.append(obj["obj_id"])
    h,w = np.array(Image.open(frame["rgb"])).shape[:2]
    return {"boxes":np.asarray(boxes).reshape(-1,4),"labels":np.array(labels),"scores":np.ones(len(masks)),
            "masks":np.stack(masks) if masks else np.zeros((0,h,w),dtype=bool)}


def match_references(items,frame):
    refs = [(o,np.array(Image.open(o["mask_visib"]))>0) for o in frame["instances"]]
    if not items or not refs:
        return {}
    costs = np.ones((len(items),len(refs)))
    for i,item in enumerate(items):
        for j,(obj,mask) in enumerate(refs):
            if item["obj_id"]==obj["obj_id"]:
                costs[i,j] = 1-mask_iou(item["mask"],mask)
    a,b = linear_sum_assignment(costs)
    return {int(i):(refs[j][0],1-costs[i,j]) for i,j in zip(a,b) if costs[i,j]<=0.5}


def run_frame(frame,config,detector=None,output="artifacts/inference",oracle_masks=False,pose_backend=None,plots=True,depth_extraction="mask",pose_checkpoint=None,runtime=None,export_clouds=True):
    if not oracle_masks and detector is None:
        raise ValueError("Prediction mode requires a trained detector checkpoint")
    directory = resolve(output)
    directory.mkdir(parents=True,exist_ok=True)
    for folder in ["masks","pointclouds"]:
        (directory/folder).mkdir(exist_ok=True)
    timings = {}
    started = time.perf_counter()
    rgb,depth,k = load_rgbd(frame)
    timings["preprocessing_s"] = time.perf_counter()-started
    begun = time.perf_counter()
    prediction = reference_detections(frame) if oracle_masks else detector.predict(rgb,depth=depth,k=k) if getattr(detector,'requires_depth',False) else detector.predict(rgb)
    timings["detection_s"] = time.perf_counter()-begun
    begun = time.perf_counter()
    scene_points,pixels = backproject(depth,k,None,config["geometry"]["depth_min_m"],config["geometry"]["depth_max_m"])
    scene_colors = rgb[pixels[:,0],pixels[:,1]]
    scene_points,scene_colors = voxel_downsample(scene_points,config["geometry"]["voxel_size_m"],scene_colors)
    timings["scene_geometry_s"] = time.perf_counter()-begun
    if export_clouds:
        write_ply(directory/"pointcloud.ply",scene_points,scene_colors)
    backend = pose_backend or config["pose"]["backend"]
    cache = runtime if runtime is not None else {}
    if backend=="rendered":
        from .rendered_pose import RenderedPoseEstimator
        if "rendered" not in cache:
            cache["rendered"] = RenderedPoseEstimator(config)
        estimator = cache["rendered"]
    else:
        if "geometry" not in cache:
            cache["geometry"] = GeometricPoseEstimator(config)
        estimator = cache["geometry"]
    foundation = None
    if backend=="foundationpose":
        if "foundationpose" not in cache:
            cache["foundationpose"] = FoundationPoseEstimator(config)
        foundation = cache["foundationpose"]
    rgb_pose = None
    dense_pose = None
    if backend=="dense_rgbd":
        from .dense_pose import DenseRGBDEstimator
        if "dense_pose" not in cache and detector is not None and hasattr(detector,'refiner'):
            cache['dense_pose'] = detector.refiner
            cache['dense_pose'].geometry = estimator
        if "dense_pose" not in cache:
            cache["dense_pose"] = DenseRGBDEstimator(pose_checkpoint or config["dense_pose"]["checkpoint"],config)
            cache["dense_pose"].geometry = estimator
        dense_pose = cache["dense_pose"]
    if backend in ["rgb_keypoints","rgbd_keypoints"]:
        from .rgb_pose import RGBKeypointEstimator
        if "rgb_pose" not in cache:
            cache["rgb_pose"] = RGBKeypointEstimator(resolve(pose_checkpoint or "artifacts/training/rgb_pose/best.pt"),config)
            cache["rgb_pose"].geometry = estimator
        rgb_pose = cache["rgb_pose"]
    items,poses,all_grasps,all_candidates,summaries = [],[],[],[],[]
    timings.update(geometry_s=0.,pose_s=0.,grasp_s=0.,collision_s=0.)
    for i,(box,label,score,mask) in enumerate(zip(prediction["boxes"],prediction["labels"],prediction["scores"],prediction["masks"])):
        instance_id = f"{frame['key']}/pred_{i:03d}"
        Image.fromarray(mask.astype(np.uint8)*255).save(directory/"masks"/f"instance_{i:03d}.png")
        begun = time.perf_counter()
        geometry_mask = mask
        if depth_extraction=="bbox":
            geometry_mask = np.zeros_like(mask)
            x1,y1,x2,y2 = np.asarray(box).astype(int)
            geometry_mask[max(y1,0):min(y2,mask.shape[0]),max(x1,0):min(x2,mask.shape[1])] = True
        elif depth_extraction!="mask":
            raise ValueError("depth_extraction must be mask or bbox")
        points,colors,diagnostics = instance_cloud(depth,k,geometry_mask,rgb,config)
        _,selected_pixels = backproject(depth,k,geometry_mask,config["geometry"]["depth_min_m"],config["geometry"]["depth_max_m"])
        diagnostics["selected_depth_pixels"] = len(selected_pixels)
        # Mask consistency diagnostic; GT contamination is computed separately in experiments.
        diagnostics["fraction_outside_predicted_mask"] = float((~mask[selected_pixels[:,0],selected_pixels[:,1]]).mean()) if len(selected_pixels) else None
        if export_clouds:
            write_ply(directory/"pointclouds"/f"instance_{i:03d}.ply",points,colors)
        timings["geometry_s"] += time.perf_counter()-begun
        item = {"instance_id":instance_id,"obj_id":int(label),"score":float(score),"box":box,"mask":mask,
                "_points":points,
                "mask_path":f"masks/instance_{i:03d}.png","geometry":diagnostics}
        items.append(item)
        begun = time.perf_counter()
        if dense_pose:
            pose = dense_pose.estimate_rgbd(rgb,depth,k,box,geometry_mask,int(label))
        elif foundation:
            pose = foundation.estimate_rgbd(rgb,depth,k,geometry_mask,int(label))
        elif rgb_pose:
            pose = rgb_pose.estimate_rgb(rgb,k,box,int(label))
            if backend=="rgbd_keypoints":
                pose = rgb_pose.refine_depth(pose,points,int(label))
        elif backend=="rendered":
            pose = estimator.estimate_rgbd(rgb,depth,k,geometry_mask,int(label),points)
        else:
            pose = estimator.estimate(points,int(label))
        timings["pose_s"] += time.perf_counter()-begun
        poses.append({"instance_id":instance_id,"obj_id":int(label),**pose})
        if pose["status"]!="ok":
            summaries.append({"instance_id":instance_id,"status":"pose_unreliable","generated":0,"accepted":0})
            continue
        fit_limit = config["grasp"].get("max_pose_fit_rmse_m")
        if fit_limit is not None and pose.get("observed_trimmed_rmse_m",float("inf"))>fit_limit:
            summaries.append({"instance_id":instance_id,"status":"pose_uncertainty_too_high_for_grasp","generated":0,"accepted":0})
            continue
        mesh,model_samples,_ = estimator.mesh(int(label))
        begun = time.perf_counter()
        candidates = generate_candidates(mesh,pose["T_camera_object"],instance_id,config,points)
        raw_count = len(candidates)
        candidates,support_rejections = require_observed_contact(candidates,points,config["grasp"].get("observed_contact_tolerance_m",.02))
        all_candidates.extend(candidates)
        timings["grasp_s"] += time.perf_counter()-begun
        # Target pixels are excluded from scene obstacles, then checked against full target CAD.
        obstacles,_ = backproject(depth,k,~mask,config["geometry"]["depth_min_m"],config["geometry"]["depth_max_m"])
        obstacles = voxel_downsample(obstacles,config["geometry"]["voxel_size_m"])
        target = transform_points(model_samples,pose["T_camera_object"])
        begun = time.perf_counter()
        collision_config = config
        if config["grasp"].get("collision_backend")=="mesh":
            import copy
            collision_config = copy.deepcopy(config)
            collision_config["grasp"]["output_limit"] = len(candidates)+1
            # Check measured target surfaces as well as the full fitted CAD.
            target = points
        accepted,rejected,accepted_count = filter_candidates(candidates,obstacles,target,collision_config)
        if config["grasp"].get("collision_backend")=="mesh" and accepted:
            from .mesh_collision import filter_mesh_candidates
            accepted,mesh_rejected = filter_mesh_candidates(accepted,mesh,pose["T_camera_object"],config)
            rejected += mesh_rejected
            accepted_count = len(accepted)
        timings["collision_s"] += time.perf_counter()-begun
        all_grasps.extend(accepted)
        summaries.append({"instance_id":instance_id,"status":"candidates_available" if accepted else "no_feasible_candidate",
                          "generated":raw_count,"collision_input_candidates":len(candidates),
                          "accepted":accepted_count,"exported":len(accepted),"rejections":support_rejections+rejected})
    if config['grasp'].get('collision_backend')=='mesh' and all_grasps:
        from .mesh_collision import filter_estimated_neighbors
        begun = time.perf_counter()
        neighbor_passed,neighbor_rejected = filter_estimated_neighbors(all_grasps,poses,estimator,config)
        grouped = {}
        by_instance = {summary['instance_id']:summary for summary in summaries}
        for rejected in neighbor_rejected:
            by_instance[rejected['target_instance_id']]['rejections'].append(rejected)
        for grasp in neighbor_passed:
            grouped.setdefault(grasp['target_instance_id'],[]).append(grasp)
        all_grasps = []
        for summary in summaries:
            if 'collision_input_candidates' not in summary:
                continue
            accepted = sorted(grouped.get(summary['instance_id'],[]),key=lambda g:g['score'],reverse=True)
            exported = accepted[:config['grasp']['output_limit']]
            summary.update(accepted=len(accepted),exported=len(exported),
                           status='candidates_available' if accepted else 'no_feasible_candidate')
            all_grasps.extend(exported)
        timings['collision_s'] += time.perf_counter()-begun
    all_grasps.sort(key=lambda g:g["score"],reverse=True)
    timings["inference_s_before_reference_evaluation"] = time.perf_counter()-started
    matched = match_references(items,frame)
    model_info = read_json(resolve(config["data"]["models"])/"models_info.json")
    diagnostics,geometry_evaluation = [],[]
    for i,(reference,iou) in matched.items():
        reference_mask = np.array(Image.open(reference["mask_visib"]))>0
        observed_points = items[i]["_points"]
        if len(observed_points):
            uvh = observed_points@k.T
            uv = np.rint(uvh[:,:2]/uvh[:,2:]).astype(int)
            uv[:,0] = np.clip(uv[:,0],0,depth.shape[1]-1)
            uv[:,1] = np.clip(uv[:,1],0,depth.shape[0]-1)
            contaminated = ~reference_mask[uv[:,1],uv[:,0]]
            contamination = float(contaminated.mean())
        else:
            contamination = None
        geometry_evaluation.append({"instance_id":items[i]["instance_id"],"reference_instance_id":reference["instance_id"],
                                    "retained_points":len(observed_points),"point_contamination_fraction":contamination,
                                    "mask_IoU":float(iou)})
        pose = poses[i]
        if "T_camera_object" not in pose:
            continue
        truth = np.eye(4)
        truth[:3,:3] = np.array(reference["R_m2c"]).reshape(3,3)
        truth[:3,3] = np.array(reference["t_m2c_mm"])/1000
        mesh,_,_ = estimator.mesh(reference["obj_id"])
        errors = pose_errors(mesh,np.asarray(pose["T_camera_object"]),truth)
        threshold = model_info[str(reference["obj_id"])]["diameter"]*0.001*0.1
        diagnostics.append({"instance_id":items[i]["instance_id"],"reference_instance_id":reference["instance_id"],
                            "mask_iou":float(iou),"pose_status":pose["status"],
                            "ADD_success_0_1d":errors["ADD_m"]<threshold,
                            "ADD_S_success_0_1d":errors["ADD_S_m"]<threshold,**errors})
    provenance = {"frame_key":frame["key"],"units":"m","coordinate_frame":"camera_BOP_x_right_y_down_z_forward",
                  "uses_ground_truth_masks":oracle_masks,"uses_ground_truth_pose_for_inference":False,
                  "ground_truth_pose_used_only_for_evaluation":True,
                  "detector_checkpoint":None if oracle_masks else detector.checkpoint,"pose_backend":backend,
                  "mask_refinement_checkpoint":detector.refiner.checkpoint if not oracle_masks and hasattr(detector,'refiner') else None,
                  "depth_extraction":depth_extraction,
                  "pose_checkpoint":dense_pose.checkpoint if dense_pose else rgb_pose.checkpoint if rgb_pose else None,
                  "grasp_generator":config["grasp"].get("generator","observed_surface_priority_best_antipodal_pair_v2"),
                  "config":config,"simulation_performed":False,"physical_success_measured":False}
    provenance["point_clouds_exported"] = export_clouds
    write_json(directory/"detection.json",{**provenance,"instances":[{k:v for k,v in x.items() if k not in ["mask","_points"]} for x in items]})
    write_json(directory/"poses.json",{**provenance,"instances":poses})
    write_json(directory/"grasps.json",{**provenance,"grasps":all_grasps,"instance_summaries":summaries})
    write_json(directory/"grasp_candidates.json",{**provenance,"candidates":all_candidates})
    write_json(directory/"pose_diagnostics.json",{"matched_instances":diagnostics,"gt_instance_count":len(frame["instances"]),
        "detected_instance_count":len(items),"matched_mask_iou50_count":len(matched),
        "scope":"diagnostic ADD/ADD-S; not official BOP AR; symmetry conventions unresolved"})
    write_json(directory/"geometry_diagnostics.json",{"instances":geometry_evaluation,
               "scope":"post-filter projected points compared to GT visible masks for evaluation only"})
    timings["pipeline_s_excluding_visualization"] = time.perf_counter()-started
    write_json(directory/"timing.json",timings)
    overlay(rgb,items,all_grasps,k,directory/"final_visualization.png",config["gripper"],oracle_masks,poses)
    if plots:
        plot_scene(scene_points,scene_colors,all_grasps,directory/"scene_3d.png",config["gripper"],poses,oracle_masks)
    if backend=="rendered" and runtime is None:
        estimator.close()
    return {"frame_key":frame["key"],"detections":len(items),"poses_ok":sum(p["status"]=="ok" for p in poses),
            "gt_instances":len(frame["instances"]),
            "candidate_count":sum(x["generated"] for x in summaries),"exported_grasps":len(all_grasps),
            "timing":timings,"output":str(directory),"oracle_masks":oracle_masks,"pose_diagnostics":diagnostics}
