"""Optional CAD render-and-compare refinement using observed RGB-D silhouette.

Uses an offscreen OpenGL context, no simulator or reference pose. The geometric
baseline remains available on machines without an OpenGL display/context.
"""
import numpy as np
from PIL import Image
from scipy.optimize import minimize
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
from .pose import GeometricPoseEstimator


class RenderedPoseEstimator(GeometricPoseEstimator):
    def __init__(self,config):
        super().__init__(config)
        self.renderer = None
        self.render_meshes = {}

    def estimate_rgbd(self,rgb,depth,k,mask,obj_id,points):
        import pyrender
        result = self.estimate(points,obj_id)
        if "T_camera_object" not in result:
            return result
        h,w = depth.shape
        render_w = 160
        render_h = int(h*render_w/w)
        observed = np.array(Image.fromarray(depth.astype(np.float32)).resize((render_w,render_h),Image.Resampling.NEAREST))
        visible = np.array(Image.fromarray(mask.astype(np.uint8)).resize((render_w,render_h),Image.Resampling.NEAREST))>0
        fx,fy,cx,cy = k[0,0]*render_w/w,k[1,1]*render_h/h,k[0,2]*render_w/w,k[1,2]*render_h/h
        if self.renderer is None:
            self.renderer = pyrender.OffscreenRenderer(render_w,render_h)
        self.renderer.viewport_width,self.renderer.viewport_height = render_w,render_h
        mesh,model,_ = self.mesh(obj_id)
        if obj_id not in self.render_meshes:
            reduced = mesh.simplify_quadric_decimation(face_count=5000) if len(mesh.faces)>5000 else mesh
            material = pyrender.MetallicRoughnessMaterial(doubleSided=True)
            self.render_meshes[obj_id] = pyrender.Mesh.from_trimesh(reduced,material=material,smooth=False)
        scene = pyrender.Scene()
        scene.add(pyrender.IntrinsicsCamera(fx,fy,cx,cy,znear=.05,zfar=3.),pose=np.eye(4))
        node = scene.add(self.render_meshes[obj_id],pose=np.eye(4))
        cv_to_gl = np.diag([1.,-1.,-1.,1.])
        valid_observed = visible & (observed>0)
        count = max(visible.sum(),1)
        calls = 0
        def cost(pose,details=False):
            nonlocal calls
            scene.set_pose(node,pose=cv_to_gl@pose)
            rendered = self.renderer.render(scene,flags=pyrender.RenderFlags.DEPTH_ONLY)
            calls += 1
            present = rendered>0
            covered = visible & present
            depth_overlap = valid_observed & present
            errors = np.abs(rendered[depth_overlap]-observed[depth_overlap])
            depth_error = float(np.minimum(errors,.08).mean()) if len(errors) else .08
            recall = float(covered.sum()/count)
            # Rendered surfaces hidden behind measured scene depth are not false visible pixels.
            foreground = present & ((observed==0) | (rendered<=observed+.015))
            false_visible = float((foreground & ~visible).sum()/max(foreground.sum(),1))
            value = depth_error+.05*(1-recall)+.04*false_visible
            return (value,depth_error,recall,false_visible) if details else value
        hypotheses = self.last_coarse_hypotheses+self.last_refined_hypotheses
        scored = sorted([(cost(pose),pose) for pose in hypotheses],key=lambda pair:pair[0])
        best_cost,best_pose = scored[0]
        for _,initial in scored[:3]:
            def objective(delta):
                pose = initial.copy()
                pose[:3,:3] = Rotation.from_rotvec(delta[:3]).as_matrix()@initial[:3,:3]
                pose[:3,3] = initial[:3,3]+delta[3:]
                return cost(pose)
            optimized = minimize(objective,np.zeros(6),method="Powell",
                bounds=[(-.6,.6)]*3+[(-.04,.04)]*3,
                options={"maxiter":8,"maxfev":220,"xtol":.002,"ftol":.005})
            if optimized.fun<best_cost:
                best_pose = initial.copy()
                best_pose[:3,:3] = Rotation.from_rotvec(optimized.x[:3]).as_matrix()@initial[:3,:3]
                best_pose[:3,3] = initial[:3,3]+optimized.x[3:]
                best_cost = float(optimized.fun)
        value,depth_error,recall,false_visible = cost(best_pose,True)
        distances = cKDTree(model).query((points-best_pose[:3,3])@best_pose[:3,:3])[0]
        trimmed = np.sort(distances)[:max(1,int(len(distances)*self.config["pose"]["trim_fraction"]))]
        result.update(backend="geometric_render_and_compare",T_camera_object=best_pose,
                      status="ok" if recall>.5 and depth_error<.025 else "poor_fit",
                      render_cost=value,render_depth_error_m=depth_error,
                      render_mask_recall=recall,render_false_visible_fraction=false_visible,render_calls=calls,
                      observed_trimmed_rmse_m=float(np.sqrt(np.mean(trimmed**2))),
                      observed_coverage_10mm=float(np.mean(distances<.01)))
        return result

    def close(self):
        if self.renderer is not None:
            self.renderer.delete()
            self.renderer = None
