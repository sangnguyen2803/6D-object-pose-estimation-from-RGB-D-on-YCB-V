"""Dense RGB-D object-coordinate prediction and robust 3D correspondence fitting.

Ground truth transforms are used only to build training targets. Inference uses
RGB, measured depth, predicted box/mask/class, K and CAD bounds.
"""
from pathlib import Path
import hashlib
import time
import zipfile
import numpy as np
from PIL import Image
from .common import resolve,read_json,write_json,set_seed
from .data import load_index,select_frames,load_rgbd
from .pose import rigid_fit,GeometricPoseEstimator,trimmed_icp
from .geometry import transform_points
from .detection import choose_device


def bounds(info):
    return (np.array([info['min_'+axis] for axis in 'xyz'])/1000,
            np.array([info['size_'+axis] for axis in 'xyz'])/1000)


def crop_rectangle(shape,box):
    h,w = shape
    x1,y1,x2,y2 = np.asarray(box,dtype=float)
    pad = .15*max(x2-x1,y2-y1)
    x1,y1 = max(0,int(np.floor(x1-pad))),max(0,int(np.floor(y1-pad)))
    x2,y2 = min(w,int(np.ceil(x2+pad))),min(h,int(np.ceil(y2+pad)))
    if x2<=x1 or y2<=y1:
        raise ValueError("Invalid dense pose crop")
    return x1,y1,x2,y2


def prepare_crop(rgb,depth,k,box,mask,size,diameter):
    import cv2
    x1,y1,x2,y2 = crop_rectangle(depth.shape,box)
    xx = x1+np.minimum((np.arange(size)*(x2-x1)/size).astype(int),x2-x1-1)
    yy = y1+np.minimum((np.arange(size)*(y2-y1)/size).astype(int),y2-y1-1)
    uu,vv = np.meshgrid(xx,yy)
    small_depth = depth[vv,uu]
    small_mask = mask[vv,uu]
    small_rgb = cv2.resize(rgb[y1:y2,x1:x2],(size,size),interpolation=cv2.INTER_LINEAR)
    depth_valid = (small_depth>.1) & (small_depth<2.)
    valid = small_mask & depth_valid
    median = np.median(small_depth[depth_valid]) if depth_valid.any() else 0.
    relative = np.where(depth_valid,np.clip((small_depth-median)/max(diameter,.01),-1,1),0)
    camera_points = np.stack(((uu-k[0,2])*small_depth/k[0,0],
                             (vv-k[1,2])*small_depth/k[1,1],small_depth),axis=-1)
    return small_rgb,relative.astype(np.float32),valid,camera_points.astype(np.float32),np.stack((uu,vv),axis=-1)


def input_tensor(rgb,relative,mask):
    import torch
    color = rgb.astype(np.float32)/255
    color = (color-np.array([.485,.456,.406],dtype=np.float32))/np.array([.229,.224,.225],dtype=np.float32)
    combined = np.concatenate((color,relative[...,None],mask.astype(np.float32)[...,None]),axis=-1)
    return torch.from_numpy(combined.transpose(2,0,1).copy())


def create_dense_network(pretrained=False):
    import torch
    from torch import nn
    from torch.nn import functional as F
    from torchvision.models import resnet18,ResNet18_Weights

    class DenseCoordinateNetwork(nn.Module):
        def __init__(self):
            super().__init__()
            self.backbone = resnet18(weights=ResNet18_Weights.DEFAULT if pretrained else None)
            original = self.backbone.conv1
            self.backbone.conv1 = nn.Conv2d(5,64,7,stride=2,padding=3,bias=False)
            with torch.no_grad():
                self.backbone.conv1.weight.zero_()
                self.backbone.conv1.weight[:,:3].copy_(original.weight)
            self.laterals = nn.ModuleList([nn.Conv2d(channels,64,1) for channels in [64,64,128,256,512]])
            self.head = nn.Sequential(nn.Conv2d(64,64,3,padding=1),nn.GroupNorm(8,64),nn.ReLU(),
                                      nn.Conv2d(64,20,1))

        def forward(self,images,labels):
            b = self.backbone
            stem = b.relu(b.bn1(b.conv1(images)))
            first = b.layer1(b.maxpool(stem)); second = b.layer2(first)
            third = b.layer3(second); fourth = b.layer4(third)
            features = [stem,first,second,third,fourth]
            pyramid = self.laterals[-1](features[-1])
            for level in range(3,-1,-1):
                pyramid = F.interpolate(pyramid,size=features[level].shape[-2:],mode='bilinear',align_corners=False)+self.laterals[level](features[level])
            raw = self.head(F.interpolate(pyramid,size=images.shape[-2:],mode='bilinear',align_corners=False))
            raw = raw.reshape(len(images),5,4,*images.shape[-2:])
            selected = raw[torch.arange(len(images),device=images.device),labels-1]
            return selected[:,:3].sigmoid(),selected[:,3]
    return DenseCoordinateNetwork()


class DenseCoordinateDataset:
    def __init__(self,frames,info,config,training=False):
        self.info,self.config,self.training = info,config,training
        self.items = [(frame,obj) for frame in frames for obj in frame['instances']
                      if obj['visib_fract']>=.1 and obj['rotation_orthogonality_error']<=1e-3 and obj.get('px_count_visib',0)>=50]
        self.cache = resolve(config['dense_pose']['cache'])
        self.cache.mkdir(parents=True,exist_ok=True)
        from collections import OrderedDict
        import threading
        self.frame_cache,self.frame_lock = OrderedDict(),threading.Lock()

    def __len__(self):
        return len(self.items)

    def arrays(self,index):
        frame,obj = self.items[index]
        size = self.config['dense_pose']['crop_size']
        digest = hashlib.sha256((obj['instance_id']+f'/dense_v3/{size}').encode()).hexdigest()
        path = self.cache/(digest+'.npz')
        cached = False
        if path.exists():
            try:
                with np.load(path) as payload:
                    rgb,relative,valid,target,input_mask = [payload[name] for name in ['rgb','relative','valid','target','mask']]
                cached = True
            except (ValueError,OSError,EOFError,zipfile.BadZipFile):
                pass  # Regenerate interrupted local cache writes from audited data.
        if cached:
            rgb,relative,target = rgb.copy(),relative.astype(np.float32),target.astype(np.float32)
            valid = valid.astype(bool)
            input_mask = input_mask.astype(bool)
        else:
            with self.frame_lock:
                image_data = self.frame_cache.get(frame['key'])
                if image_data is not None:
                    self.frame_cache.move_to_end(frame['key'])
            if image_data is None:
                image_data = load_rgbd(frame)
                with self.frame_lock:
                    self.frame_cache[frame['key']] = image_data
                    while len(self.frame_cache)>8:
                        self.frame_cache.popitem(last=False)
            rgb,depth,k = image_data
            mask = np.asarray(Image.open(obj['mask_visib']))>0
            y,x = np.nonzero(mask)
            rgb,relative,valid,camera,pixels = prepare_crop(rgb,depth,k,[x.min(),y.min(),x.max()+1,y.max()+1],mask,size,self.info[str(obj['obj_id'])]['diameter']/1000)
            input_mask = mask[pixels[...,1],pixels[...,0]].copy()  # Independent of pose and depth availability.
            local = (camera-np.asarray(obj['t_m2c_mm'])/1000)@np.asarray(obj['R_m2c']).reshape(3,3)
            minimum,extent = bounds(self.info[str(obj['obj_id'])])
            target = (local-minimum)/extent
            valid &= (target>=-.03).all(axis=-1) & (target<=1.03).all(axis=-1)
            target = np.clip(target,0,1).astype(np.float32)
            temporary = path.with_suffix('.tmp')
            with temporary.open('wb') as stream:
                np.savez_compressed(stream,rgb=rgb,relative=relative.astype(np.float16),valid=valid,target=target.astype(np.float16),mask=input_mask)
            temporary.replace(path)
        return rgb,relative,valid,target,input_mask

    def __getitem__(self,index):
        import torch
        import cv2
        _,obj = self.items[index]
        rgb,relative,valid,target,input_mask = self.arrays(index)
        size = self.config['dense_pose']['crop_size']
        segmentation = input_mask.copy()
        if self.training:
            from PIL import ImageEnhance
            augmented = Image.fromarray(rgb)
            for operator in [ImageEnhance.Brightness,ImageEnhance.Contrast,ImageEnhance.Color]:
                augmented = operator(augmented).enhance(float(np.random.uniform(.7,1.3)))
            rgb = np.asarray(augmented)
            relative += np.random.normal(0,.007,relative.shape).astype(np.float32)*valid
            if np.random.random()<.5:
                kernel = np.ones((3,3),dtype=np.uint8)
                input_mask = (cv2.erode if np.random.random()<.5 else cv2.dilate)(input_mask.astype(np.uint8),kernel)>0
            if np.random.random()<.4:
                input_mask[:] = True  # Learn foreground from RGB-D even with a box-only prompt.
            # Small affine perturbations emulate localization/crop errors. The
            # same transform is applied to inputs and correspondence targets.
            scale = float(np.random.uniform(.88,1.12))
            matrix = cv2.getRotationMatrix2D((size/2,size/2),float(np.random.uniform(-8,8)),scale)
            matrix[:,2] += np.random.uniform(-6,6,2)
            rgb = cv2.warpAffine(rgb,matrix,(size,size),borderMode=cv2.BORDER_REFLECT_101)
            relative = cv2.warpAffine(relative,matrix,(size,size),flags=cv2.INTER_NEAREST)
            input_mask = cv2.warpAffine(input_mask.astype(np.uint8),matrix,(size,size),flags=cv2.INTER_NEAREST)>0
            valid = cv2.warpAffine(valid.astype(np.uint8),matrix,(size,size),flags=cv2.INTER_NEAREST)>0
            segmentation = cv2.warpAffine(segmentation.astype(np.uint8),matrix,(size,size),flags=cv2.INTER_NEAREST)>0
            target = cv2.warpAffine(target,matrix,(size,size),flags=cv2.INTER_NEAREST)
        return (input_tensor(rgb,relative,input_mask),torch.tensor(obj['obj_id'],dtype=torch.long),
                torch.from_numpy(target.transpose(2,0,1).copy()),torch.from_numpy(valid.copy()),torch.from_numpy(segmentation.copy()))


def balanced_validation_frames(index,splits,limit,seed):
    ids = splits['val']
    real = [i for i in ids if not index['frames'][i]['group'].startswith('pbr')]
    synthetic = [i for i in ids if index['frames'][i]['group'].startswith('pbr')]
    if real and synthetic:
        return select_frames(index,real,limit//2,seed)+select_frames(index,synthetic,limit-limit//2,seed)
    return select_frames(index,ids,limit,seed)


def train_dense_pose(config,epochs=None,resume=None,device='auto'):
    import torch
    from torch.utils.data import DataLoader,WeightedRandomSampler
    from collections import Counter
    set_seed(config['seed']); torch.set_num_threads(4)
    device = choose_device(device)
    index,splits = load_index(config)
    info = read_json(resolve(config['data']['models'])/'models_info.json')
    cfg = config['dense_pose']
    train = DenseCoordinateDataset(select_frames(index,splits['train']),info,config,True)
    validation_frames = balanced_validation_frames(index,splits,cfg['validation_frames'],config['seed'])
    val = DenseCoordinateDataset(validation_frames,info,config)
    counts = Counter(obj['obj_id'] for _,obj in train.items)
    weights = [1/counts[obj['obj_id']] for _,obj in train.items]
    sampler = WeightedRandomSampler(weights,cfg['samples_per_epoch'],replacement=True)
    loader = DataLoader(train,batch_size=cfg['batch_size'],sampler=sampler,num_workers=0,pin_memory=device.type=='cuda')
    validation = DataLoader(val,batch_size=cfg['batch_size'],num_workers=0)
    network = create_dense_network(resume is None).to(device)
    optimizer = torch.optim.AdamW(network.parameters(),lr=cfg['learning_rate'],weight_decay=1e-4)
    count = epochs or cfg['epochs']
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=count,eta_min=cfg['learning_rate']*.05)
    scaler = torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
    directory = resolve(cfg['output']); directory.mkdir(parents=True,exist_ok=True)
    history,best,start = [],float('inf'),0
    if resume:
        payload = torch.load(resolve(resume),map_location='cpu',weights_only=False)
        if payload.get('target_cache_version') != 'dense_v3':
            raise ValueError('Resume checkpoint must use dense_v3 RGB-D foreground supervision')
        network.load_state_dict(payload['model']); optimizer.load_state_dict(payload['optimizer'])
        scheduler.load_state_dict(payload['scheduler']); scaler.load_state_dict(payload['scaler'])
        history,start,best = payload['history'],payload['epoch'],payload['best_validation_error']
        if 'rng_state' in payload:
            import random
            random.setstate(payload['rng_state']['python']); np.random.set_state(payload['rng_state']['numpy'])
            torch.set_rng_state(payload['rng_state']['torch'])
            if device.type=='cuda' and payload['rng_state'].get('cuda'):
                torch.cuda.set_rng_state_all(payload['rng_state']['cuda'])
    for epoch in range(start,count):
        network.train(); total=0.; begun=time.perf_counter()
        from .training import prefetched_batches
        batches = prefetched_batches(loader) if cfg.get('threaded_prefetch',True) else loader
        for step,(images,labels,target,valid,segmentation) in enumerate(batches):
            images,labels,target,valid,segmentation = images.to(device),labels.to(device),target.to(device),valid.to(device),segmentation.to(device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,enabled=device.type=='cuda'):
                predicted,confidence = network(images,labels)
                coordinates = torch.nn.functional.smooth_l1_loss(predicted,target,reduction='none').mean(dim=1)
                counts_valid = valid.sum(dim=(1,2))
                eligible = counts_valid>=16
                per_instance = (coordinates*valid).sum(dim=(1,2))/counts_valid.clamp(min=1)
                coordinate_loss = per_instance[eligible].mean() if eligible.any() else predicted.sum()*0
                # Foreground supervision is the visible mask, independently of
                # coordinate validity or missing/reflective depth measurements.
                positive = -(torch.nn.functional.logsigmoid(confidence)*segmentation).sum(dim=(1,2))/segmentation.sum(dim=(1,2)).clamp(min=1)
                negative = -(torch.nn.functional.logsigmoid(-confidence)*(~segmentation)).sum(dim=(1,2))/(~segmentation).sum(dim=(1,2)).clamp(min=1)
                confidence_loss = ((positive+negative)*.5).mean()
                loss = coordinate_loss+confidence_loss*.05
            if not torch.isfinite(loss):
                raise RuntimeError('Non-finite dense coordinate loss')
            scaler.scale(loss).backward(); scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(network.parameters(),10)
            scaler.step(optimizer); scaler.update()
            total += float(loss.item())
            if step%50==0:
                print(f'dense epoch={epoch+1}/{count} step={step}/{len(loader)} loss={loss.item():.5f} elapsed={time.perf_counter()-begun:.1f}s',flush=True)
        scheduler.step(); network.eval()
        per_group = {'real':[],'pbr':[]}
        position=0
        with torch.inference_mode():
            for images,labels,target,valid,segmentation in validation:
                predicted,_ = network(images.to(device),labels.to(device))
                squared = ((predicted.cpu()-target)**2).mean(dim=1)
                for i in range(len(images)):
                    group = 'pbr' if val.items[position][0]['group'].startswith('pbr') else 'real'
                    if valid[i].any():
                        per_group[group].append(float(squared[i][valid[i]].mean().sqrt()))
                    position += 1
        group_errors = {name:float(np.mean(values)) for name,values in per_group.items() if values}
        score = .7*group_errors['real']+.3*group_errors['pbr'] if len(group_errors)==2 else np.mean(list(group_errors.values()))
        history.append({'epoch':epoch+1,'training_loss':total/len(loader),'validation_normalized_coordinate_rmse':float(score),
                        'validation_by_source':group_errors,'training_seconds':time.perf_counter()-begun,
                        'learning_rate_next_epoch':optimizer.param_groups[0]['lr'],
                        'peak_allocated_vram_GB':torch.cuda.max_memory_allocated()/1e9 if device.type=='cuda' else None})
        best = min(best,float(score))
        import random
        payload = {'model':network.state_dict(),'optimizer':optimizer.state_dict(),'scheduler':scheduler.state_dict(),
                   'scaler':scaler.state_dict(),'config':config,'model_info':info,'epoch':epoch+1,'history':history,
                   'best_validation_error':best,'training_instances':len(train),'validation_instances':len(val),
                   'training_frame_keys':[index['frames'][i]['key'] for i in splits['train']],
                   'validation_frame_keys':[frame['key'] for frame in validation_frames],
                   'target_cache_version':'dense_v3','foreground_supervision':'GT visible mask independent of valid coordinate targets',
                   'dataset_revision':index['revision'],'torch_version':torch.__version__,'device':str(device),
                   'ground_truth_poses_used_only_as_training_targets':True}
        payload['rng_state'] = {'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state(),
                                'cuda':torch.cuda.get_rng_state_all() if device.type=='cuda' else None}
        torch.save(payload,directory/'last.pt')
        if float(score)<=best:
            torch.save(payload,directory/'best.pt')
        write_json(directory/'history.json',history)
        print(f'dense epoch={epoch+1} validation={score:.4f} by_source={group_errors}',flush=True)
    return directory/'best.pt'


def robust_correspondence_pose(model,camera,config,seed=42):
    """Reject correspondence outliers with proper-rigid-transform RANSAC."""
    if len(model)<config['min_inliers']:
        return None,np.zeros(len(model),dtype=bool)
    rng = np.random.default_rng(seed)
    threshold = config['correspondence_threshold_m']
    best_pose,best_keep,best_count = None,None,0
    for _ in range(config['ransac_iterations']):
        ids = rng.choice(len(model),3,replace=False)
        source,target = model[ids],camera[ids]
        if np.linalg.norm(np.cross(source[1]-source[0],source[2]-source[0]))<1e-5:
            continue
        first = np.linalg.norm(source[:,None]-source[None],axis=-1)
        second = np.linalg.norm(target[:,None]-target[None],axis=-1)
        if np.max(np.abs(first-second))>threshold*2:
            continue
        pose = rigid_fit(source,target)
        residuals = np.linalg.norm(transform_points(model,pose)-camera,axis=1)
        keep = residuals<threshold
        if keep.sum()>best_count:
            best_count = int(keep.sum()); best_keep,best_pose = keep,pose
    if best_pose is None:
        return None,np.zeros(len(model),dtype=bool)
    for _ in range(4):
        if best_keep.sum()<3:
            break
        best_pose = rigid_fit(model[best_keep],camera[best_keep])
        best_keep = np.linalg.norm(transform_points(model,best_pose)-camera,axis=1)<threshold
    return best_pose,best_keep


class DenseRGBDEstimator:
    def __init__(self,checkpoint,config,device='auto'):
        import torch
        self.device = choose_device(device)
        self.payload = torch.load(resolve(checkpoint),map_location='cpu',weights_only=False)
        self.network = create_dense_network(False)
        self.network.load_state_dict(self.payload['model']); self.network.to(self.device).eval()
        self.config,self.checkpoint = config,str(resolve(checkpoint))
        self.geometry = GeometricPoseEstimator(config)

    def predict_crop(self,rgb,depth,k,box,mask,obj_id):
        import torch
        cfg = self.config['dense_pose']
        info = self.payload['model_info'][str(obj_id)]
        color,relative,valid,camera,pixels = prepare_crop(rgb,depth,k,box,mask,cfg['crop_size'],info['diameter']/1000)
        prompt = mask[pixels[...,1],pixels[...,0]]
        with torch.inference_mode():
            predicted,confidence = self.network(input_tensor(color,relative,prompt)[None].to(self.device),torch.tensor([obj_id],device=self.device))
        coordinates = predicted[0].cpu().numpy().transpose(1,2,0)
        scores = confidence[0].sigmoid().cpu().numpy()
        return coordinates,scores,valid,camera

    def refine_mask(self,rgb,depth,k,box,obj_id):
        import cv2
        _,scores,_,_ = self.predict_crop(rgb,depth,k,box,np.ones(depth.shape,dtype=bool),obj_id)
        x1,y1,x2,y2 = crop_rectangle(depth.shape,box)
        probabilities = cv2.resize(scores,(x2-x1,y2-y1),interpolation=cv2.INTER_LINEAR)
        mask = np.zeros(depth.shape,dtype=bool)
        mask[y1:y2,x1:x2] = probabilities>self.config.get('detector',{}).get('refinement_mask_threshold',.5)
        return mask

    def estimate_rgbd(self,rgb,depth,k,box,mask,obj_id):
        cfg = self.config['dense_pose']
        info = self.payload['model_info'][str(obj_id)]
        coordinates,scores,valid,camera = self.predict_crop(rgb,depth,k,box,mask,obj_id)
        selected = valid & (scores>.5)
        minimum,extent = bounds(info)
        model_points = coordinates[selected]*extent+minimum
        camera_points = camera[selected]
        if len(model_points)>1200:
            ids = np.random.default_rng(self.config['seed']).choice(len(model_points),1200,replace=False)
            model_points,camera_points = model_points[ids],camera_points[ids]
        pose,inliers = robust_correspondence_pose(model_points,camera_points,cfg,self.config['seed'])
        if pose is None or inliers.sum()<cfg['min_inliers']:
            return {'status':'dense_correspondence_failed','backend':'dense_rgbd','uses_ground_truth_pose':False,
                    'correspondence_count':len(model_points),'inlier_count':int(inliers.sum())}
        original_rmse = float(np.sqrt(np.mean(np.sum((transform_points(model_points[inliers],pose)-camera_points[inliers])**2,axis=1))))
        _,cad,_ = self.geometry.mesh(obj_id)
        refined,depth_rmse,coverage = trimmed_icp(cad,camera_points[inliers],pose,self.config['pose']['icp_iterations'],
                                               self.config['pose']['correspondence_limit_m'],self.config['pose']['trim_fraction'])
        refined_rmse = float(np.sqrt(np.mean(np.sum((transform_points(model_points[inliers],refined)-camera_points[inliers])**2,axis=1))))
        used_refinement = refined_rmse<=original_rmse+.001
        if used_refinement:
            pose = refined
        else:
            _,depth_rmse,coverage = trimmed_icp(cad,camera_points[inliers],pose,0,self.config['pose']['correspondence_limit_m'],self.config['pose']['trim_fraction'])
        correspondence_rmse = refined_rmse if used_refinement else original_rmse
        fraction = float(inliers.mean())
        ok = fraction>=cfg['min_inlier_fraction'] and correspondence_rmse<cfg['max_correspondence_rmse_m']
        return {'status':'ok' if ok else 'poor_fit','backend':'dense_rgbd_correspondence_ransac',
                'T_camera_object':pose,'correspondence_count':len(model_points),'inlier_count':int(inliers.sum()),
                'inlier_fraction':fraction,'correspondence_rmse_m':correspondence_rmse,
                'observed_trimmed_rmse_m':depth_rmse,'observed_coverage_10mm':coverage,
                'depth_icp_update_accepted':bool(used_refinement),'uses_ground_truth_pose':False,
                'uses_depth_for_pose':True,'pose_checkpoint':self.checkpoint}
