"""RGB-D industrial perception and grasp planning."""
__version__ = "0.1.0"

