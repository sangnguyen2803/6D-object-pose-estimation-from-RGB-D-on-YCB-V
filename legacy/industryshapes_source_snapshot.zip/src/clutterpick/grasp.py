"""Antipodal contact sampling for a parameterized parallel-jaw gripper."""
import numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from .pose import sample_mesh
from .geometry import transform_points


def generate_candidates(mesh,object_pose,instance_id,config,observed_points=None):
    if config["grasp"].get("generator")=="ray_antipodal":
        return generate_ray_candidates(mesh,object_pose,instance_id,config,observed_points)
    cfg,g = config["grasp"],config["gripper"]
    points,normals = sample_mesh(mesh,cfg["surface_samples"],config["seed"])
    tree = cKDTree(points)
    rng = np.random.default_rng(config["seed"])
    candidates = []
    cos_limit = np.cos(np.arctan(g["friction_coefficient"]))
    anchors = rng.permutation(len(points))
    if observed_points is not None and len(observed_points):
        world_points = transform_points(points,object_pose)
        distances,_ = cKDTree(observed_points).query(world_points)
        # Favor visible, supported surfaces before using hidden CAD surfaces.
        anchors = np.argsort(distances,kind="stable")
    for i in anchors:
        neighbors = tree.query_ball_point(points[i],g["max_opening_m"]-0.002)
        if not neighbors:
            continue
        neighbors = np.asarray(neighbors)
        differences = points[neighbors]-points[i]
        widths = np.linalg.norm(differences,axis=1)
        axes = differences/np.maximum(widths[:,None],1e-12)
        a_alignment = axes@(-normals[i])
        b_alignment = np.sum(normals[neighbors]*axes,axis=1)
        eligible = (widths>=cfg["contact_min_width_m"]) & (np.minimum(a_alignment,b_alignment)>=cos_limit)
        ranks = np.argsort(-(a_alignment+b_alignment),kind="stable")
        for rank in ranks[eligible[ranks]][:1]:
            j = neighbors[rank]
            difference = points[j]-points[i]
            width = np.linalg.norm(difference)
            if width<cfg["contact_min_width_m"]:
                continue
            axis = difference/width
            alignment_a = float(np.dot(-normals[i],axis))
            alignment_b = float(np.dot(normals[j],axis))
            if min(alignment_a,alignment_b)<cos_limit:
                continue
            center = (points[i]+points[j])/2
            x = object_pose[:3,:3]@axis
            z = np.array([0.,0.,1.])-x*x[2]
            if np.linalg.norm(z)<0.1:
                z = np.array([0.,1.,0.])-x*x[1]
            z /= np.linalg.norm(z)
            y = np.cross(z,x)
            base = np.column_stack((x,y,z))
            for roll in [0,np.pi/2,np.pi,3*np.pi/2]:
                rotation = base@Rotation.from_rotvec(np.array([roll,0,0])).as_matrix()
                pose = np.eye(4)
                pose[:3,:3] = rotation
                pose[:3,3] = transform_points(center[None],object_pose)[0]
                pregrasp = pose.copy()
                pregrasp[:3,3] -= rotation[:,2]*cfg["approach_distance_m"]
                candidates.append({"grasp_id": f"{instance_id}/g{len(candidates):03d}","target_instance_id": instance_id,
                    "frame": "camera", "units": "m", "T_camera_gripper": pose,
                    "T_camera_pregrasp": pregrasp,"opening_width_m": float(width+0.002),
                    "contact_width_m": float(width), "approach_direction": rotation[:,2],
                    "contacts_camera": transform_points(points[[i,j]],object_pose),
                    "contact_score": float((alignment_a+alignment_b)/2), "quality_is_probability": False})
                if len(candidates)>=cfg["candidate_limit"]:
                    return candidates
            break
    return candidates


def generate_ray_candidates(mesh,object_pose,instance_id,config,observed_points=None):
    """Use the first exit surface along an inward normal, with spaced anchors."""
    cfg,g = config["grasp"],config["gripper"]
    # Open scan meshes have no reliable entry/exit pair. A closed convex
    # envelope provides conservative proposals; original CAD is still checked.
    proposal_mesh = mesh if mesh.is_watertight else mesh.convex_hull
    if not hasattr(mesh,'_clutterpick_vertex_tree'):
        mesh._clutterpick_vertex_tree = cKDTree(np.asarray(mesh.vertices))
    original_surface = mesh._clutterpick_vertex_tree
    points,normals = sample_mesh(proposal_mesh,cfg["surface_samples"],config["seed"])
    world = transform_points(points,object_pose)
    order = np.random.default_rng(config["seed"]).permutation(len(points))
    if observed_points is not None and len(observed_points):
        distances = cKDTree(observed_points).query(world)[0]
        order = np.argsort(distances,kind="stable")
    anchors = []
    spacing = cfg.get("anchor_spacing_m",.012)
    for i in order:
        if not anchors or np.linalg.norm(points[anchors]-points[i],axis=1).min()>=spacing:
            anchors.append(i)
        if len(anchors)>=200:
            break
    anchors = np.asarray(anchors,dtype=int)
    origins = points[anchors]+normals[anchors]*.0002
    directions = -normals[anchors]
    locations,rays,triangles = proposal_mesh.ray.intersects_location(origins,directions,multiple_hits=True)
    candidates = []
    cos_limit = np.cos(np.arctan(g["friction_coefficient"]))
    opening_clearance = cfg.get('opening_clearance_m',.002)
    for ray,i in enumerate(anchors):
        selected = np.flatnonzero(rays==ray)
        if not len(selected):
            continue
        widths = np.linalg.norm(locations[selected]-points[i],axis=1)
        selected = selected[np.argsort(widths)]
        # The first intersection beyond the entry is the exit, not a distant body.
        selected = [j for j in selected if np.linalg.norm(locations[j]-points[i])>.001]
        if not selected:
            continue
        j = selected[0]
        p2 = locations[j]
        width = np.linalg.norm(p2-points[i])
        if not cfg["contact_min_width_m"]<=width<=g["max_opening_m"]-opening_clearance:
            continue
        axis = (p2-points[i])/width
        opposing = float(proposal_mesh.face_normals[triangles[j]]@axis)
        if opposing<cos_limit:
            continue
        contact_distances = original_surface.query(np.stack((points[i],p2)))[0]
        distance_method = 'vertex_distance_upper_bound'
        if contact_distances.max()>cfg.get('cad_contact_tolerance_m',.004):
            _,contact_distances,_ = mesh.nearest.on_surface(np.stack((points[i],p2)))
            distance_method = 'exact_triangle_surface'
        if contact_distances.max()>cfg.get('cad_contact_tolerance_m',.004):
            continue
        x = object_pose[:3,:3]@axis
        z = np.array([0.,0.,1.])-x*x[2]
        if np.linalg.norm(z)<.1:
            z = np.array([0.,1.,0.])-x*x[1]
        z /= np.linalg.norm(z)
        base = np.column_stack((x,np.cross(z,x),z))
        for roll in np.linspace(0,2*np.pi,cfg.get("approach_rolls",8),endpoint=False):
            pose = np.eye(4)
            pose[:3,:3] = base@Rotation.from_rotvec([roll,0,0]).as_matrix()
            pose[:3,3] = transform_points(((points[i]+p2)/2)[None],object_pose)[0]
            pre = pose.copy()
            pre[:3,3] -= pose[:3,2]*cfg["approach_distance_m"]
            candidates.append({"grasp_id":f"{instance_id}/g{len(candidates):03d}","target_instance_id":instance_id,
                "frame":"camera","units":"m","T_camera_gripper":pose,"T_camera_pregrasp":pre,
                "opening_width_m":float(width+opening_clearance),"contact_width_m":float(width),
                "closing_width_m":float(width),"gripper_state":"open_at_approach_endpoint","closing_motion_validated":False,
                "approach_direction":pose[:3,2],"contacts_camera":transform_points(np.stack((points[i],p2)),object_pose),
                "contact_score":float((1+opposing)/2),"quality_is_probability":False,"generator":"ray_exit_antipodal",
                "proposal_surface":"original_closed_CAD" if mesh.is_watertight else "convex_envelope_of_open_scan",
                "contacts_on_original_surface_verified":True,
                "original_CAD_contact_distances_m":contact_distances,"CAD_contact_distance_method":distance_method})
            if len(candidates)>=cfg["candidate_limit"]:
                return candidates
    return candidates


def require_observed_contact(candidates,observed_points,tolerance):
    """At least one modeled contact must be supported by actual target depth."""
    if not len(observed_points):
        return [],[{"grasp_id":c["grasp_id"],"reason":"no_observed_contact_support"} for c in candidates]
    tree = cKDTree(observed_points)
    accepted,rejected = [],[]
    for candidate in candidates:
        distances,_ = tree.query(np.asarray(candidate["contacts_camera"]))
        if distances.min()<=tolerance:
            accepted.append({**candidate,"observed_contact_distances_m":distances})
        else:
            rejected.append({"grasp_id":candidate["grasp_id"],"reason":"no_observed_contact_support"})
    return accepted,rejected
