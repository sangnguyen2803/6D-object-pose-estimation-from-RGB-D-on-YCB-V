from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw

PALETTE = [(239,68,68),(59,130,246),(16,185,129),(245,158,11),(168,85,247)]


def project(points,k):
    points = np.asarray(points)
    uv = points@k.T
    valid = points[:,2]>0.01
    return uv[:,:2]/np.maximum(uv[:,2:3],0.01),valid


def overlay(rgb,detections,grasps,k,path,gripper,reference=False,poses=None):
    from .collision import gripper_vertices
    array = rgb.copy()
    for item in detections:
        color = np.array(PALETTE[(item["obj_id"]-1)%5])
        mask = item["mask"]
        array[mask] = (array[mask]*0.5+color*0.5).astype(np.uint8)
    image = Image.fromarray(array)
    draw = ImageDraw.Draw(image)
    for item in detections:
        box = item["box"]
        draw.rectangle(tuple(box),outline=PALETTE[(item["obj_id"]-1)%5],width=2)
        draw.text((box[0],max(0,box[1]-12)),f"obj {item['obj_id']} {item['score']:.2f}",fill="white")
    for item in poses or []:
        if "T_camera_object" not in item:
            continue
        pose = np.asarray(item["T_camera_object"])
        axes = np.vstack((pose[:3,3],pose[:3,3]+pose[:3,:3].T*.04))
        uv,valid = project(axes,k)
        for j,color in enumerate([(255,60,60),(60,255,60),(60,120,255)]):
            if valid[0] and valid[j+1]:
                draw.line([tuple(uv[0]),tuple(uv[j+1])],fill=color,width=3)
    if grasps:
        best = max(grasps,key=lambda g:g["score"])
        vertices = gripper_vertices(best,gripper)
        uv,valid = project(vertices,k)
        edges = [(0,1),(0,2),(0,4),(1,3),(1,5),(2,3),(2,6),(3,7),(4,5),(4,6),(5,7),(6,7)]
        for offset in [0,8,16]:
            for a,b in edges:
                if valid[offset+a] and valid[offset+b]:
                    draw.line([tuple(uv[offset+a]),tuple(uv[offset+b])],fill=(0,255,255),width=2)
        points = np.stack((np.asarray(best["T_camera_pregrasp"])[:3,3],np.asarray(best["T_camera_gripper"])[:3,3]))
        projected,visible = project(points,k)
        if visible.all():
            draw.line([tuple(x) for x in projected],fill=(255,255,0),width=3)
    draw.rectangle((0,0,image.width,22),fill=(20,20,20))
    draw.text((6,5),"REFERENCE MASK DIAGNOSTIC" if reference else "PREDICTED MASKS / GEOMETRIC GRASP CANDIDATES",fill="white")
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    image.save(path)


def plot_scene(points,colors,grasps,path,gripper,poses=None,reference=False):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from .collision import gripper_vertices
    fig = plt.figure(figsize=(9,7))
    ax = fig.add_subplot(projection="3d")
    stride = max(1,len(points)//12000)
    cloud = points[::stride]
    if len(cloud):
        ax.scatter(cloud[:,0],cloud[:,1],cloud[:,2],c=colors[::stride]/255,s=0.4)
    if grasps:
        best = max(grasps,key=lambda g:g["score"])
        vertices = gripper_vertices(best,gripper)
        ax.scatter(vertices[:,0],vertices[:,1],vertices[:,2],c="red",s=15)
        p = np.asarray(best["T_camera_gripper"])[:3,3]
        z = np.asarray(best["approach_direction"])
        ax.quiver(*(p-z*0.08),*(z*0.08),color="red")
    for item in poses or []:
        if "T_camera_object" in item:
            pose = np.asarray(item["T_camera_object"])
            for i,color in enumerate(["red","green","blue"]):
                ax.quiver(*pose[:3,3],*(pose[:3,i]*.04),color=color)
    title = "REFERENCE MASK DIAGNOSTIC" if reference else "Visible scene and selected geometric grasp"
    ax.set(xlabel="camera X (m)",ylabel="camera Y (m)",zlabel="camera Z (m)",title=title)
    fig.tight_layout()
    fig.savefig(path,dpi=160)
    plt.close(fig)
