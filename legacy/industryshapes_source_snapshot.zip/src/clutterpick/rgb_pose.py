"""Known-CAD RGB keypoint regression + PnP; optional depth ICP refinement.

Eight canonical CAD bounding-box corners are projected from train annotations.
Inference receives RGB, predicted box/class and K only; references are never read.
"""
import itertools
import time
from pathlib import Path
import numpy as np
from PIL import Image,ImageEnhance
from .common import resolve,read_json,write_json,set_seed
from .data import load_index,select_frames
from .detection import choose_device
from .pose import GeometricPoseEstimator,trimmed_icp


def cad_corners(info):
    return np.array(list(itertools.product(*[(info["min_"+axis],info["min_"+axis]+info["size_"+axis]) for axis in "xyz"]))) / 1000


def crop_rgb(rgb,box,size=128):
    h,w = rgb.shape[:2]
    x1,y1,x2,y2 = np.asarray(box,dtype=float)
    pad = .1*max(x2-x1,y2-y1)
    x1,y1 = max(0,int(np.floor(x1-pad))),max(0,int(np.floor(y1-pad)))
    x2,y2 = min(w,int(np.ceil(x2+pad))),min(h,int(np.ceil(y2+pad)))
    if x2<=x1 or y2<=y1:
        raise ValueError("Empty object crop")
    image = Image.fromarray(rgb[y1:y2,x1:x2]).resize((size,size),Image.Resampling.BILINEAR)
    return image,np.array([x1,y1]),np.array([x2-x1,y2-y1])


def image_tensor(image):
    import torch
    array = np.array(image).astype(np.float32)/255
    array = (array-np.array([.485,.456,.406],dtype=np.float32))/np.array([.229,.224,.225],dtype=np.float32)
    return torch.from_numpy(array).permute(2,0,1)


def create_network(pretrained=False):
    import torch
    from torch import nn
    from torchvision.models import resnet18,ResNet18_Weights
    class KeypointNetwork(nn.Module):
        def __init__(self):
            super().__init__()
            self.backbone = resnet18(weights=ResNet18_Weights.DEFAULT if pretrained else None)
            self.backbone.fc = nn.Identity()
            self.embedding = nn.Embedding(5,16)
            self.head = nn.Sequential(nn.Linear(528,256),nn.ReLU(),nn.Linear(256,16))

        def forward(self,image,labels):
            features = self.backbone(image)
            return self.head(torch.cat((features,self.embedding(labels-1)),dim=1)).reshape(-1,8,2)
    return KeypointNetwork()


class KeypointDataset:
    def __init__(self,frames,model_info,training=False):
        self.items = [(f,o) for f in frames for o in f["instances"]
                      if o["visib_fract"]>=.05 and o["rotation_orthogonality_error"]<=1e-3]
        self.info,self.training = model_info,training

    def __len__(self):
        return len(self.items)

    def __getitem__(self,i):
        import torch
        frame,obj = self.items[i]
        rgb = np.array(Image.open(frame["rgb"]).convert("RGB"))
        mask = np.array(Image.open(obj["mask_visib"]))>0
        y,x = np.nonzero(mask)
        image,origin,extent = crop_rgb(rgb,[x.min(),y.min(),x.max()+1,y.max()+1])
        corners = cad_corners(self.info[str(obj["obj_id"])])
        observed = corners@np.array(obj["R_m2c"]).reshape(3,3).T+np.array(obj["t_m2c_mm"])/1000
        projected = observed@np.array(frame["K"]).reshape(3,3).T
        uv = projected[:,:2]/projected[:,2:]
        targets = (uv-origin)/extent
        if self.training:
            image = ImageEnhance.Brightness(image).enhance(float(np.random.uniform(.8,1.2)))
        return image_tensor(image),torch.tensor(obj["obj_id"],dtype=torch.long),torch.tensor(targets,dtype=torch.float32)


def train_rgb_pose(config,epochs=12,val_limit=200,device="auto",resume=None):
    import torch
    from torch.utils.data import DataLoader
    set_seed(config["seed"])
    torch.set_num_threads(4)
    device = choose_device(device)
    index,splits = load_index(config)
    info = read_json(resolve(config["data"]["models"])/"models_info.json")
    train = KeypointDataset(select_frames(index,splits["train"]),info,True)
    val = KeypointDataset(select_frames(index,splits["val"],val_limit,config["seed"]),info)
    loader = DataLoader(train,batch_size=16,shuffle=True,num_workers=0)
    val_loader = DataLoader(val,batch_size=16,num_workers=0)
    network = create_network(resume is None).to(device)
    optimizer = torch.optim.AdamW(network.parameters(),lr=1e-4,weight_decay=1e-4)
    amp = device.type=="cuda"
    scaler = torch.amp.GradScaler("cuda",enabled=amp)
    directory = resolve("artifacts/training/rgb_pose")
    directory.mkdir(parents=True,exist_ok=True)
    history,best,start = [],float("inf"),0
    if resume:
        payload = torch.load(resume,map_location="cpu",weights_only=False)
        network.load_state_dict(payload["model"])
        optimizer.load_state_dict(payload["optimizer"])
        scaler.load_state_dict(payload["scaler"])
        history = payload["history"]
        best = min(r["validation_normalized_keypoint_rmse"] for r in history)
        start = payload["epoch"]
    for epoch in range(start,epochs):
        network.train(); total=0.; begun=time.perf_counter()
        for images,labels,targets in loader:
            images,labels,targets = images.to(device),labels.to(device),targets.to(device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,enabled=amp):
                predicted = network(images,labels)
                loss = torch.nn.functional.smooth_l1_loss(predicted,targets)
            if not torch.isfinite(loss):
                raise RuntimeError("Non-finite RGB pose loss")
            scaler.scale(loss).backward(); scaler.step(optimizer); scaler.update()
            total += loss.item()*len(images)
        network.eval(); errors=[]
        with torch.inference_mode():
            for images,labels,targets in val_loader:
                prediction = network(images.to(device),labels.to(device)).cpu()
                errors.extend(((prediction-targets)**2).mean(dim=(1,2)).numpy().tolist())
        validation = float(np.sqrt(np.mean(errors)))
        history.append({"epoch":epoch+1,"training_loss":total/len(train),"validation_normalized_keypoint_rmse":validation,
                        "training_seconds":time.perf_counter()-begun})
        payload = {"model":network.state_dict(),"config":config,"model_info":info,"history":history,
                   "optimizer":optimizer.state_dict(),"scaler":scaler.state_dict(),
                   "epoch":epoch+1,"train_instances":len(train),"validation_instances":len(val),
                   "ground_truth_poses_used_only_as_training_targets":True,
                   "training_frame_keys":[f["key"] for f in select_frames(index,splits["train"])]}
        torch.save(payload,directory/"last.pt")
        if validation<best:
            best=validation; torch.save(payload,directory/"best.pt")
        write_json(directory/"history.json",history)
        print(f"RGB-pose epoch={epoch+1}/{epochs} train_loss={total/len(train):.5f} val_keypoint_rmse={validation:.4f}",flush=True)
    return directory/"best.pt"


class RGBKeypointEstimator:
    def __init__(self,checkpoint,config,device="auto"):
        import torch
        self.device = choose_device(device)
        self.payload = torch.load(checkpoint,map_location="cpu",weights_only=False)
        self.network = create_network(False)
        self.network.load_state_dict(self.payload["model"])
        self.network.to(self.device).eval()
        self.geometry = GeometricPoseEstimator(config)
        self.config = config
        self.checkpoint = str(Path(checkpoint).resolve())

    def estimate_rgb(self,rgb,k,box,obj_id):
        import cv2
        import torch
        image,origin,extent = crop_rgb(rgb,box)
        with torch.inference_mode():
            normalized = self.network(image_tensor(image)[None].to(self.device),torch.tensor([obj_id],device=self.device)).cpu().numpy()[0]
        image_points = normalized*extent+origin
        model = cad_corners(self.payload["model_info"][str(obj_id)])
        cv2.setRNGSeed(self.config["seed"])
        ok,rotvec,tvec,inliers = cv2.solvePnPRansac(model.astype(np.float64),image_points.astype(np.float64),k.astype(np.float64),
            None,iterationsCount=100,reprojectionError=15.,flags=cv2.SOLVEPNP_EPNP)
        if not ok or tvec[2,0]<=0 or inliers is None or len(inliers)<4:
            return {"status":"pnp_failed","backend":"rgb_keypoints_pnp","uses_ground_truth_pose":False}
        # Refine all corners after a valid RANSAC initialization.
        rotvec,tvec = cv2.solvePnPRefineLM(model.astype(np.float64),image_points.astype(np.float64),k.astype(np.float64),None,rotvec,tvec)
        pose = np.eye(4); pose[:3,:3] = cv2.Rodrigues(rotvec)[0]; pose[:3,3] = tvec.ravel()
        reprojection,_ = cv2.projectPoints(model,rotvec,tvec,k,None)
        rmse = float(np.sqrt(np.mean((reprojection[:,0]-image_points)**2)))
        return {"status":"ok" if rmse<20 and pose[2,3]>0 else "poor_fit","backend":"rgb_keypoints_pnp",
                "T_camera_object":pose,"reprojection_rmse_pixels":rmse,"predicted_corners_uv":image_points,
                "uses_ground_truth_pose":False,"uses_depth_for_pose":False,"pose_checkpoint":self.checkpoint}

    def refine_depth(self,result,points,obj_id):
        if "T_camera_object" not in result:
            return result
        if len(points)<self.config["geometry"]["min_points"]:
            return {**result,"status":"insufficient_points_for_refinement","uses_depth_for_pose":True}
        _,model,_ = self.geometry.mesh(obj_id)
        cfg = self.config["pose"]
        pose,rmse,coverage = trimmed_icp(model,points,np.asarray(result["T_camera_object"]),cfg["icp_iterations"],
                                       cfg["correspondence_limit_m"],cfg["trim_fraction"])
        return {**result,"T_camera_object":pose,"backend":"rgb_keypoints_pnp_depth_icp","uses_depth_for_pose":True,
                "status":"ok" if rmse<cfg["max_observed_rmse_m"] and coverage>cfg["min_coverage"] else "poor_fit",
                "observed_trimmed_rmse_m":rmse,"observed_coverage_10mm":coverage}
