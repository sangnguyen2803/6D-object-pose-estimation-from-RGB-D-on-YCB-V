"""Conservative surface-point collision checks, not full robot motion planning."""
import numpy as np
from scipy.spatial import cKDTree


def gripper_boxes(width,gripper,margin=0):
    t,d,l,p = (gripper[k] for k in ["finger_thickness_m","finger_depth_m","finger_length_m","palm_thickness_m"])
    boxes = []
    for sign in [-1,1]:
        center = sign*(width/2+t/2)
        boxes.append((np.array([center-t/2,-d/2,-l]),np.array([center+t/2,d/2,0.])))
    boxes.append((np.array([-width/2-t,-d/2,-l-p]),np.array([width/2+t,d/2,-l])))
    return [(a-margin,b+margin) for a,b in boxes]


def box_collision(local_points,boxes):
    if len(local_points)==0:
        return False
    return any(np.any(np.all((local_points>=lo)&(local_points<=hi),axis=1)) for lo,hi in boxes)


def gripper_vertices(candidate,gripper):
    vertices = []
    for lo,hi in gripper_boxes(candidate["opening_width_m"],gripper):
        vertices.extend([[x,y,z] for x in [lo[0],hi[0]] for y in [lo[1],hi[1]] for z in [lo[2],hi[2]]])
    pose = np.asarray(candidate["T_camera_gripper"])
    return np.asarray(vertices)@pose[:3,:3].T+pose[:3,3]


def filter_candidates(candidates,scene_points,target_points,config):
    cfg,g = config["grasp"],config["gripper"]
    scene_points = np.asarray(scene_points).reshape(-1,3)
    target_points = np.asarray(target_points).reshape(-1,3)
    obstacle_tree = cKDTree(scene_points) if len(scene_points) else None
    accepted,rejected = [],[]
    for candidate in candidates:
        reason = None
        final = np.asarray(candidate["T_camera_gripper"])
        pre = np.asarray(candidate["T_camera_pregrasp"])
        rotation = final[:3,:3]
        # Target surfaces have no obstacle margin; intended inner-face contacts allowed.
        target_local = (target_points-final[:3,3])@rotation
        contact = (np.abs(np.abs(target_local[:,0])-candidate["contact_width_m"]/2)<g["contact_tolerance_m"])
        contact &= (np.abs(target_local[:,1])<g["finger_depth_m"]/2+g["contact_tolerance_m"])
        contact &= (np.abs(target_local[:,2])<g["contact_tolerance_m"])
        if box_collision(target_local[~contact],gripper_boxes(candidate["opening_width_m"],g)):
            reason = "target_body_collision"
        approach_alphas = np.linspace(0,1,cfg["approach_steps"])
        if cfg.get('continuous_approach',False):
            delta = (pre[:3,3]-final[:3,3])@rotation
            local = (scene_points-final[:3,3])@rotation
            swept = [(low+np.minimum(delta,0),high+np.maximum(delta,0)) for low,high in gripper_boxes(candidate['opening_width_m'],g,cfg['clearance_margin_m'])]
            if box_collision(local,swept):
                reason = 'scene_swept_volume_collision'
            target_swept = [(low+np.minimum(delta,0),high+np.maximum(delta,0)) for low,high in gripper_boxes(candidate['opening_width_m'],g)]
            if box_collision(target_local[~contact],target_swept):
                reason = 'target_swept_volume_collision'
            approach_alphas = []
        for alpha in approach_alphas:
            if reason:
                break
            position = pre[:3,3]*(1-alpha)+final[:3,3]*alpha
            local = (scene_points-position)@rotation
            if box_collision(local,gripper_boxes(candidate["opening_width_m"],g,cfg["clearance_margin_m"])):
                reason = "scene_or_approach_collision"
            target_along = (target_points-position)@rotation
            # Intended contacts only allowed at the final approach pose.
            target_keep = ~contact if alpha==1 else np.ones(len(target_points),dtype=bool)
            if box_collision(target_along[target_keep],gripper_boxes(candidate["opening_width_m"],g)):
                reason = "target_approach_collision"
        if reason:
            rejected.append({"grasp_id": candidate["grasp_id"],"reason": reason})
            continue
        vertices = gripper_vertices(candidate,g)
        clearance = float(obstacle_tree.query(vertices)[0].min()) if obstacle_tree else 0.1
        accessibility = float((np.dot(rotation[:,2],[0,0,1])+1)/2)
        weights = cfg["weights"]
        score = weights["contact"]*candidate["contact_score"]+weights["clearance"]*min(clearance/0.03,1)+weights["accessibility"]*accessibility
        approach_scope = 'continuous_swept_approach' if cfg.get('continuous_approach',False) else 'discretized_approach'
        accepted.append({**candidate,"score": float(score),"clearance_proxy_m": clearance,"collision_status": "passed_surface_checks",
                         "validation_scope": f"sampled_surfaces_and_{approach_scope}; hidden_unknown_geometry_and_robot_reachability_not_verified"})
    accepted.sort(key=lambda c:c["score"],reverse=True)
    return accepted[:cfg["output_limit"]],rejected,len(accepted)
